package com.example.virtualmouse

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Tap calibration. Hands differ, and so does how well the camera sees thumb and middle finger touching.
 * This measures YOUR "thumb apart" and "thumb touching" distances and sets the tap thresholds from them.
 */
class CalibrationActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var tvStep: TextView
    private lateinit var tvHelp: TextView
    private lateinit var tvResult: TextView
    private lateinit var gauge: GaugeView
    private lateinit var btnStart: Button

    private var phase = 0 // 0 idle, 1 waiting for hand, 2 thumb apart, 3 thumb touching, 4 test
    private var phaseStart = 0L
    private val openS = ArrayList<Float>()
    private val touchS = ArrayList<Float>()
    private var openMed = 0f
    private var taps = 0
    private var lastTapSeen = 0L

    private val tick = object : Runnable {
        override fun run() {
            step()
            ui.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Ui.applyTheme(this)
        setTheme(Ui.themeRes())
        super.onCreate(savedInstanceState)
        val c = this
        Ui.systemBars(this)
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        val pad = Ui.dp(c, 16)

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Calibrate tap", 24f, Ui.TEXT, true))
        Ui.add(col, Ui.text(c, "Measures your own thumb and middle finger, so tapping fits your hand. Takes about 10 seconds.", 13f, Ui.MUTED), 4)

        val card = Ui.card(c)
        tvStep = Ui.text(c, "Ready", 18f, Ui.ACCENT, true)
        card.addView(tvStep)
        tvHelp = Ui.text(c, "Press Start, then follow the instructions. Keep your index finger up the whole time.", 15f, Ui.TEXT)
        Ui.add(card, tvHelp, 8)
        gauge = GaugeView(c)
        Ui.add(card, gauge, 16)
        Ui.add(card, Ui.text(c, "The bar shows the distance between your thumb tip and middle fingertip right now.", 12f, Ui.MUTED), 6)
        tvResult = Ui.text(c, "", 14f, Ui.TEXT, true)
        Ui.add(card, tvResult, 14)
        Ui.add(col, card, 16)

        btnStart = Ui.button(c, "Start", true) { start() }
        Ui.add(col, btnStart, 16)
        Ui.add(col, Ui.button(c, "Done", false) { finish() }, 8)

        setContentView(ScrollView(c).apply {
            setBackgroundColor(Ui.BG)
            addView(col)
        })
        refreshGauge()
    }

    private fun refreshGauge() {
        gauge.value = TrackingState.pinchRatio
        gauge.on = if (TrackingState.calOn > 0f) TrackingState.calOn else 0.20f + 0.04f * TrackingState.tapSens
        gauge.arm = if (TrackingState.calArm > 0f) TrackingState.calArm else gauge.on + 0.15f
        gauge.invalidate()
    }

    private fun start() {
        if (!TrackingState.running) {
            val err = startTracking(this)
            if (err != null) {
                Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                return
            }
        }
        phase = 1
        phaseStart = SystemClock.uptimeMillis()
        openS.clear()
        touchS.clear()
        tvResult.text = ""
        btnStart.visibility = View.GONE
    }

    private fun median(l: List<Float>): Float {
        val s = l.sorted()
        return s[s.size / 2]
    }

    private fun fail(msg: String) {
        phase = 0
        tvStep.text = "Could not calibrate"
        tvHelp.text = msg
        btnStart.text = "Try again"
        btnStart.visibility = View.VISIBLE
    }

    private fun finish3() {
        if (touchS.size < 5) {
            fail("I could not see your hand while you touched your fingers. Hold the phone steady, add light in front of you, and try again.")
            return
        }
        val touch = median(touchS)
        if (openMed - touch < 0.15f) {
            fail("I could not see a clear difference between 'apart' (${"%.2f".format(openMed)}) and 'touching' (${"%.2f".format(touch)}). " +
                "Move the hand a little closer, spread your thumb further away in step 1, and press your fingers firmly together in step 2.")
            return
        }
        val on = (touch + 0.40f * (openMed - touch)).coerceIn(0.20f, 0.70f)
        val arm = (touch + 0.65f * (openMed - touch)).coerceIn(on + 0.10f, 1.10f)
        prefs.edit().putFloat("tap_on", on).putFloat("tap_arm", arm).apply()
        TrackingState.calOn = on
        TrackingState.calArm = arm
        taps = 0
        phase = 4
        tvStep.text = "Calibrated  ✅"
        tvHelp.text = "Now test it: flick your thumb away from your middle finger, then touch them together. Taps are only counted here, nothing is clicked."
        tvResult.text = "Touching ${"%.2f".format(touch)}  |  apart ${"%.2f".format(openMed)}  |  taps under ${"%.2f".format(on)}\nTest taps counted: 0"
        btnStart.text = "Calibrate again"
        btnStart.visibility = View.VISIBLE
        refreshGauge()
    }

    private fun step() {
        val now = SystemClock.uptimeMillis()
        val seen = TrackingState.running && TrackingState.gesture != "NO_HAND" && TrackingState.landmarks != null
        gauge.value = TrackingState.pinchRatio
        gauge.invalidate()
        when (phase) {
            1 -> {
                tvStep.text = "Show your hand"
                tvHelp.text = "Raise your index finger toward the front camera and relax the others."
                if (!seen) phaseStart = now
                else if (now - phaseStart > 1500L) {
                    phase = 2
                    phaseStart = now
                    openS.clear()
                }
            }
            2 -> {
                val left = 3 - (now - phaseStart) / 1000L
                tvStep.text = "Step 1 of 2:  thumb APART  ($left)"
                tvHelp.text = "Keep your thumb AWAY from your middle finger and hold still."
                if (seen && now - phaseStart > 600L) openS.add(TrackingState.pinchRatio)
                if (now - phaseStart > 3000L) {
                    if (openS.size < 5) {
                        fail("I could not see your hand clearly. Add light in front of you, face your palm to the camera, and try again.")
                    } else {
                        openMed = median(openS)
                        phase = 3
                        phaseStart = now
                        touchS.clear()
                    }
                }
            }
            3 -> {
                val left = 4 - (now - phaseStart) / 1000L
                tvStep.text = "Step 2 of 2:  thumb TOUCHING  ($left)"
                tvHelp.text = "Now TOUCH your thumb and middle finger together and hold them there."
                if (seen && now - phaseStart > 1500L) touchS.add(TrackingState.pinchRatio)
                if (now - phaseStart > 4000L) finish3()
            }
            4 -> {
                if (TrackingState.eventRecent("TAP", 400L) && now - lastTapSeen > 500L) {
                    lastTapSeen = now
                    taps++
                    val t = tvResult.text.toString().substringBefore("\nTest taps")
                    tvResult.text = t + "\nTest taps counted: $taps  ✅"
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TrackingState.suppress = true // detect gestures, but do not perform them while calibrating
        TrackingState.forceHud = true
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(tick)
    }

    override fun onPause() {
        TrackingState.suppress = false
        TrackingState.forceHud = false
        MouseAccessibilityService.instance?.refreshHud()
        ui.removeCallbacks(tick)
        if (phase in 1..3) phase = 0
        super.onPause()
    }

    /** Horizontal bar: current distance, with the "taps under" and "thumb open over" marks. */
    private class GaugeView(c: Context) : View(c) {
        var value = 1f
        var on = 0.4f
        var arm = 0.55f
        private val d = c.resources.displayMetrics.density
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.tint(Ui.MUTED, 50) }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT }
        private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 3f * d }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Ui.MUTED
            textSize = 10f * d
        }
        private val box = RectF()

        override fun onMeasure(w: Int, h: Int) {
            setMeasuredDimension(MeasureSpec.getSize(w), (56f * d).toInt())
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val top = 20f * d
            val bh = 16f * d
            val max = 1.4f
            box.set(0f, top, w, top + bh)
            canvas.drawRoundRect(box, bh / 2, bh / 2, track)
            val vx = (value / max).coerceIn(0f, 1f) * w
            box.set(0f, top, max(vx, bh), top + bh)
            canvas.drawRoundRect(box, bh / 2, bh / 2, fill)
            mark.color = Ui.GOOD
            val xo = (on / max).coerceIn(0f, 1f) * w
            canvas.drawLine(xo, top - 6f * d, xo, top + bh + 6f * d, mark)
            canvas.drawText("taps under", xo - 22f * d, top + bh + 20f * d, txt)
            mark.color = Ui.WARN
            val xa = (arm / max).coerceIn(0f, 1f) * w
            canvas.drawLine(xa, top - 6f * d, xa, top + bh + 6f * d, mark)
            canvas.drawText("thumb open", xa - 20f * d, top - 10f * d, txt)
        }

        private fun max(a: Float, b: Float) = if (a > b) a else b
    }
}
