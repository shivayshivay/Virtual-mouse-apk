package com.example.virtualmouse

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** About screen: who made the app, copyright, privacy policy, permissions and open-source credits. */
class AboutActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        Ui.applyTheme(this)
        setTheme(Ui.themeRes())
        super.onCreate(savedInstanceState)
        val c = this
        Ui.systemBars(this)
        val pad = Ui.dp(c, 16)

        val name = getString(R.string.dev_name)
        val email = getString(R.string.dev_email)
        val github = getString(R.string.dev_github)
        val site = getString(R.string.dev_website)
        val year = getString(R.string.copyright_year)

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)

        // header
        val logo = ImageView(c)
        logo.setImageResource(R.drawable.gf_logo)
        val llp = LinearLayout.LayoutParams(Ui.dp(c, 96), Ui.dp(c, 96))
        llp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(logo, llp)
        Ui.add(col, Ui.text(c, "GestureFlow", 26f, Ui.TEXT, true).also { it.gravity = Gravity.CENTER }, 10)
        Ui.add(col, Ui.text(c, "Version 1.8  |  Hand control for your phone", 12f, Ui.MUTED).also { it.gravity = Gravity.CENTER }, 2)

        // developer
        val dev = Ui.card(c)
        dev.addView(Ui.text(c, "Developer", 16f, Ui.TEXT, true))
        Ui.add(dev, Ui.text(c, name, 18f, Ui.ACCENT, true), 8)
        if (email.isNotBlank()) Ui.add(dev, Ui.text(c, email, 13f, Ui.MUTED), 2)
        if (site.isNotBlank()) Ui.add(dev, Ui.text(c, site, 13f, Ui.MUTED), 2)
        if (github.isNotBlank()) Ui.add(dev, Ui.text(c, github, 13f, Ui.MUTED), 2)
        if (email.isNotBlank()) {
            Ui.add(dev, Ui.button(c, "Email the developer", true) {
                open(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).putExtra(Intent.EXTRA_SUBJECT, "GestureFlow"))
            }, 12)
        }
        if (github.isNotBlank()) {
            Ui.add(dev, Ui.button(c, "Open GitHub", false) {
                open(Intent(Intent.ACTION_VIEW, Uri.parse(github)))
            }, 8)
        }
        Ui.add(col, dev, 18)

        section(col, "Copyright",
            "© $year $name. All rights reserved.\n\n" +
                "The GestureFlow name, app design, source code and icon artwork are supplied by the developer. " +
                "Third-party components are used under their own licences, listed below. " +
                "All other trademarks belong to their owners; GestureFlow is not affiliated with or endorsed by Google.")

        section(col, "Privacy policy",
            "GestureFlow does not collect, store, share or sell personal data.\n\n" +
                "• Camera: used live to see your hand. Frames are analysed on your phone and discarded immediately. " +
                "Nothing is recorded, saved or uploaded.\n\n" +
                "• No internet: the app does not request internet permission, so it cannot send anything off your phone.\n\n" +
                "• Accessibility service: used only to draw a cursor and to perform the taps, swipes, pinch-zoom, Back and Home " +
                "that you trigger with gestures. It is not given access to read your screen, notifications, passwords or what you type.\n\n" +
                "• Volume: gestures change the media volume only.\n\n" +
                "• Settings (speed, smoothness, preview mode, vibration) are stored only on your phone and are removed when you uninstall.\n\n" +
                "• No accounts, ads, analytics or trackers.\n\n" +
                "• You stay in control: press STOP, or switch the accessibility service off in Android settings, at any time. " +
                "The camera also stops when the screen turns off and after 5 minutes without a hand.\n\n" +
                "Last updated: October 2026." +
                (if (email.isNotBlank()) "\nPrivacy questions: $email" else ""))

        section(col, "Permissions explained",
            "• Camera: to see your hand.\n" +
                "• Accessibility service: to move the cursor and perform taps, swipes, zoom, Back and Home.\n" +
                "• Foreground service (camera): keeps tracking running while you use other apps; a notification is shown.\n" +
                "• Notifications: to show that notification on Android 13 and newer.\n" +
                "• Vibration: short buzz as feedback when an action happens.")

        section(col, "Open-source notices",
            "This app includes software from other projects:\n\n" +
                "• MediaPipe Tasks and the hand landmark model (Google): Apache License 2.0\n" +
                "• AndroidX CameraX, Lifecycle and Core (Google): Apache License 2.0\n" +
                "• Kotlin Standard Library (JetBrains): Apache License 2.0\n\n" +
                "Apache License 2.0: https://www.apache.org/licenses/LICENSE-2.0")

        section(col, "Disclaimer",
            "GestureFlow is provided \"as is\", without warranty of any kind. Hand tracking depends on light, camera and " +
                "how you hold your hand, and can make mistakes. Do not rely on it for anything safety-critical.")

        Ui.add(col, Ui.button(c, "Back", false) { finish() }, 18)

        setContentView(ScrollView(c).apply {
            setBackgroundColor(Ui.BG)
            addView(col)
        })
    }

    private fun section(parent: LinearLayout, title: String, body: String) {
        val c = this
        val card = Ui.card(c)
        card.addView(Ui.text(c, title, 16f, Ui.TEXT, true))
        Ui.add(card, Ui.text(c, body, 13f, Ui.MUTED).also { it.setLineSpacing(0f, 1.15f) }, 8)
        Ui.add(parent, card, 12)
    }

    private fun open(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open this", Toast.LENGTH_LONG).show()
        }
    }
}
