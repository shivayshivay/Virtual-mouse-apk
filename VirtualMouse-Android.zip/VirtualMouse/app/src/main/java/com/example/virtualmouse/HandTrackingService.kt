package com.example.virtualmouse

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.Display
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class HandTrackingService : LifecycleService() {

    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val engine = GestureEngine()
    private val main = Handler(Looper.getMainLooper())
    private var frames = 0
    private var fpsStart = 0L
    private var lastHand = 0L
    private var registered = false

    /** Privacy: the camera is switched off as soon as the screen turns off. */
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Toast.makeText(this@HandTrackingService, "GestureFlow stopped: screen turned off", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    /** Keeps the picture upright if the phone is rotated while tracking. */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { updateRotation() }
    }

    override fun onCreate() {
        super.onCreate()
        goForeground()
        val prefs = getSharedPreferences("vm", MODE_PRIVATE)
        TrackingState.smooth = prefs.getFloat("smooth", 5f)
        TrackingState.speed = prefs.getFloat("speed", 5f)
        TrackingState.scrollInv = prefs.getBoolean("scroll_inv", false)
        TrackingState.running = true
        fpsStart = SystemClock.uptimeMillis()
        lastHand = fpsStart
        MouseAccessibilityService.instance?.refreshHud()

        ContextCompat.registerReceiver(
            this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        getSystemService(DisplayManager::class.java)?.registerDisplayListener(displayListener, null)
        registered = true

        try {
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .build()
            landmarker = HandLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            Log.e(TAG, "Could not load hand model", e)
            Toast.makeText(this, "Model load failed: hand_landmarker.task missing?", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        startCamera()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("vm", "GestureFlow", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "vm")
            .setContentTitle("GestureFlow is using the camera")
            .setContentText("Stops when the screen turns off or no hand is seen for 5 minutes")
            .setSmallIcon(R.drawable.ic_stat_mouse)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(1, n)
        }
    }

    private fun updateRotation() {
        val dm = getSystemService(DisplayManager::class.java) ?: return
        val disp = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return
        analysis?.targetRotation = disp.rotation
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val p = future.get()
            provider = p
            val a = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 640))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            a.setAnalyzer(executor) { analyze(it) }
            analysis = a
            updateRotation()
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, a)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val src = proxy.toBitmap()
            val m = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // mirror, like a selfie view
            }
            val bmp = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            val result = landmarker?.detectForVideo(BitmapImageBuilder(bmp).build(), SystemClock.uptimeMillis())
            engine.update(result?.landmarks()?.firstOrNull(), result?.worldLandmarks()?.firstOrNull())

            val now = SystemClock.uptimeMillis()
            frames++
            if (now - fpsStart >= 1000L) {
                TrackingState.fps = frames
                frames = 0
                fpsStart = now
            }
            // Privacy / battery: stop the camera if nobody is using it.
            if (TrackingState.gesture != "NO_HAND") {
                lastHand = now
            } else if (now - lastHand > IDLE_MS) {
                lastHand = now
                main.post {
                    Toast.makeText(this, "GestureFlow stopped: no hand seen for 5 minutes", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "frame error", e)
        } finally {
            proxy.close()
        }
    }

    override fun onDestroy() {
        if (registered) {
            try { unregisterReceiver(screenOff) } catch (_: Exception) {}
            try { getSystemService(DisplayManager::class.java)?.unregisterDisplayListener(displayListener) } catch (_: Exception) {}
            registered = false
        }
        provider?.unbindAll()
        executor.shutdown()
        try { executor.awaitTermination(500, TimeUnit.MILLISECONDS) } catch (_: Exception) {}
        landmarker?.close()
        TrackingState.running = false
        TrackingState.gesture = "NO_HAND"
        TrackingState.landmarks = null
        TrackingState.fps = 0
        TrackingState.anchorX = -1f
        TrackingState.progress = 0f
        TrackingState.offX = 0f
        TrackingState.offY = 0f
        TrackingState.has3d = false
        TrackingState.hint = ""
        MouseAccessibilityService.instance?.refreshHud()
        super.onDestroy()
    }

    private companion object {
        const val TAG = "VirtualMouse"
        const val IDLE_MS = 5 * 60 * 1000L
    }
}
