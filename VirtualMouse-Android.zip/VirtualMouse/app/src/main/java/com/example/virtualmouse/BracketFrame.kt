package com.example.virtualmouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.min

/** Four neon corner brackets, like the scanning frame in the GestureFlow icon. */
class BracketFrame(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 4f * d
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 11f * d
    }
    private val path = Path()
    private val box = RectF()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val g = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), Ui.ACCENT, Ui.BLUE, Shader.TileMode.CLAMP)
        line.shader = g
        glow.shader = g
        glow.alpha = 45
        path.reset()
        val m = 6f * d
        val len = min(w, h) * 0.2f
        val r = len * 0.55f
        val wf = w.toFloat()
        val hf = h.toFloat()
        // top-left
        path.moveTo(m, m + len); path.lineTo(m, m + r)
        box.set(m, m, m + 2 * r, m + 2 * r); path.arcTo(box, 180f, 90f, false); path.lineTo(m + len, m)
        // top-right
        path.moveTo(wf - m - len, m); path.lineTo(wf - m - r, m)
        box.set(wf - m - 2 * r, m, wf - m, m + 2 * r); path.arcTo(box, 270f, 90f, false); path.lineTo(wf - m, m + len)
        // bottom-right
        path.moveTo(wf - m, hf - m - len); path.lineTo(wf - m, hf - m - r)
        box.set(wf - m - 2 * r, hf - m - 2 * r, wf - m, hf - m); path.arcTo(box, 0f, 90f, false); path.lineTo(wf - m - len, hf - m)
        // bottom-left
        path.moveTo(m + len, hf - m); path.lineTo(m + r, hf - m)
        box.set(m, hf - m - 2 * r, m + 2 * r, hf - m); path.arcTo(box, 90f, 90f, false); path.lineTo(m, hf - m - len)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawPath(path, glow)
        canvas.drawPath(path, line)
    }
}
