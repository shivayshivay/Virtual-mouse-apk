package com.example.virtualmouse

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/** Starts hand tracking. Returns an error message, or null on success. */
fun startTracking(a: Activity): String? {
    if (a.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
        return "Allow the camera first (step 1)"
    }
    if (MouseAccessibilityService.instance == null) {
        return "Enable GestureFlow in Accessibility settings first (step 2)"
    }
    ContextCompat.startForegroundService(a, Intent(a, HandTrackingService::class.java))
    return null
}

/** A tap calibration saved by an older (3D) version does not fit the Classic 2D mode: clear it once. */
fun migrateCalibration(c: Context) {
    val p = c.getSharedPreferences("vm", Context.MODE_PRIVATE)
    if (p.getInt("cal_ver", 0) < 2) {
        p.edit().remove("tap_on").remove("tap_arm").putInt("cal_ver", 2).apply()
    }
}
