package com.example.virtualmouse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/** Starts hand tracking. Returns an error message, or null on success. */
fun startTracking(a: Activity): String? {
    if (a.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
        return "Allow the camera first (step 1)"
    }
    if (MouseAccessibilityService.instance == null) {
        return "Enable GestureFlow in Accessibility settings first (step 2)"
    }
    ContextCompat.startForegroundService(a, Intent(a, HandTrackingService::class.java))
    return null
}
