package com.example.virtualmouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Pairs of landmark ids that form the hand skeleton (21 bones).
private val LINKS = intArrayOf(
    0, 1, 1, 2, 2, 3, 3, 4,
    0, 5, 5, 6, 6, 7, 7, 8,
    5, 9, 9, 10, 10, 11, 11, 12,
    9, 13, 13, 14, 14, 15, 15, 16,
    13, 17, 17, 18, 18, 19, 19, 20, 0, 17
)

/**
 * Live 3D hand: real depth from the hand model, drawn with perspective and neon depth shading
 * (near = big, bright cyan; far = small, dim violet). It sways gently so the depth is visible;
 * in the app you can also drag it to rotate.
 */
class HandPreviewView(c: Context, private val d: Float) : View(c) {

    var interactive = false

    private var yaw = 0.5f
    private var pitch = -0.3f
    private var userRotated = false
    private var lastX = 0f
    private var lastY = 0f

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 6, 10, 22) }
    private val floorP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
        color = Color.argb(70, 40, 215, 255)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val joint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11f * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 170, 185, 220)
        textSize = 9.5f * d
    }
    private val stat = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    private val px = FloatArray(21)
    private val py = FloatArray(21)
    private val pz = FloatArray(21)
    private val ps = FloatArray(21)
    private val order = IntArray(21)
    private val depth = FloatArray(21)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!userRotated) {
                    yaw = 0.5f
                    pitch = -0.3f
                }
                yaw += (e.x - lastX) * 0.012f
                pitch = (pitch + (e.y - lastY) * 0.012f).coerceIn(-1.3f, 1.3f)
                lastX = e.x
                lastY = e.y
                userRotated = true
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val strip = 28f * d
        val ph = h - strip

        canvas.drawRoundRect(0f, 0f, w, h, 14f * d, 14f * d, bg)

        // floor rings under the hand: they make the depth readable
        box.set(w * 0.16f, ph * 0.80f, w * 0.84f, ph * 0.96f)
        canvas.drawOval(box, floorP)
        box.set(w * 0.30f, ph * 0.85f, w * 0.70f, ph * 0.93f)
        canvas.drawOval(box, floorP)

        val pts = TrackingState.points3d
        if (pts != null && TrackingState.landmarks != null) {
            draw3d(canvas, pts, w, ph)
        } else {
            val t = "Show your hand"
            canvas.drawText(t, (w - small.measureText(t)) / 2f, ph / 2f, small)
        }

        canvas.drawText("${TrackingState.fps} fps" + if (TrackingState.has3d) "  3D" else "", w - 62f * d, 13f * d, small)

        // hold progress (Back / Home / volume / zoom arming)
        val pg = TrackingState.progress
        if (pg > 0f) {
            stat.color = TrackingState.color()
            canvas.drawRoundRect(10f * d, h - 6f * d, 10f * d + (w - 20f * d) * pg, h - 3f * d, 2f * d, 2f * d, stat)
        }

        stat.color = TrackingState.color()
        canvas.drawCircle(14f * d, ph + strip / 2f - 2f * d, 5f * d, stat)
        canvas.drawText(TrackingState.label(), 26f * d, ph + strip / 2f + 2f * d, label)
    }

    private fun draw3d(canvas: Canvas, pts: FloatArray, w: Float, ph: Float) {
        val yawA: Float
        val pitchA: Float
        if (interactive && userRotated) {
            yawA = yaw
            pitchA = pitch
        } else {
            yawA = 0.55f * sin(SystemClock.uptimeMillis() / 1400f)
            pitchA = -0.3f
        }

        var mx = 0f
        var my = 0f
        var mz = 0f
        for (i in 0 until 21) {
            mx += pts[i * 3]
            my += pts[i * 3 + 1]
            mz += pts[i * 3 + 2]
        }
        mx /= 21f
        my /= 21f
        mz /= 21f

        val cyw = cos(yawA)
        val syw = sin(yawA)
        val cp = cos(pitchA)
        val sp = sin(pitchA)
        val base = min(w, ph) / 0.27f
        for (i in 0 until 21) {
            val x = pts[i * 3] - mx
            val y = pts[i * 3 + 1] - my
            val z = pts[i * 3 + 2] - mz
            val x1 = x * cyw + z * syw
            val z1 = -x * syw + z * cyw
            val y2 = y * cp - z1 * sp
            val z2 = y * sp + z1 * cp
            val persp = 1f / max(1f + z2 * 3.5f, 0.45f)
            px[i] = w / 2f + x1 * base * persp
            py[i] = ph / 2f + y2 * base * persp
            pz[i] = z2
            ps[i] = persp
        }

        // bones, far ones first, so near bones overlap them
        val nb = LINKS.size / 2
        for (b in 0 until nb) {
            order[b] = b
            depth[b] = (pz[LINKS[b * 2]] + pz[LINKS[b * 2 + 1]]) * 0.5f
        }
        for (a in 1 until nb) {
            val key = order[a]
            val kd = depth[key]
            var j = a - 1
            while (j >= 0 && depth[order[j]] < kd) {
                order[j + 1] = order[j]
                j--
            }
            order[j + 1] = key
        }
        for (k in 0 until nb) {
            val b = order[k]
            val a = LINKS[b * 2]
            val e = LINKS[b * 2 + 1]
            val pr = (ps[a] + ps[e]) * 0.5f
            val t = ((pr - 0.8f) / 0.55f).coerceIn(0f, 1f) // 0 = far, 1 = near
            val r = (110 + (40 - 110) * t).toInt()
            val g = (70 + (220 - 70) * t).toInt()
            glow.color = Color.argb(35 + (40 * t).toInt(), r, g, 255)
            glow.strokeWidth = 9f * d * pr
            canvas.drawLine(px[a], py[a], px[e], py[e], glow)
            bone.color = Color.argb(140 + (115 * t).toInt(), r, g, 255)
            bone.strokeWidth = 3.4f * d * pr
            canvas.drawLine(px[a], py[a], px[e], py[e], bone)
        }

        // joints; fingertips are larger, and thumb + pinky tips glow when they are about to tap
        val closing = TrackingState.pinchRatio < 0.5f
        for (i in 0 until 21) {
            val t = ((ps[i] - 0.8f) / 0.55f).coerceIn(0f, 1f)
            val tip = i == 4 || i == 8 || i == 12 || i == 16 || i == 20
            joint.color = Color.argb(190 + (65 * t).toInt(), 255, 255, 255)
            canvas.drawCircle(px[i], py[i], (if (tip) 3.6f else 2.4f) * d * ps[i], joint)
            if ((i == 4 || i == 20) && closing) {
                halo.color = Color.argb(150, 0, 220, 255)
                canvas.drawCircle(px[i], py[i], 8f * d * ps[i], halo)
            }
        }

        // the index knuckle drives the cursor
        stat.color = TrackingState.color()
        halo.color = Color.argb(70, Color.red(stat.color), Color.green(stat.color), Color.blue(stat.color))
        canvas.drawCircle(px[5], py[5], 10f * d * ps[5], halo)
        canvas.drawCircle(px[5], py[5], 5.5f * d * ps[5], stat)
    }
}
