package com.example.virtualmouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// 16 finger segments (pairs of landmark ids): thumb, index, middle, ring, pinky.
private val SEG = intArrayOf(
    0, 1, 1, 2, 2, 3, 3, 4,
    5, 6, 6, 7, 7, 8,
    9, 10, 10, 11, 11, 12,
    13, 14, 14, 15, 15, 16,
    17, 18, 18, 19, 19, 20
)
// finger thickness per segment in metres (tapering towards the tips)
private val SEG_W = floatArrayOf(
    0.024f, 0.021f, 0.018f, 0.015f,
    0.019f, 0.016f, 0.013f,
    0.020f, 0.017f, 0.014f,
    0.019f, 0.016f, 0.013f,
    0.016f, 0.013f, 0.011f
)
// outline of the palm
private val PALM = intArrayOf(0, 1, 5, 9, 13, 17)

// A relaxed open hand (metres, wrist at the origin, y points down). Shown when no hand is being tracked.
private val IDLE = floatArrayOf(
    0f, 0f, 0f,
    -0.022f, -0.020f, -0.004f, -0.040f, -0.044f, -0.008f, -0.054f, -0.066f, -0.010f, -0.064f, -0.086f, -0.010f,
    -0.027f, -0.088f, 0f, -0.031f, -0.126f, -0.002f, -0.033f, -0.151f, -0.003f, -0.034f, -0.172f, -0.003f,
    -0.006f, -0.093f, 0f, -0.007f, -0.134f, -0.002f, -0.007f, -0.161f, -0.003f, -0.007f, -0.183f, -0.003f,
    0.016f, -0.088f, 0f, 0.019f, -0.126f, -0.002f, 0.020f, -0.150f, -0.003f, 0.020f, -0.170f, -0.003f,
    0.036f, -0.078f, 0.001f, 0.042f, -0.108f, 0f, 0.045f, -0.127f, 0f, 0.047f, -0.143f, 0f
)

/**
 * Live 3D hand MODEL: real depth from the hand model, drawn as solid, lit, tapered fingers and a shaded palm
 * with perspective (near = big and bright, far = small and violet). It sways gently so the depth is visible;
 * in the app you can drag it to rotate. When no hand is tracked it shows a relaxed demo hand.
 */
class HandPreviewView(c: Context, private val d: Float) : View(c) {

    var interactive = false
    var cornerDp = 14f

    private var yaw = 0.5f
    private var pitch = -0.3f
    private var userRotated = false
    private var lastX = 0f
    private var lastY = 0f

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 6, 10, 22) }
    private val floorP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
        color = Color.argb(70, 40, 215, 255)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * d
        strokeJoin = Paint.Join.ROUND
    }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11f * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 170, 185, 220)
        textSize = 9.5f * d
    }
    private val stat = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val path = Path()

    private val px = FloatArray(21)
    private val py = FloatArray(21)
    private val ps = FloatArray(21)
    private val rx = FloatArray(21)
    private val ry = FloatArray(21)
    private val rz = FloatArray(21)
    private val order = IntArray(17)
    private val depth = FloatArray(17)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!userRotated) {
                    yaw = 0.5f
                    pitch = -0.3f
                }
                yaw += (e.x - lastX) * 0.012f
                pitch = (pitch + (e.y - lastY) * 0.012f).coerceIn(-1.3f, 1.3f)
                lastX = e.x
                lastY = e.y
                userRotated = true
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val strip = 28f * d
        val ph = h - strip

        canvas.drawRoundRect(0f, 0f, w, h, cornerDp * d, cornerDp * d, bg)

        // floor rings under the hand: they make the depth readable
        box.set(w * 0.16f, ph * 0.80f, w * 0.84f, ph * 0.96f)
        canvas.drawOval(box, floorP)
        box.set(w * 0.30f, ph * 0.85f, w * 0.70f, ph * 0.93f)
        canvas.drawOval(box, floorP)

        val live = TrackingState.points3d
        val tracking = TrackingState.running && live != null && TrackingState.landmarks != null
        draw3d(canvas, if (tracking && live != null) live else IDLE, w, ph, !tracking)
        if (!tracking) {
            val t = if (TrackingState.running) "Show your hand" else "3D preview"
            canvas.drawText(t, (w - small.measureText(t)) / 2f, 16f * d, small)
        }

        canvas.drawText("${TrackingState.fps} fps" + if (TrackingState.has3d) "  3D" else "", w - 62f * d, h - 10f * d, small)

        // hold progress (Back / Home / volume / zoom / scroll arming)
        val pg = TrackingState.progress
        if (pg > 0f) {
            stat.color = TrackingState.color()
            canvas.drawRoundRect(10f * d, h - 6f * d, 10f * d + (w - 20f * d) * pg, h - 3f * d, 2f * d, 2f * d, stat)
        }

        stat.color = if (tracking) TrackingState.color() else Color.rgb(140, 152, 186)
        canvas.drawCircle(14f * d, ph + strip / 2f - 2f * d, 5f * d, stat)
        val text = if (TrackingState.running) TrackingState.label() else "Not tracking"
        canvas.drawText(text, 26f * d, ph + strip / 2f + 2f * d, label)
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = (a + (b - a) * t).toInt()

    /** far = violet, near = cyan-blue */
    private fun body(t: Float): Int = Color.rgb(lerp(110, 70, t), lerp(80, 190, t), 255)

    private fun shade(c: Int, k: Float): Int = Color.rgb(
        (Color.red(c) * k).toInt().coerceIn(0, 255),
        (Color.green(c) * k).toInt().coerceIn(0, 255),
        (Color.blue(c) * k).toInt().coerceIn(0, 255)
    )

    private fun withA(a: Int, c: Int): Int = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun draw3d(canvas: Canvas, pts: FloatArray, w: Float, ph: Float, idle: Boolean) {
        val yawA: Float
        val pitchA: Float
        if (interactive && userRotated) {
            yawA = yaw
            pitchA = pitch
        } else {
            yawA = 0.55f * sin(SystemClock.uptimeMillis() / 1400f)
            pitchA = -0.3f
        }

        var mx = 0f
        var my = 0f
        var mz = 0f
        for (i in 0 until 21) {
            mx += pts[i * 3]
            my += pts[i * 3 + 1]
            mz += pts[i * 3 + 2]
        }
        mx /= 21f
        my /= 21f
        mz /= 21f

        val cyw = cos(yawA)
        val syw = sin(yawA)
        val cp = cos(pitchA)
        val sp = sin(pitchA)
        val base = min(w, ph) / 0.27f
        for (i in 0 until 21) {
            val x = pts[i * 3] - mx
            val y = pts[i * 3 + 1] - my
            val z = pts[i * 3 + 2] - mz
            val x1 = x * cyw + z * syw
            val z1 = -x * syw + z * cyw
            val y2 = y * cp - z1 * sp
            val z2 = y * sp + z1 * cp
            val persp = 1f / max(1f + z2 * 3.5f, 0.45f)
            rx[i] = x1
            ry[i] = y2
            rz[i] = z2
            px[i] = w / 2f + x1 * base * persp
            py[i] = ph / 2f + y2 * base * persp
            ps[i] = persp
        }

        // far parts first so near parts overlap them: 16 finger segments + the palm
        for (b in 0 until 16) {
            order[b] = b
            depth[b] = (rz[SEG[b * 2]] + rz[SEG[b * 2 + 1]]) * 0.5f
        }
        order[16] = 16
        var pz = 0f
        for (k in 0 until 6) pz += rz[PALM[k]]
        depth[16] = pz / 6f + 0.01f
        for (a in 1 until 17) {
            val key = order[a]
            val kd = depth[key]
            var j = a - 1
            while (j >= 0 && depth[order[j]] < kd) {
                order[j + 1] = order[j]
                j--
            }
            order[j + 1] = key
        }

        val aMul = if (idle) 0.6f else 1f
        for (k in 0 until 17) {
            val b = order[k]
            if (b == 16) drawPalm(canvas, aMul) else drawSeg(canvas, b, base, aMul)
        }

        if (!idle) {
            // thumb + pinky tips glow when they are about to tap
            if (TrackingState.pinchRatio < 0.5f) {
                halo.color = Color.argb(160, 0, 220, 255)
                canvas.drawCircle(px[4], py[4], 8f * d * ps[4], halo)
                canvas.drawCircle(px[20], py[20], 8f * d * ps[20], halo)
            }
            // the index knuckle drives the cursor
            stat.color = TrackingState.color()
            halo.color = Color.argb(70, Color.red(stat.color), Color.green(stat.color), Color.blue(stat.color))
            canvas.drawCircle(px[5], py[5], 10f * d * ps[5], halo)
            canvas.drawCircle(px[5], py[5], 5.5f * d * ps[5], stat)
        }
    }

    private fun drawSeg(canvas: Canvas, s: Int, base: Float, aMul: Float) {
        val a = SEG[s * 2]
        val e = SEG[s * 2 + 1]
        val pr = (ps[a] + ps[e]) * 0.5f
        val t = ((pr - 0.8f) / 0.55f).coerceIn(0f, 1f)
        val col = body(t)
        val wpx = SEG_W[s] * base * pr
        val x0 = px[a]
        val y0 = py[a]
        val x1 = px[e]
        val y1 = py[e]

        glow.color = Color.argb((50 * aMul).toInt(), 40, 215, 255)
        glow.strokeWidth = wpx * 1.9f
        canvas.drawLine(x0, y0, x1, y1, glow)

        // a cylinder: dark rim, lit body, and a highlight pushed towards the light (upper left)
        bone.color = withA((240 * aMul).toInt(), shade(col, 0.55f))
        bone.strokeWidth = wpx
        canvas.drawLine(x0, y0, x1, y1, bone)
        bone.color = withA((240 * aMul).toInt(), shade(col, 0.95f))
        bone.strokeWidth = wpx * 0.7f
        canvas.drawLine(x0, y0, x1, y1, bone)

        var ox = -(y1 - y0)
        var oy = x1 - x0
        val len = hypot(ox, oy)
        if (len > 0.5f) {
            ox /= len
            oy /= len
            if (ox + oy > 0f) {
                ox = -ox
                oy = -oy
            }
            ox *= wpx * 0.16f
            oy *= wpx * 0.16f
            bone.color = Color.argb((130 * aMul).toInt(), 255, 255, 255)
            bone.strokeWidth = wpx * 0.26f
            canvas.drawLine(x0 + ox, y0 + oy, x1 + ox, y1 + oy, bone)
        }
    }

    private fun drawPalm(canvas: Canvas, aMul: Float) {
        path.reset()
        var tsum = 0f
        for (k in 0 until 6) {
            val i = PALM[k]
            if (k == 0) path.moveTo(px[i], py[i]) else path.lineTo(px[i], py[i])
            tsum += ps[i]
        }
        path.close()
        val t = ((tsum / 6f - 0.8f) / 0.55f).coerceIn(0f, 1f)

        // surface normal of the palm -> brightness (light comes from the upper left, in front)
        val ax = rx[5] - rx[0]
        val ay = ry[5] - ry[0]
        val az = rz[5] - rz[0]
        val bx = rx[17] - rx[0]
        val by = ry[17] - ry[0]
        val bz = rz[17] - rz[0]
        var nx = ay * bz - az * by
        var ny = az * bx - ax * bz
        var nz = ax * by - ay * bx
        val nl = max(sqrt(nx * nx + ny * ny + nz * nz), 1e-9f)
        nx /= nl
        ny /= nl
        nz /= nl
        val lit = abs(nx * -0.35f + ny * -0.5f + nz * -0.8f)
        val k = 0.45f + 0.55f * min(lit, 1f)

        fillP.color = withA((215 * aMul).toInt(), shade(body(t), k))
        canvas.drawPath(path, fillP)
        rimP.color = Color.argb((130 * aMul).toInt(), 40, 215, 255)
        canvas.drawPath(path, rimP)
    }
}
