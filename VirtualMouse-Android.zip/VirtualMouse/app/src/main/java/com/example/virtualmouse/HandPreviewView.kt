package com.example.virtualmouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import kotlin.math.hypot

// Pairs of landmark ids that form the hand skeleton.
private val LINKS = intArrayOf(
    0, 1, 1, 2, 2, 3, 3, 4,
    0, 5, 5, 6, 6, 7, 7, 8,
    5, 9, 9, 10, 10, 11, 11, 12,
    9, 13, 13, 14, 14, 15, 15, 16,
    13, 17, 17, 18, 18, 19, 19, 20, 0, 17
)

/** Live hand preview: skeleton, usable area, neutral oval, pinch line, status label. */
class HandPreviewView(c: Context, private val d: Float) : View(c) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(215, 12, 14, 24) }
    private val bone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(235, 120, 220, 255)
        strokeWidth = 2.5f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val joint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        pathEffect = DashPathEffect(floatArrayOf(8f * d, 6f * d), 0f)
    }
    private val oval = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 176, 96, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
    }
    private val pinchLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 3f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11f * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 200, 200, 200)
        textSize = 9.5f * d
    }
    private val stat = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val strip = 28f * d
        val ph = h - strip

        canvas.drawRoundRect(0f, 0f, w, h, 12f * d, 12f * d, bg)

        val m = GestureEngine.MARGIN
        canvas.drawRect(w * m, ph * m, w * (1 - m), ph * (1 - m), box)

        // neutral oval of the open hand (scroll / slide centre)
        val ax = TrackingState.anchorX
        if (ax >= 0f) {
            val cx = ax * w
            val cy = TrackingState.anchorY * ph
            canvas.drawOval(
                cx - GestureEngine.DZ_H * w, cy - GestureEngine.DZ_V * ph,
                cx + GestureEngine.DZ_H * w, cy + GestureEngine.DZ_V * ph, oval
            )
        }

        val lm = TrackingState.landmarks
        if (lm != null) {
            var i = 0
            while (i < LINKS.size) {
                val a = LINKS[i]
                val b = LINKS[i + 1]
                canvas.drawLine(lm[a * 2] * w, lm[a * 2 + 1] * ph, lm[b * 2] * w, lm[b * 2 + 1] * ph, bone)
                i += 2
            }

            // thumb-tip to index-tip line: white = moving, amber = close, cyan = tap
            val palm = hypot(lm[0] - lm[18], lm[1] - lm[19]).coerceAtLeast(1e-6f)
            val ratio = hypot(lm[8] - lm[16], lm[9] - lm[17]) / palm
            pinchLine.color = when {
                ratio < 0.22f -> Color.rgb(0, 200, 255)
                ratio < 0.40f -> Color.rgb(255, 176, 32)
                else -> Color.argb(110, 255, 255, 255)
            }
            canvas.drawLine(lm[8] * w, lm[9] * ph, lm[16] * w, lm[17] * ph, pinchLine)

            for (k in 0 until 21) canvas.drawCircle(lm[k * 2] * w, lm[k * 2 + 1] * ph, 2.5f * d, joint)
            // the index KNUCKLE (landmark 5) is the point that drives the cursor
            stat.color = TrackingState.color()
            canvas.drawCircle(lm[10] * w, lm[11] * ph, 6f * d, stat)
        } else {
            val t = "Show your hand"
            canvas.drawText(t, (w - small.measureText(t)) / 2f, ph / 2f, small)
        }

        canvas.drawText("${TrackingState.fps} fps" + if (TrackingState.has3d) "  3D" else "", w - 62f * d, 13f * d, small)

        // hold progress (Back / Home)
        val pg = TrackingState.progress
        if (pg > 0f) {
            stat.color = TrackingState.color()
            canvas.drawRoundRect(10f * d, h - 6f * d, 10f * d + (w - 20f * d) * pg, h - 3f * d, 2f * d, 2f * d, stat)
        }

        stat.color = TrackingState.color()
        canvas.drawCircle(14f * d, ph + strip / 2f - 2f * d, 5f * d, stat)
        canvas.drawText(TrackingState.label(), 26f * d, ph + strip / 2f + 2f * d, label)
    }
}
