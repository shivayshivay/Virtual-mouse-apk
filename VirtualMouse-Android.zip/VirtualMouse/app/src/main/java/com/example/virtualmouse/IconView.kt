package com.example.virtualmouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Small line icons drawn with the Canvas, tinted with [color]. */
class IconView(c: Context, var type: Int) : View(c) {
    companion object {
        const val HOME = 0
        const val GRID = 1
        const val TUNE = 2
        const val SUN = 3
        const val MOON = 4
        const val PLAY = 5
        const val STOP = 6
    }

    var color = Ui.MUTED
        set(v) {
            field = v
            invalidate()
        }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val cut = Path()
    private val box = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        line.color = color
        fill.color = color
        line.strokeWidth = s * 0.09f
        fun x(v: Float) = ox + v * s
        fun y(v: Float) = oy + v * s
        when (type) {
            HOME -> {
                path.reset()
                path.moveTo(x(0.14f), y(0.50f)); path.lineTo(x(0.50f), y(0.18f)); path.lineTo(x(0.86f), y(0.50f))
                path.moveTo(x(0.24f), y(0.44f)); path.lineTo(x(0.24f), y(0.82f)); path.lineTo(x(0.76f), y(0.82f)); path.lineTo(x(0.76f), y(0.44f))
                canvas.drawPath(path, line)
                canvas.drawLine(x(0.43f), y(0.82f), x(0.43f), y(0.60f), line)
                canvas.drawLine(x(0.57f), y(0.82f), x(0.57f), y(0.60f), line)
            }
            GRID -> {
                val r = s * 0.07f
                for (i in 0..1) for (j in 0..1) {
                    box.set(x(0.18f + i * 0.34f), y(0.18f + j * 0.34f), x(0.18f + i * 0.34f + 0.30f), y(0.18f + j * 0.34f + 0.30f))
                    canvas.drawRoundRect(box, r, r, line)
                }
            }
            TUNE -> {
                canvas.drawLine(x(0.16f), y(0.28f), x(0.84f), y(0.28f), line)
                canvas.drawLine(x(0.16f), y(0.50f), x(0.84f), y(0.50f), line)
                canvas.drawLine(x(0.16f), y(0.72f), x(0.84f), y(0.72f), line)
                fill.color = Ui.CARD
                canvas.drawCircle(x(0.62f), y(0.28f), s * 0.085f, fill)
                canvas.drawCircle(x(0.36f), y(0.50f), s * 0.085f, fill)
                canvas.drawCircle(x(0.68f), y(0.72f), s * 0.085f, fill)
                canvas.drawCircle(x(0.62f), y(0.28f), s * 0.085f, line)
                canvas.drawCircle(x(0.36f), y(0.50f), s * 0.085f, line)
                canvas.drawCircle(x(0.68f), y(0.72f), s * 0.085f, line)
            }
            SUN -> {
                canvas.drawCircle(x(0.5f), y(0.5f), s * 0.17f, line)
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4.0
                    val c0 = cos(a).toFloat()
                    val s0 = sin(a).toFloat()
                    canvas.drawLine(x(0.5f + c0 * 0.28f), y(0.5f + s0 * 0.28f), x(0.5f + c0 * 0.40f), y(0.5f + s0 * 0.40f), line)
                }
            }
            MOON -> {
                path.reset()
                path.addCircle(x(0.5f), y(0.5f), s * 0.32f, Path.Direction.CW)
                cut.reset()
                cut.addCircle(x(0.64f), y(0.40f), s * 0.28f, Path.Direction.CW)
                path.op(cut, Path.Op.DIFFERENCE)
                canvas.drawPath(path, fill)
            }
            PLAY -> {
                path.reset()
                path.moveTo(x(0.30f), y(0.18f)); path.lineTo(x(0.82f), y(0.50f)); path.lineTo(x(0.30f), y(0.82f)); path.close()
                canvas.drawPath(path, fill)
            }
            STOP -> {
                box.set(x(0.22f), y(0.22f), x(0.78f), y(0.78f))
                canvas.drawRoundRect(box, s * 0.10f, s * 0.10f, fill)
            }
        }
    }
}
