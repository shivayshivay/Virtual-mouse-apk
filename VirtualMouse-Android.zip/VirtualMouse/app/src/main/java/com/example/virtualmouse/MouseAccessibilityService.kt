package com.example.virtualmouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class MouseAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MouseAccessibilityService? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var cursor: CursorView? = null
    private var size = 0
    private var active = true

    @Volatile var cx = 0f
    @Volatile var cy = 0f
    @Volatile var screenW = 1080
    @Volatile var screenH = 1920

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        size = (36 * resources.displayMetrics.density).toInt()
        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        refreshScreen()
        cx = screenW / 2f
        cy = screenH / 2f
        val view = CursorView(this)
        cursor = view
        ui.post {
            place()
            wm.addView(view, lp)
        }
    }

    @Suppress("DEPRECATION")
    private fun refreshScreen() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::wm.isInitialized) refreshScreen()
    }

    private fun place() {
        lp.x = (cx - size / 2f).toInt()
        lp.y = (cy - size / 2f).toInt()
    }

    fun moveTo(x: Float, y: Float) {
        cx = x
        cy = y
        ui.post {
            cursor?.let {
                place()
                try { wm.updateViewLayout(it, lp) } catch (_: Exception) {}
            }
        }
    }

    fun setActive(on: Boolean) {
        if (on == active) return
        active = on
        ui.post { cursor?.alpha = if (on) 1f else 0.25f }
    }

    fun tap() {
        gesture(Path().apply { moveTo(cx, cy) }, 60)
    }

    /** dir = +1 swipe finger down, -1 swipe finger up (at the cursor position). */
    fun swipe(dir: Int) {
        val end = (cy + dir * screenH * 0.3f).coerceIn(10f, screenH - 10f)
        gesture(Path().apply { moveTo(cx, cy); lineTo(cx, end) }, 250)
    }

    fun back() { ui.post { performGlobalAction(GLOBAL_ACTION_BACK) } }
    fun home() { ui.post { performGlobalAction(GLOBAL_ACTION_HOME) } }

    private fun gesture(path: Path, ms: Long) {
        ui.post {
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        cursor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cursor = null
        super.onDestroy()
    }

    private class CursorView(c: Context) : View(c) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 255, 51, 102) }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }

        override fun onDraw(canvas: Canvas) {
            val r = width / 2f
            canvas.drawCircle(r, r, r - 3f, fill)
            canvas.drawCircle(r, r, r - 3f, ring)
        }
    }
}
