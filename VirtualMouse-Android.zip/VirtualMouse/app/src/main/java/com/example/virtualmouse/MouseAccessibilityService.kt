package com.example.virtualmouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.max

class MouseAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MouseAccessibilityService? = null
        const val HIDE_AFTER_MS = 1500L   // hand recognised this long -> hide the preview (until the next START)
    }

    private val ui = Handler(Looper.getMainLooper())
    private val cursorFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    // the preview box is touchable so you can drag it
    private val hudFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var hudLp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private var cursor: CursorView? = null
    private var hud: HandPreviewView? = null
    private var vibrator: Vibrator? = null
    private var size = 0
    private var density = 1f
    private var active = true
    private var dragDX = 0f
    private var dragDY = 0f

    @Volatile private var hudMode = 1        // 0 = always on, 1 = auto-hide, 2 = hidden
    @Volatile private var hapticsOn = true
    @Volatile private var hudShown = false
    @Volatile private var autoHidden = false
    @Volatile private var handSince = 0L
    @Volatile private var moveUntil = 0L     // while now < moveUntil the preview is shown so it can be moved

    @Volatile var cx = 0f
    @Volatile var cy = 0f
    @Volatile var screenW = 1080
    @Volatile var screenH = 1920

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        vibrator = getSystemService(Vibrator::class.java)
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        hudMode = prefs.getInt("hud_mode", 1)
        hapticsOn = prefs.getBoolean("haptics", true)

        density = resources.displayMetrics.density
        size = (76 * density).toInt() // room for the joystick drawn around the cursor
        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            cursorFlags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        refreshScreen()
        val sc = hudScale()
        hudLp = WindowManager.LayoutParams(
            (116 * density * sc).toInt(), (183 * density * sc).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            hudFlags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        var hx = prefs.getInt("hud_x", -1)
        var hy = prefs.getInt("hud_y", -1)
        if (hx < 0 || hy < 0) {
            hx = screenW - hudLp.width - (8 * density).toInt()
            hy = (40 * density).toInt()
        }
        hudLp.x = hx
        hudLp.y = hy
        clampHud()

        cx = screenW / 2f
        cy = screenH / 2f
        val cursorView = CursorView(this)
        val hudView = HandPreviewView(this, density)
        hudView.setOnTouchListener { _, e -> hudTouch(e) }
        cursor = cursorView
        hud = hudView
        ui.post {
            place()
            wm.addView(cursorView, lp)
            hudView.alpha = 0f
            hudView.visibility = View.GONE
            wm.addView(hudView, hudLp)
            refreshHud()
        }
    }

    @Suppress("DEPRECATION")
    private fun refreshScreen() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::wm.isInitialized) {
            refreshScreen()
            if (::hudLp.isInitialized) {
                clampHud()
                updateHudLayout()
            }
        }
    }

    private fun place() {
        lp.x = (cx - size / 2f).toInt()
        lp.y = (cy - size / 2f).toInt()
    }

    fun moveTo(x: Float, y: Float) {
        cx = x
        cy = y
        ui.post {
            cursor?.let {
                place()
                try { wm.updateViewLayout(it, lp) } catch (_: Exception) {}
            }
        }
    }

    fun setActive(on: Boolean) {
        if (on == active) return
        active = on
        ui.post { cursor?.alpha = if (on) 1f else 0.35f }
    }

    /** Short vibration so you can feel an action even when the preview is hidden. */
    fun buzz(ms: Long = 25L) {
        if (!hapticsOn) return
        try {
            vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    fun setHapticsEnabled(on: Boolean) {
        hapticsOn = on
    }

    // ---------------- preview box: auto-hide, drag, position, size ----------------

    private fun hudScale(): Float = when (prefs.getInt("hud_scale", 1)) {
        0 -> 0.85f
        2 -> 1.3f
        else -> 1f
    }

    private fun clampHud() {
        hudLp.x = hudLp.x.coerceIn(0, max(0, screenW - hudLp.width))
        hudLp.y = hudLp.y.coerceIn(0, max(0, screenH - hudLp.height))
    }

    private fun updateHudLayout() {
        hud?.let {
            try { wm.updateViewLayout(it, hudLp) } catch (_: Exception) {}
        }
    }

    private fun saveHudPos() {
        prefs.edit().putInt("hud_x", hudLp.x).putInt("hud_y", hudLp.y).apply()
    }

    private fun hudTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragDX = hudLp.x - e.rawX
                dragDY = hudLp.y - e.rawY
                moveUntil = SystemClock.uptimeMillis() + 6000L
            }
            MotionEvent.ACTION_MOVE -> {
                hudLp.x = (e.rawX + dragDX).toInt()
                hudLp.y = (e.rawY + dragDY).toInt()
                clampHud()
                updateHudLayout()
                moveUntil = SystemClock.uptimeMillis() + 6000L
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> saveHudPos()
        }
        return true
    }

    /** Snap the preview box to a corner: 0 = top-left, 1 = top-right, 2 = bottom-left, 3 = bottom-right. */
    fun setHudCorner(i: Int) {
        ui.post {
            val m = (12 * density).toInt()
            val top = (36 * density).toInt()
            val bottom = (56 * density).toInt()
            hudLp.x = if (i == 0 || i == 2) m else screenW - hudLp.width - m
            hudLp.y = if (i < 2) top else screenH - hudLp.height - bottom
            clampHud()
            updateHudLayout()
            saveHudPos()
            showHudForMove(4000L)
        }
    }

    /** 0 = small, 1 = medium, 2 = large. */
    fun setHudScale(i: Int) {
        prefs.edit().putInt("hud_scale", i).apply()
        ui.post {
            val sc = hudScale()
            hudLp.width = (116 * density * sc).toInt()
            hudLp.height = (183 * density * sc).toInt()
            clampHud()
            updateHudLayout()
            saveHudPos()
            showHudForMove(4000L)
        }
    }

    /** Show the preview box for a while (even with the app in front, even when not tracking) so it can be dragged. */
    fun showHudForMove(ms: Long = 12000L) {
        moveUntil = SystemClock.uptimeMillis() + ms
        refreshHud()
        ui.postDelayed({ refreshHud() }, ms + 100L)
    }

    private fun wantHud(): Boolean {
        if (SystemClock.uptimeMillis() < moveUntil) return true
        if (!TrackingState.running || TrackingState.inApp) return false
        return when (hudMode) {
            0 -> true
            2 -> false
            else -> TrackingState.forceHud || !autoHidden
        }
    }

    private fun applyHud(show: Boolean) {
        hudShown = show
        ui.post {
            hud?.let { v ->
                if (show) {
                    v.visibility = View.VISIBLE
                    v.animate().alpha(1f).setDuration(200).start()
                } else {
                    v.animate().alpha(0f).setDuration(250).withEndAction {
                        if (!hudShown) v.visibility = View.GONE
                    }.start()
                }
            }
        }
    }

    /** Called after every camera frame (analysis thread). */
    fun frameUpdate() {
        val now = SystemClock.uptimeMillis()
        if (TrackingState.gesture != "NO_HAND") {
            if (handSince == 0L) handSince = now
            if (!autoHidden && now - handSince > HIDE_AFTER_MS) {
                autoHidden = true // hand recognised: hide the preview and keep it hidden for this session
                buzz(40L)
            }
        } else {
            handSince = 0L // hand lost: do NOT bring the preview back
        }
        val want = wantHud()
        if (want != hudShown) applyHud(want)
        if (hudShown) hud?.postInvalidate()
        cursor?.postInvalidate()
    }

    /** Re-evaluate preview visibility (tracking started/stopped, settings changed, screen changed). */
    fun refreshHud() {
        if (!TrackingState.running) {
            autoHidden = false // a new START shows the preview again until the hand is recognised
            handSince = 0L
        }
        applyHud(wantHud())
        ui.post {
            cursor?.invalidate()
            hud?.invalidate()
        }
    }

    fun setHudMode(mode: Int) {
        hudMode = mode
        autoHidden = false
        handSince = 0L
        refreshHud()
    }

    // ---------------- actions ----------------

    fun tap() {
        gesture(Path().apply { moveTo(cx, cy) }, 60)
    }

    /** Tap at a given point (the engine passes the cursor position from just before the fingers moved). */
    fun tapAt(x: Float, y: Float) {
        gesture(Path().apply { moveTo(x, y) }, 60)
    }

    /**
     * Vertical scroll swipe. dir = +1 finger moves down (see content above), -1 finger moves up.
     * The swipe is centred on the cursor but kept fully on screen, so it never collapses near an edge.
     */
    fun swipe(dir: Int) {
        val len = screenH * 0.35f
        val x = cx.coerceIn(screenW * 0.1f, screenW * 0.9f)
        val mid = cy.coerceIn(len / 2f + 20f, screenH - len / 2f - 20f)
        val y0 = mid - dir * len / 2f
        val y1 = mid + dir * len / 2f
        gesture(Path().apply { moveTo(x, y0); lineTo(x, y1) }, 320)
    }

    /** Page slide. dir = +1 swipe finger right (previous page), -1 swipe finger left (next page). */
    fun swipeH(dir: Int) {
        val y = cy.coerceIn(screenH * 0.15f, screenH * 0.85f)
        val a = screenW * 0.2f
        val b = screenW * 0.8f
        val p = Path().apply {
            if (dir > 0) { moveTo(a, y); lineTo(b, y) } else { moveTo(b, y); lineTo(a, y) }
        }
        gesture(p, 180)
    }

    /** Two-finger pinch around the cursor: spread = zoom in, close = zoom out. */
    fun zoom(zoomIn: Boolean) {
        val near = screenW * 0.06f
        val far = screenW * 0.26f
        val y = cy.coerceIn(screenH * 0.2f, screenH * 0.8f)
        val x = cx.coerceIn(far + 10f, screenW - far - 10f)
        val s = if (zoomIn) near else far
        val e = if (zoomIn) far else near
        val left = Path().apply { moveTo(x - s, y); lineTo(x - e, y) }
        val right = Path().apply { moveTo(x + s, y); lineTo(x + e, y) }
        ui.post {
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(left, 0, 320))
                .addStroke(GestureDescription.StrokeDescription(right, 0, 320))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    /** Media volume up / down (shows Android's volume bar). Needs no extra permission. */
    fun volume(up: Boolean) {
        ui.post {
            val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
            val am = getSystemService(AudioManager::class.java)
            try {
                am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
            } catch (_: Exception) {
                try {
                    am?.adjustSuggestedStreamVolume(dir, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI)
                } catch (_: Exception) {}
            }
        }
    }

    fun back() { ui.post { performGlobalAction(GLOBAL_ACTION_BACK) } }
    fun home() { ui.post { performGlobalAction(GLOBAL_ACTION_HOME) } }

    private fun gesture(path: Path, ms: Long) {
        ui.post {
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        cursor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hud?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cursor = null
        hud = null
        super.onDestroy()
    }

    /**
     * Round cursor. Colour shows the gesture state. A ring fills while you hold a gesture.
     * For scroll / zoom / volume it grows into a small joystick: the dot shows where your hand is
     * relative to the centre, and turns cyan once it is acting.
     */
    private class CursorView(c: Context) : View(c) {
        private val d = c.resources.displayMetrics.density
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 5f * d
            strokeCap = Paint.Cap.ROUND
        }
        private val joyRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(210, 80, 140, 255)
            style = Paint.Style.STROKE
            strokeWidth = 2.5f * d
        }
        private val joyDead = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(130, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * d
        }
        private val joyDot = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = 20f * d
            isFakeBoldText = true
        }
        private val box = RectF()

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val base = 18f * d
            val col = if (TrackingState.running) TrackingState.color() else Color.rgb(255, 51, 102)
            fill.color = (190 shl 24) or (col and 0x00FFFFFF)
            canvas.drawCircle(cx, cy, base - 3f, fill)
            canvas.drawCircle(cx, cy, base - 3f, ring)

            val g = TrackingState.gesture
            val sym = when (g) {
                "ZOOM_IN" -> "+"
                "ZOOM_OUT" -> "\u2212"
                "VOL_UP" -> "\u25B2"
                "VOL_DOWN" -> "\u25BC"
                else -> null
            }
            if (sym != null && TrackingState.running) canvas.drawText(sym, cx, cy + glyph.textSize / 3f, glyph)

            val pg = TrackingState.progress
            if (TrackingState.running && TrackingState.joystick) {
                val r = 34f * d
                canvas.drawCircle(cx, cy, r, joyRing)
                canvas.drawCircle(cx, cy, r * 0.5f, joyDead)
                val armed = g == "PALM" || g == "ZOOM" || g == "ZOOM_IN" || g == "ZOOM_OUT" || g == "VJ"
                if (armed) {
                    val ox = TrackingState.offX.coerceIn(-1.8f, 1.8f)
                    val oy = TrackingState.offY.coerceIn(-1.8f, 1.8f)
                    val acting = max(abs(TrackingState.offX), abs(TrackingState.offY)) > 1f
                    joyDot.color = if (acting) Color.rgb(0, 200, 255) else Color.WHITE
                    canvas.drawCircle(cx + ox * r * 0.5f, cy + oy * r * 0.5f, 5f * d, joyDot)
                }
                if (pg > 0f) {
                    box.set(cx - r, cy - r, cx + r, cy + r)
                    canvas.drawArc(box, -90f, 360f * pg, false, arc)
                }
            } else if (pg > 0f) {
                box.set(cx - base + 2f, cy - base + 2f, cx + base - 2f, cy + base - 2f)
                canvas.drawArc(box, -90f, 360f * pg, false, arc)
            }
        }
    }
}
