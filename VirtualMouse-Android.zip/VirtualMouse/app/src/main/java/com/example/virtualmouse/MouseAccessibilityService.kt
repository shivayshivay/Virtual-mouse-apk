package com.example.virtualmouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot

// Pairs of landmark ids that form the hand skeleton.
private val LINKS = intArrayOf(
    0, 1, 1, 2, 2, 3, 3, 4,
    0, 5, 5, 6, 6, 7, 7, 8,
    5, 9, 9, 10, 10, 11, 11, 12,
    9, 13, 13, 14, 14, 15, 15, 16,
    13, 17, 17, 18, 18, 19, 19, 20, 0, 17
)

class MouseAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MouseAccessibilityService? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private val overlayFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var cursor: CursorView? = null
    private var hud: HudView? = null
    private var size = 0
    private var active = true
    private var hudEnabled = true

    @Volatile var cx = 0f
    @Volatile var cy = 0f
    @Volatile var screenW = 1080
    @Volatile var screenH = 1920

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        size = (36 * d).toInt()
        hudEnabled = getSharedPreferences("vm", MODE_PRIVATE).getBoolean("hud", true)

        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            overlayFlags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val hudLp = WindowManager.LayoutParams(
            (116 * d).toInt(), (183 * d).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            overlayFlags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (8 * d).toInt()
            y = (40 * d).toInt()
        }

        refreshScreen()
        cx = screenW / 2f
        cy = screenH / 2f
        val cursorView = CursorView(this)
        val hudView = HudView(this, d)
        cursor = cursorView
        hud = hudView
        ui.post {
            place()
            wm.addView(cursorView, lp)
            wm.addView(hudView, hudLp)
            refreshHud()
        }
    }

    @Suppress("DEPRECATION")
    private fun refreshScreen() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::wm.isInitialized) refreshScreen()
    }

    private fun place() {
        lp.x = (cx - size / 2f).toInt()
        lp.y = (cy - size / 2f).toInt()
    }

    fun moveTo(x: Float, y: Float) {
        cx = x
        cy = y
        ui.post {
            cursor?.let {
                place()
                try { wm.updateViewLayout(it, lp) } catch (_: Exception) {}
            }
        }
    }

    fun setActive(on: Boolean) {
        if (on == active) return
        active = on
        ui.post { cursor?.alpha = if (on) 1f else 0.35f }
    }

    /** Called after every camera frame: redraw cursor colour and preview. */
    fun frameUpdate() {
        hud?.postInvalidate()
        cursor?.postInvalidate()
    }

    /** Show the preview only while tracking is running and the user wants it. */
    fun refreshHud() {
        ui.post {
            hud?.visibility = if (hudEnabled && TrackingState.running) View.VISIBLE else View.GONE
            hud?.invalidate()
            cursor?.invalidate()
        }
    }

    fun setHudEnabled(on: Boolean) {
        hudEnabled = on
        refreshHud()
    }

    fun tap() {
        gesture(Path().apply { moveTo(cx, cy) }, 60)
    }

    /** dir = +1 swipe finger down, -1 swipe finger up (at the cursor position). */
    fun swipe(dir: Int) {
        val end = (cy + dir * screenH * 0.3f).coerceIn(10f, screenH - 10f)
        gesture(Path().apply { moveTo(cx, cy); lineTo(cx, end) }, 250)
    }

    /** Page slide. dir = +1 swipe finger right (previous page), -1 swipe finger left (next page). */
    fun swipeH(dir: Int) {
        val y = cy.coerceIn(screenH * 0.15f, screenH * 0.85f)
        val a = screenW * 0.2f
        val b = screenW * 0.8f
        val p = Path().apply {
            if (dir > 0) { moveTo(a, y); lineTo(b, y) } else { moveTo(b, y); lineTo(a, y) }
        }
        gesture(p, 180)
    }

    /** Two-finger pinch around the cursor: spread = zoom in, close = zoom out. */
    fun zoom(zoomIn: Boolean) {
        val near = screenW * 0.06f
        val far = screenW * 0.26f
        val y = cy.coerceIn(screenH * 0.2f, screenH * 0.8f)
        val x = cx.coerceIn(far + 10f, screenW - far - 10f)
        val s = if (zoomIn) near else far
        val e = if (zoomIn) far else near
        val left = Path().apply { moveTo(x - s, y); lineTo(x - e, y) }
        val right = Path().apply { moveTo(x + s, y); lineTo(x + e, y) }
        ui.post {
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(left, 0, 320))
                .addStroke(GestureDescription.StrokeDescription(right, 0, 320))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    fun back() { ui.post { performGlobalAction(GLOBAL_ACTION_BACK) } }
    fun home() { ui.post { performGlobalAction(GLOBAL_ACTION_HOME) } }

    private fun gesture(path: Path, ms: Long) {
        ui.post {
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        cursor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hud?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cursor = null
        hud = null
        super.onDestroy()
    }

    /** Round cursor. Colour shows the current gesture state. */
    private class CursorView(c: Context) : View(c) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }

        override fun onDraw(canvas: Canvas) {
            val c = if (TrackingState.running) TrackingState.color() else Color.rgb(255, 51, 102)
            fill.color = (190 shl 24) or (c and 0x00FFFFFF)
            val r = width / 2f
            canvas.drawCircle(r, r, r - 3f, fill)
            canvas.drawCircle(r, r, r - 3f, ring)
        }
    }

    /** Small live preview: skeleton, usable area, neutral oval, pinch line, status label. */
    private class HudView(c: Context, private val d: Float) : View(c) {
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(205, 12, 14, 24) }
        private val bone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(235, 120, 220, 255)
            strokeWidth = 2.5f * d
            strokeCap = Paint.Cap.ROUND
        }
        private val joint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(150, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * d
            pathEffect = DashPathEffect(floatArrayOf(8f * d, 6f * d), 0f)
        }
        private val oval = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(230, 176, 96, 255)
            style = Paint.Style.STROKE
            strokeWidth = 2f * d
        }
        private val pinchLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 3f * d
            strokeCap = Paint.Cap.ROUND
        }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 11f * d
            typeface = Typeface.DEFAULT_BOLD
        }
        private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(210, 200, 200, 200)
            textSize = 9.5f * d
        }
        private val stat = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val strip = 28f * d
            val ph = h - strip

            canvas.drawRoundRect(0f, 0f, w, h, 12f * d, 12f * d, bg)

            val m = GestureEngine.MARGIN
            canvas.drawRect(w * m, ph * m, w * (1 - m), ph * (1 - m), box)

            // neutral oval of the open hand (scroll / slide centre)
            val ax = TrackingState.anchorX
            if (ax >= 0f) {
                val cx = ax * w
                val cy = TrackingState.anchorY * ph
                canvas.drawOval(
                    cx - GestureEngine.DZ_H * w, cy - GestureEngine.DZ_V * ph,
                    cx + GestureEngine.DZ_H * w, cy + GestureEngine.DZ_V * ph, oval
                )
            }

            val lm = TrackingState.landmarks
            if (lm != null) {
                var i = 0
                while (i < LINKS.size) {
                    val a = LINKS[i]
                    val b = LINKS[i + 1]
                    canvas.drawLine(lm[a * 2] * w, lm[a * 2 + 1] * ph, lm[b * 2] * w, lm[b * 2 + 1] * ph, bone)
                    i += 2
                }

                // thumb-tip to index-tip line: white = moving, amber = close, cyan = tap
                val palm = hypot(lm[0] - lm[18], lm[1] - lm[19]).coerceAtLeast(1e-6f)
                val ratio = hypot(lm[8] - lm[16], lm[9] - lm[17]) / palm
                pinchLine.color = when {
                    ratio < 0.22f -> Color.rgb(0, 200, 255)
                    ratio < 0.40f -> Color.rgb(255, 176, 32)
                    else -> Color.argb(110, 255, 255, 255)
                }
                canvas.drawLine(lm[8] * w, lm[9] * ph, lm[16] * w, lm[17] * ph, pinchLine)

                for (k in 0 until 21) canvas.drawCircle(lm[k * 2] * w, lm[k * 2 + 1] * ph, 2.5f * d, joint)
                // the index KNUCKLE (landmark 5) is the point that drives the cursor
                stat.color = TrackingState.color()
                canvas.drawCircle(lm[10] * w, lm[11] * ph, 6f * d, stat)
            } else {
                val t = "Show your hand"
                canvas.drawText(t, (w - small.measureText(t)) / 2f, ph / 2f, small)
            }

            canvas.drawText("${TrackingState.fps} fps", w - 40f * d, 13f * d, small)

            // hold progress (Back / Home)
            val pg = TrackingState.progress
            if (pg > 0f) {
                stat.color = TrackingState.color()
                canvas.drawRoundRect(10f * d, h - 6f * d, 10f * d + (w - 20f * d) * pg, h - 3f * d, 2f * d, 2f * d, stat)
            }

            stat.color = TrackingState.color()
            canvas.drawCircle(14f * d, ph + strip / 2f - 2f * d, 5f * d, stat)
            canvas.drawText(TrackingState.label(), 26f * d, ph + strip / 2f + 2f * d, label)
        }
    }
}
