package com.example.virtualmouse

import android.graphics.Color
import android.os.SystemClock

/** Shared live state: what the camera sees and which gesture was recognised. */
object TrackingState {
    @Volatile var running = false
    @Volatile var gesture = "NO_HAND"
    @Volatile var landmarks: FloatArray? = null // 21 points as x,y pairs (0..1), mirrored
    @Volatile var fps = 0
    @Volatile var smooth = 5f                  // cursor smoothing (2 = fast, 12 = steady)
    @Volatile var anchorX = -1f                // neutral point of the open hand (-1 = none)
    @Volatile var anchorY = -1f
    @Volatile var progress = 0f                // 0..1 hold progress for Back / Home
    @Volatile var lastEvent = ""
    @Volatile var lastEventTime = 0L

    fun event(name: String) {
        lastEvent = name
        lastEventTime = SystemClock.uptimeMillis()
    }

    fun eventRecent(name: String, ms: Long = 2500L): Boolean =
        lastEvent == name && SystemClock.uptimeMillis() - lastEventTime < ms

    private fun flash(): String? =
        if (lastEvent.isNotEmpty() && SystemClock.uptimeMillis() - lastEventTime < 700L) lastEvent else null

    fun label(): String {
        flash()?.let { return it.replace('_', ' ') + "!" }
        return when (gesture) {
            "MOVE" -> "Moving"
            "PINCH" -> "Pinch (tap)"
            "READY" -> "Hand found"
            "PAUSED" -> "Paused (fist)"
            "PALM_WAIT" -> "Hold still..."
            "PALM" -> "Scroll / slide"
            "ZOOM" -> "Zoom mode"
            "ZOOM_IN" -> "Zooming in"
            "ZOOM_OUT" -> "Zooming out"
            "BACK_HOLD" -> "Hold: Back"
            "HOME_HOLD" -> "Hold: Home"
            else -> "No hand"
        }
    }

    fun color(): Int {
        if (flash() != null) return Color.rgb(0, 200, 255)
        return when (gesture) {
            "MOVE" -> Color.rgb(34, 204, 102)
            "PINCH", "BACK_HOLD", "HOME_HOLD" -> Color.rgb(255, 140, 66)
            "READY" -> Color.rgb(255, 176, 32)
            "PAUSED" -> Color.rgb(150, 150, 150)
            "PALM_WAIT", "PALM" -> Color.rgb(80, 140, 255)
            "ZOOM", "ZOOM_IN", "ZOOM_OUT" -> Color.rgb(176, 96, 255)
            else -> Color.rgb(255, 51, 102)
        }
    }

    fun statusLine(): String = if (gesture == "NO_HAND") "no hand seen" else label()

    /** Did the user perform the gesture a tutorial step is waiting for? */
    fun matches(target: String): Boolean {
        if (!running) return false
        return when (target) {
            "HAND" -> gesture != "NO_HAND"
            "MOVE" -> gesture == "MOVE"
            "PAUSED" -> gesture == "PAUSED"
            "SCROLL" -> eventRecent("SCROLL_UP") || eventRecent("SCROLL_DOWN")
            "SWIPE" -> eventRecent("PAGE_NEXT") || eventRecent("PAGE_PREV")
            "ZOOM" -> eventRecent("ZOOM_IN") || eventRecent("ZOOM_OUT")
            else -> eventRecent(target) // TAP, BACK, HOME
        }
    }
}
