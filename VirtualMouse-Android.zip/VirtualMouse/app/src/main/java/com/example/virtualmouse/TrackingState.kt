package com.example.virtualmouse

import android.graphics.Color
import android.os.SystemClock

/** Shared live state: what the camera sees and which gesture was recognised. */
object TrackingState {
    @Volatile var running = false
    @Volatile var gesture = "NO_HAND"          // NO_HAND, READY, MOVE, SCROLL, PAUSED
    @Volatile var landmarks: FloatArray? = null // 21 points as x,y pairs (0..1), mirrored
    @Volatile var fps = 0
    @Volatile var lastEvent = ""               // TAP, BACK, HOME, SCROLL
    @Volatile var lastEventTime = 0L

    fun event(name: String) {
        lastEvent = name
        lastEventTime = SystemClock.uptimeMillis()
    }

    fun eventRecent(name: String, ms: Long = 2500L): Boolean =
        lastEvent == name && SystemClock.uptimeMillis() - lastEventTime < ms

    private fun flash(): String? =
        if (lastEvent.isNotEmpty() && SystemClock.uptimeMillis() - lastEventTime < 700L) lastEvent else null

    fun label(): String {
        flash()?.let { return "$it!" }
        return when (gesture) {
            "MOVE" -> "Moving"
            "READY" -> "Raise index"
            "PAUSED" -> "Paused (fist)"
            "SCROLL" -> "Scroll mode"
            else -> "No hand"
        }
    }

    fun color(): Int {
        if (flash() != null) return Color.rgb(0, 200, 255)
        return when (gesture) {
            "MOVE" -> Color.rgb(34, 204, 102)
            "READY" -> Color.rgb(255, 176, 32)
            "PAUSED" -> Color.rgb(150, 150, 150)
            "SCROLL" -> Color.rgb(80, 140, 255)
            else -> Color.rgb(255, 51, 102)
        }
    }

    fun statusLine(): String = if (gesture == "NO_HAND") "no hand seen" else label()

    /** Did the user perform the gesture a tutorial step is waiting for? */
    fun matches(target: String): Boolean {
        if (!running) return false
        return when (target) {
            "HAND" -> gesture != "NO_HAND"
            "MOVE" -> gesture == "MOVE"
            "SCROLL" -> gesture == "SCROLL" || eventRecent("SCROLL")
            "PAUSED" -> gesture == "PAUSED"
            else -> eventRecent(target)
        }
    }
}
