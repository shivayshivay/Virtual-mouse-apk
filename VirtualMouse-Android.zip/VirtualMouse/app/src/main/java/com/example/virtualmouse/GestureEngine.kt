package com.example.virtualmouse

import android.os.SystemClock
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/** Turns 21 hand landmarks into cursor moves, taps, scroll, page slides, zoom, Back and Home. */
class GestureEngine {

    companion object {
        const val MARGIN = 0.15f              // unused border of the camera view
        private const val PINCH = 0.30f       // thumb-finger pinch threshold (relative to palm size)
        private const val OK_PINCH = 0.35f    // thumb+index touching = "OK sign" (zoom mode)
        private const val ACTION_COOLDOWN = 600L
        private const val FLICK_WINDOW = 300L // a flick must cover the distance within this time
        private const val FLICK_COOLDOWN = 500L
        private const val SCROLL_STEP = 0.06f // vertical flick distance (fraction of frame)
        private const val SWIPE_STEP = 0.07f  // horizontal flick distance
        private const val ZOOM_DWELL = 400L   // hold the OK sign this long before zoom is armed
        private const val ZOOM_COOLDOWN = 700L
        private const val ZOOM_IN_RATIO = 1.18f   // hand 18% closer than at start
        private const val ZOOM_OUT_RATIO = 0.85f  // hand 15% farther than at start
    }

    private var sx = -1f
    private var sy = -1f
    private var anchorSet = false
    private var anchorX = 0f
    private var anchorY = 0f
    private var anchorT = 0L
    private var lastAction = 0L
    private var lastFlick = 0L
    private var lastZoom = 0L
    private var zoomBase = -1f
    private var zoomSince = 0L

    fun update(lm: List<NormalizedLandmark>?) {
        val svc = MouseAccessibilityService.instance ?: return
        if (lm == null) {
            anchorSet = false
            zoomBase = -1f
            TrackingState.landmarks = null
            TrackingState.gesture = "NO_HAND"
            svc.frameUpdate()
            return
        }
        val pts = FloatArray(42)
        for (i in 0 until 21) {
            pts[i * 2] = lm[i].x()
            pts[i * 2 + 1] = lm[i].y()
        }
        TrackingState.landmarks = pts

        val now = SystemClock.uptimeMillis()
        fun d(a: Int, b: Int) = hypot(lm[a].x() - lm[b].x(), lm[a].y() - lm[b].y())

        val palm = max(d(0, 9), 1e-6f)
        val up = booleanArrayOf(
            lm[8].y() < lm[6].y(),    // index
            lm[12].y() < lm[10].y(),  // middle
            lm[16].y() < lm[14].y(),  // ring
            lm[20].y() < lm[18].y()   // pinky
        )
        svc.setActive(up.any())

        // ---- ZOOM: OK sign (thumb touches index, other three fingers up) ----
        val ok = d(4, 8) / palm < OK_PINCH && up[1] && up[2] && up[3]
        if (ok) {
            anchorSet = false
            val w = max(d(5, 17), 1e-6f) // palm width: grows as the hand nears the camera
            if (zoomBase < 0f) {
                zoomBase = w
                zoomSince = now
            } else if (now - zoomSince < ZOOM_DWELL) {
                zoomBase += (w - zoomBase) * 0.3f
            }
            var g = "ZOOM"
            if (now - zoomSince >= ZOOM_DWELL) {
                val ratio = w / zoomBase
                if (ratio > ZOOM_IN_RATIO) g = "ZOOM_IN" else if (ratio < ZOOM_OUT_RATIO) g = "ZOOM_OUT"
                if (g != "ZOOM" && now - lastZoom > ZOOM_COOLDOWN) {
                    svc.zoom(g == "ZOOM_IN")
                    TrackingState.event(g)
                    lastZoom = now
                }
            }
            TrackingState.gesture = g
            svc.frameUpdate()
            return
        }
        zoomBase = -1f

        when {
            // Fist: pause
            up.none { it } -> {
                anchorSet = false
                TrackingState.gesture = "PAUSED"
            }

            // Open palm: quick flick up/down = scroll, left/right = slide pages
            up.all { it } -> {
                TrackingState.gesture = "SCROLL"
                val x = lm[9].x()
                val y = lm[9].y()
                if (!anchorSet || now - anchorT > FLICK_WINDOW) {
                    anchorX = x
                    anchorY = y
                    anchorT = now
                    anchorSet = true
                }
                val dx = x - anchorX
                val dy = y - anchorY
                if (now - lastFlick > FLICK_COOLDOWN) {
                    if (abs(dx) > abs(dy) && abs(dx) > SWIPE_STEP) {
                        svc.swipeH(if (dx > 0) 1 else -1)
                        TrackingState.event(if (dx > 0) "SWIPE_RIGHT" else "SWIPE_LEFT")
                        lastFlick = now
                        anchorSet = false
                    } else if (abs(dy) > abs(dx) && abs(dy) > SCROLL_STEP) {
                        svc.swipe(if (dy > 0) 1 else -1)
                        TrackingState.event("SCROLL")
                        lastFlick = now
                        anchorSet = false
                    }
                }
            }

            // Pointer mode
            else -> {
                anchorSet = false
                val action = when {
                    d(4, 12) / palm < PINCH -> 1
                    d(4, 16) / palm < PINCH -> 2
                    d(4, 20) / palm < PINCH -> 3
                    else -> 0
                }
                if (action != 0) {
                    // cursor stays frozen while pinching
                    TrackingState.gesture = "READY"
                    if (now - lastAction > ACTION_COOLDOWN) {
                        when (action) {
                            1 -> { svc.tap(); TrackingState.event("TAP") }
                            2 -> { TrackingState.event("BACK"); svc.back() }
                            else -> { TrackingState.event("HOME"); svc.home() }
                        }
                        lastAction = now
                    }
                } else if (up[0]) {
                    TrackingState.gesture = "MOVE"
                    val span = 1f - 2f * MARGIN
                    val tx = ((lm[8].x() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenW
                    val ty = ((lm[8].y() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenH
                    if (sx < 0) {
                        sx = svc.cx
                        sy = svc.cy
                    }
                    val k = TrackingState.smooth
                    sx += (tx - sx) / k
                    sy += (ty - sy) / k
                    svc.moveTo(sx, sy)
                } else {
                    TrackingState.gesture = "READY"
                }
            }
        }
        svc.frameUpdate()
    }
}
