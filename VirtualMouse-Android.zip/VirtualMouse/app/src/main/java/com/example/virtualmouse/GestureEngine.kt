package com.example.virtualmouse

import android.os.SystemClock
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * Hand pose -> action.
 *
 *  index only up ................ MOVE   (cursor follows the index KNUCKLE, so pinching can't shake it)
 *  thumb touches index tip ...... TAP    (only right after pointing, others folded)
 *  open hand .................... SCROLL / PAGE SLIDE (hold still, then move away from the neutral oval)
 *  OK sign (thumb+index, 3 up) .. ZOOM   (hand toward / away from camera)
 *  index+middle up, hold ........ BACK
 *  index+middle+ring up, hold ... HOME
 *  fist ......................... PAUSE
 */
class GestureEngine {

    companion object {
        const val MARGIN = 0.20f          // unused border of the camera view
        const val DZ_H = 0.09f            // neutral zone (half-width) for page slide
        const val DZ_V = 0.07f            // neutral zone (half-height) for scroll
        private const val EXT = 1.10f     // finger counts as "up" if tip is this much farther from wrist than its middle joint
        private const val OK_PINCH = 0.35f
        private const val TAP_ON = 0.22f      // thumb-index distance (palm units) that fires a tap
        private const val TAP_OFF = 0.36f     // must open beyond this before the next tap
        private const val TAP_APPROACH = 0.40f // cursor freezes inside this distance
        private const val TAP_WINDOW = 700L   // a tap must follow pointing within this time
        private const val TAP_COOLDOWN = 350L
        private const val PALM_DWELL = 400L   // hold the open hand still this long to set the neutral point
        private const val SLIDE_COOLDOWN = 900L
        private const val HOLD_MS = 600L      // hold time for Back / Home
        private const val HOLD_COOLDOWN = 1500L
        private const val ZOOM_DWELL = 400L
        private const val ZOOM_COOLDOWN = 700L
        private const val ZOOM_IN_RATIO = 1.18f
        private const val ZOOM_OUT_RATIO = 0.85f
    }

    private var sx = -1f
    private var sy = -1f
    private var pinchOn = false
    private var lastPointer = 0L
    private var lastTap = 0L
    private var palmSince = -1L
    private var anchorX = 0f
    private var anchorY = 0f
    private var lastRepeat = 0L
    private var holdPose = ""
    private var holdSince = 0L
    private var holdFired = false
    private var lastHold = 0L
    private var zoomBase = -1f
    private var zoomSince = 0L
    private var lastZoom = 0L

    private fun leavePalm() {
        palmSince = -1L
        TrackingState.anchorX = -1f
    }

    private fun leaveHold() {
        holdPose = ""
        holdFired = false
        TrackingState.progress = 0f
    }

    fun update(lm: List<NormalizedLandmark>?) {
        val svc = MouseAccessibilityService.instance ?: return
        if (lm == null) {
            leavePalm()
            leaveHold()
            zoomBase = -1f
            pinchOn = false
            TrackingState.landmarks = null
            TrackingState.gesture = "NO_HAND"
            svc.frameUpdate()
            return
        }
        val pts = FloatArray(42)
        for (i in 0 until 21) {
            pts[i * 2] = lm[i].x()
            pts[i * 2 + 1] = lm[i].y()
        }
        TrackingState.landmarks = pts

        val now = SystemClock.uptimeMillis()
        fun d(a: Int, b: Int) = hypot(lm[a].x() - lm[b].x(), lm[a].y() - lm[b].y())
        // A finger is "up" when its tip is clearly farther from the wrist than its middle joint.
        // This works at any hand angle (the old test only worked with an upright hand).
        fun ext(tip: Int, pip: Int) = d(tip, 0) > d(pip, 0) * EXT

        val palm = max(d(0, 9), 1e-6f)
        val e = booleanArrayOf(ext(8, 6), ext(12, 10), ext(16, 14), ext(20, 18)) // index, middle, ring, pinky
        val pinch = d(4, 8) / palm                                                // thumb tip to index tip
        val folded = !e[1] && !e[2] && !e[3]
        val pointerPose = e[0] && folded
        if (pinch > TAP_OFF) pinchOn = false
        svc.setActive(e.any() || pinchOn)

        // ---- ZOOM: OK sign (thumb touches index, other three fingers up) ----
        if (pinch < OK_PINCH && e[1] && e[2] && e[3]) {
            leavePalm()
            leaveHold()
            val w = max(d(5, 17), 1e-6f) // palm width: grows as the hand nears the camera
            if (zoomBase < 0f) {
                zoomBase = w
                zoomSince = now
            } else if (now - zoomSince < ZOOM_DWELL) {
                zoomBase += (w - zoomBase) * 0.3f
            }
            var g = "ZOOM"
            if (now - zoomSince >= ZOOM_DWELL) {
                val ratio = w / zoomBase
                if (ratio > ZOOM_IN_RATIO) g = "ZOOM_IN" else if (ratio < ZOOM_OUT_RATIO) g = "ZOOM_OUT"
                if (g != "ZOOM" && now - lastZoom > ZOOM_COOLDOWN) {
                    svc.zoom(g == "ZOOM_IN")
                    TrackingState.event(g)
                    lastZoom = now
                }
            }
            TrackingState.gesture = g
            svc.frameUpdate()
            return
        }
        zoomBase = -1f

        // ---- TAP: thumb touches index fingertip while pointing (other fingers folded) ----
        if (pointerPose) lastPointer = now
        val indexOut = d(8, 0) > d(5, 0) * 1.15f
        if (folded && pinch < TAP_APPROACH && (pinchOn || (indexOut && now - lastPointer < TAP_WINDOW))) {
            leavePalm()
            leaveHold()
            TrackingState.gesture = "PINCH" // cursor stays frozen
            if (!pinchOn && pinch < TAP_ON) {
                pinchOn = true
                if (now - lastTap > TAP_COOLDOWN) {
                    svc.tap()
                    TrackingState.event("TAP")
                    lastTap = now
                }
            }
            svc.frameUpdate()
            return
        }

        val n = e.count { it }
        when {
            // Fist: pause
            n == 0 -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "PAUSED"
            }

            // Open hand: hold still to set a neutral point, then move away from it
            n == 4 -> {
                leaveHold()
                val x = lm[9].x()
                val y = lm[9].y()
                if (palmSince < 0) {
                    palmSince = now
                    anchorX = x
                    anchorY = y
                }
                TrackingState.anchorX = anchorX
                TrackingState.anchorY = anchorY
                if (now - palmSince < PALM_DWELL) {
                    anchorX += (x - anchorX) * 0.3f
                    anchorY += (y - anchorY) * 0.3f
                    TrackingState.gesture = "PALM_WAIT"
                } else {
                    TrackingState.gesture = "PALM"
                    val dx = x - anchorX
                    val dy = y - anchorY
                    val rx = abs(dx) / DZ_H
                    val ry = abs(dy) / DZ_V
                    if (max(rx, ry) > 1f) {
                        if (ry >= rx) {
                            // farther from the neutral point = faster scrolling
                            val cooldown = (650f - 300f * (ry - 1f).coerceIn(0f, 1f)).toLong()
                            if (now - lastRepeat > cooldown) {
                                if (dy < 0) {
                                    svc.swipe(1) // hand up -> see content above
                                    TrackingState.event("SCROLL_UP")
                                } else {
                                    svc.swipe(-1)
                                    TrackingState.event("SCROLL_DOWN")
                                }
                                lastRepeat = now
                            }
                        } else if (now - lastRepeat > SLIDE_COOLDOWN) {
                            if (dx > 0) {
                                svc.swipeH(-1) // hand to your right -> next page
                                TrackingState.event("PAGE_NEXT")
                            } else {
                                svc.swipeH(1)
                                TrackingState.event("PAGE_PREV")
                            }
                            lastRepeat = now
                        }
                    }
                }
            }

            // Pointer: index only
            pointerPose -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "MOVE"
                val span = 1f - 2f * MARGIN
                val tx = ((lm[5].x() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenW
                val ty = ((lm[5].y() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenH
                if (sx < 0) {
                    sx = svc.cx
                    sy = svc.cy
                }
                val dist = hypot(tx - sx, ty - sy)
                if (dist > svc.screenW * 0.004f) { // tiny hand tremor is ignored
                    // far from target: catch up faster; near target: stay smooth
                    val k = if (dist > svc.screenW * 0.15f) max(1.5f, TrackingState.smooth / 3f) else TrackingState.smooth
                    sx += (tx - sx) / k
                    sy += (ty - sy) / k
                    svc.moveTo(sx, sy)
                }
            }

            // V sign held: Back
            e[0] && e[1] && !e[2] && !e[3] -> hold("BACK", now, svc)

            // Three fingers held: Home
            e[0] && e[1] && e[2] && !e[3] -> hold("HOME", now, svc)

            else -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "READY"
            }
        }
        svc.frameUpdate()
    }

    private fun hold(pose: String, now: Long, svc: MouseAccessibilityService) {
        leavePalm()
        if (holdPose != pose) {
            holdPose = pose
            holdSince = now
            holdFired = false
        }
        val prog = ((now - holdSince).toFloat() / HOLD_MS).coerceIn(0f, 1f)
        TrackingState.progress = if (holdFired) 0f else prog
        TrackingState.gesture = pose + "_HOLD"
        if (!holdFired && prog >= 1f && now - lastHold > HOLD_COOLDOWN) {
            holdFired = true
            lastHold = now
            TrackingState.event(pose)
            if (pose == "BACK") svc.back() else svc.home()
        }
    }
}
