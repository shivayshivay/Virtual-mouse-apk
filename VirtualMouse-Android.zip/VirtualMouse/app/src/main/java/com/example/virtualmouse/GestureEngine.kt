package com.example.virtualmouse

import android.os.SystemClock
import com.google.mediapipe.tasks.components.containers.Landmark
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/**
 * One Euro filter: smooths hard when the hand is still (no jitter) and barely at all when it
 * moves fast (no lag). This is the "time" dimension of the tracking.
 */
private class OneEuro {
    private var init = false
    private var xPrev = 0f
    private var dxPrev = 0f
    private var tPrev = 0L

    fun start(x: Float, t: Long) {
        init = true
        xPrev = x
        dxPrev = 0f
        tPrev = t
    }

    fun filter(x: Float, t: Long, minCutoff: Float, beta: Float): Float {
        if (!init) {
            start(x, t)
            return x
        }
        val dt = max((t - tPrev) / 1000f, 0.001f)
        tPrev = t
        dxPrev += alpha(dt, 1f) * ((x - xPrev) / dt - dxPrev)
        val cutoff = minCutoff + beta * abs(dxPrev)
        xPrev += alpha(dt, cutoff) * (x - xPrev)
        return xPrev
    }

    private fun alpha(dt: Float, cutoff: Float): Float {
        val tau = 1f / (2f * PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }
}

/**
 * Hand pose -> action, using real 3D hand points plus motion over time.
 *
 *  index up (middle / ring not up) MOVE   RELATIVE, like a mouse
 *  ... flick thumb away, touch middle TAP
 *  open hand ..................... SCROLL / PAGE SLIDE  \  "hold still until the ring fills,
 *  pinky only up ................. VOLUME               /   then move your hand from the centre"
 *  thumbs-up / thumbs-down ....... VOLUME (also works)
 *  fist (held briefly) ........... TASK DONE (resets everything, waits for the next command)
 *  index+middle up, hold ......... BACK
 *  index+middle+ring up, hold .... HOME
 *
 * Against accidental gestures every finger is judged UP, DOWN or UNSURE. Special poses need every
 * finger sure; in-between hands do nothing. A pose must repeat for several frames, a hand that has
 * just appeared is ignored for half a second, and most actions need a deliberate hold.
 */
class GestureEngine {

    companion object {
        const val DZ_H = 0.09f            // neutral zone (half-width) for page slide
        const val DZ_V = 0.07f            // neutral zone (half-height) for scroll / volume
        private const val TAP_COOLDOWN = 300L
        private const val TAP_GRACE = 150L       // the index finger may flicker this long while the thumb closes
        private const val TAP_ARM_WINDOW = 1500L // after the thumb was clearly open, a touch within this time taps
        private const val JOY_DWELL = 400L
        private const val SLIDE_COOLDOWN = 900L
        private const val HOLD_MS = 700L
        private const val HOLD_COOLDOWN = 1500L
        private const val VOL_DWELL = 450L
        private const val VOL_REPEAT = 450L
        private const val FIST_HOLD = 300L
        private const val REARM_MS = 350L        // after a fist, ignore the next hand shapes briefly
        private const val ENTRY_GRACE = 500L     // a hand that just appeared is ignored this long
    }

    private val p3 = FloatArray(63)                 // 21 points x (x, y, z): metres if world landmarks exist
    private val st = IntArray(4)                    // index, middle, ring, pinky: 1 up, 0 down, -1 unsure
    private var pose = "NONE"
    private var prevPose = "NONE"
    private var cand = "NONE"
    private var candN = 0
    private var lostSince = 0L
    private var seenSince = 0L
    private var flipX = 1f
    private var flipY = 1f

    // relative cursor
    private val euX = OneEuro()
    private val euY = OneEuro()
    private var relInit = false
    private var prevPx = 0f
    private var prevPy = 0f
    private var curX = 0f
    private var curY = 0f
    private val hx = FloatArray(10)
    private val hy = FloatArray(10)
    private val ht = LongArray(10)
    private var hi = 0
    private var tapX = 0f
    private var tapY = 0f

    // tap (thumb + middle)
    private var pinchM = 1f
    private var pinchInit = false
    private var armedUntil = 0L
    private var lastTapPose = 0L
    private var lastTap = 0L

    // joystick controls (open hand, pinky)
    private var joyOwner = ""
    private var palmSince = -1L
    private var anchorX = 0f
    private var anchorY = 0f
    private var lastRepeat = 0L

    private var holdPose = ""
    private var holdSince = 0L
    private var holdFired = false
    private var lastHold = 0L
    private var volSince = 0L
    private var lastVol = 0L
    private var fistSince = 0L
    private var doneFired = false
    private var rearmUntil = 0L

    private fun d3(a: Int, b: Int): Float {
        val dx = p3[a * 3] - p3[b * 3]
        val dy = p3[a * 3 + 1] - p3[b * 3 + 1]
        val dz = p3[a * 3 + 2] - p3[b * 3 + 2]
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    /** Cosine of the angle between bone (m->p) and bone (p->t): 1 = straight finger, <0.5 = bent. */
    private fun straight(m: Int, p: Int, t: Int): Float {
        val ux = p3[p * 3] - p3[m * 3]
        val uy = p3[p * 3 + 1] - p3[m * 3 + 1]
        val uz = p3[p * 3 + 2] - p3[m * 3 + 2]
        val wx = p3[t * 3] - p3[p * 3]
        val wy = p3[t * 3 + 1] - p3[p * 3 + 1]
        val wz = p3[t * 3 + 2] - p3[p * 3 + 2]
        val lu = sqrt(ux * ux + uy * uy + uz * uz)
        val lw = sqrt(wx * wx + wy * wy + wz * wz)
        if (lu < 1e-6f || lw < 1e-6f) return 1f
        return (ux * wx + uy * wy + uz * wz) / (lu * lw)
    }

    private fun fmt(v: Float): String {
        val i = (v * 100f).toInt()
        return "${i / 100}.${(abs(i) % 100).toString().padStart(2, '0')}"
    }

    private fun leavePalm() {
        palmSince = -1L
        joyOwner = ""
        TrackingState.joystick = false
        TrackingState.anchorX = -1f
        TrackingState.offX = 0f
        TrackingState.offY = 0f
    }

    private fun leaveHold() {
        holdPose = ""
        holdFired = false
        TrackingState.progress = 0f
    }

    /**
     * Shared control: hold the pose still until the ring fills (sets the centre), then move the hand
     * away from the centre. Returns true once armed. offX / offY (in dead-zone units) drive the cursor joystick.
     */
    private fun joyArm(now: Long, x: Float, y: Float, owner: String, waitName: String, activeName: String): Boolean {
        if (joyOwner != owner) {
            palmSince = -1L
            joyOwner = owner
        }
        if (palmSince < 0) {
            palmSince = now
            anchorX = x
            anchorY = y
        }
        TrackingState.joystick = true
        TrackingState.anchorX = anchorX
        TrackingState.anchorY = anchorY
        if (now - palmSince < JOY_DWELL) {
            anchorX += (x - anchorX) * 0.3f
            anchorY += (y - anchorY) * 0.3f
            TrackingState.gesture = waitName
            TrackingState.progress = (now - palmSince).toFloat() / JOY_DWELL // ring fills around the cursor
            TrackingState.offX = 0f
            TrackingState.offY = 0f
            return false
        }
        TrackingState.gesture = activeName
        TrackingState.progress = 0f
        return true
    }

    private fun remember(x: Float, y: Float, t: Long) {
        hi = (hi + 1) % 10
        hx[hi] = x
        hy[hi] = y
        ht[hi] = t
    }

    /** The click goes where the cursor was ~120 ms ago, so the hand's own motion while closing the fingers can't shift it. */
    private fun latch(now: Long, svc: MouseAccessibilityService) {
        var best = -1
        var bestT = -1L
        for (i in 0 until 10) {
            if (ht[i] != 0L && ht[i] <= now - 120L && ht[i] > bestT) {
                best = i
                bestT = ht[i]
            }
        }
        if (best >= 0 && now - bestT < 500L) {
            tapX = hx[best]
            tapY = hy[best]
        } else {
            tapX = svc.cx
            tapY = svc.cy
        }
    }

    /** Fist = "this task is finished": forget everything in progress so the next command starts clean. */
    private fun resetSession() {
        leavePalm()
        leaveHold()
        armedUntil = 0L
        relInit = false
        volSince = 0L
        for (i in 0 until 10) ht[i] = 0L
    }

    private fun fire(svc: MouseAccessibilityService, name: String, ms: Long) {
        TrackingState.event(name)
        svc.buzz(ms)
    }

    fun update(lm: List<NormalizedLandmark>?, world: List<Landmark>? = null) {
        val svc = MouseAccessibilityService.instance ?: return
        val now = SystemClock.uptimeMillis()

        if (lm == null) {
            if (lostSince == 0L) lostSince = now
            val lost = now - lostSince
            TrackingState.hint = when {
                lost > 8000L -> "Camera covered?"
                lost > 3000L -> "Add more light"
                else -> ""
            }
            leavePalm()
            leaveHold()
            armedUntil = 0L
            relInit = false
            pinchInit = false
            volSince = 0L
            seenSince = 0L
            fistSince = 0L
            pose = "NONE"
            prevPose = "NONE"
            cand = "NONE"
            candN = 0
            TrackingState.landmarks = null
            TrackingState.points3d = null
            TrackingState.gesture = "NO_HAND"
            svc.frameUpdate()
            return
        }
        lostSince = 0L
        if (seenSince == 0L) seenSince = now

        val pts = FloatArray(42)
        for (i in 0 until 21) {
            pts[i * 2] = lm[i].x()
            pts[i * 2 + 1] = lm[i].y()
        }
        TrackingState.landmarks = pts

        // Tracking mode. Classic 2D (default, steadiest): every decision uses the flat picture position,
        // corrected for the camera's aspect ratio. Depth 3D (experimental): uses the model's real-world points.
        val w3 = if (world != null && world.size >= 21) world else null
        val use3d = TrackingState.mode3d && w3 != null
        TrackingState.has3d = use3d
        val asp = TrackingState.aspect
        for (i in 0 until 21) {
            if (use3d && w3 != null) {
                p3[i * 3] = w3[i].x()
                p3[i * 3 + 1] = w3[i].y()
                p3[i * 3 + 2] = w3[i].z()
            } else {
                p3[i * 3] = lm[i].x() * asp
                p3[i * 3 + 1] = lm[i].y()
                p3[i * 3 + 2] = 0f
            }
        }

        // points for the 3D preview, flipped if needed so the 3D hand matches the 2D image
        val draw = FloatArray(63)
        if (w3 != null) {
            val dyImg = lm[0].y() - lm[9].y()
            val dyW = w3[0].y() - w3[9].y()
            if (abs(dyImg) > 0.03f && abs(dyW) > 0.005f) flipY = if (dyImg * dyW < 0f) -1f else 1f
            val dxImg = lm[5].x() - lm[17].x()
            val dxW = w3[5].x() - w3[17].x()
            if (abs(dxImg) > 0.03f && abs(dxW) > 0.005f) flipX = if (dxImg * dxW < 0f) -1f else 1f
            for (i in 0 until 21) {
                draw[i * 3] = w3[i].x() * flipX
                draw[i * 3 + 1] = w3[i].y() * flipY
                draw[i * 3 + 2] = w3[i].z()
            }
        } else {
            for (i in 0 until 21) {
                draw[i * 3] = (lm[i].x() - 0.5f) * 0.4f
                draw[i * 3 + 1] = (lm[i].y() - 0.5f) * 0.4f
                draw[i * 3 + 2] = lm[i].z() * 0.4f
            }
        }
        TrackingState.points3d = draw

        fun d2(a: Int, b: Int) = hypot(lm[a].x() - lm[b].x(), lm[a].y() - lm[b].y())
        val palm3 = max(d3(0, 9), 1e-6f)
        val palm2 = max(d2(0, 9), 1e-6f)

        // Each finger is UP (1), DOWN (0) or UNSURE (-1), from two 3D measures that must agree:
        // how far the tip is from the wrist compared with the middle joint, and how straight the finger is.
        fun fst(m: Int, p: Int, t: Int): Int {
            val r = d3(t, 0) / max(d3(p, 0), 1e-6f)
            val s = straight(m, p, t)
            return when {
                r > 1.28f && s > 0.70f -> 1
                r < 1.12f || s < 0.40f -> 0
                else -> -1
            }
        }
        st[0] = fst(5, 6, 8)
        st[1] = fst(9, 10, 12)
        st[2] = fst(13, 14, 16)
        st[3] = fst(17, 18, 20)
        val upC = st.count { it == 1 }
        val downC = st.count { it == 0 }
        val allUp = upC == 4
        val allDown = downC == 4

        // capture-quality tip
        val pw = d2(5, 17)
        TrackingState.hint = when {
            pw < 0.10f -> "Move closer"
            pw > 0.42f -> "Too close"
            lm.any { it.x() < 0.02f || it.x() > 0.98f || it.y() < 0.02f || it.y() > 0.98f } -> "Near edge"
            else -> ""
        }

        // thumb tip <-> middle fingertip, 3D, lightly smoothed over time
        val rawM = d3(4, 12) / palm3
        if (!pinchInit) {
            pinchInit = true
            pinchM = rawM
        } else {
            pinchM += 0.5f * (rawM - pinchM)
        }
        TrackingState.pinchRatio = pinchM

        // tap thresholds: calibrated if the user ran "Calibrate tap", otherwise from the sensitivity slider
        val tapOn = if (TrackingState.calOn > 0f) TrackingState.calOn else 0.20f + 0.04f * TrackingState.tapSens
        val tapArm = if (TrackingState.calArm > 0f) max(TrackingState.calArm, tapOn + 0.08f) else tapOn + 0.15f

        // thumbs-up / thumbs-down: four fingers folded, thumb straight, tip clearly above / below the index knuckle
        val tvx = lm[4].x() - lm[5].x()
        val tvy = lm[4].y() - lm[5].y()
        val thumbPose = allDown && straight(2, 3, 4) > 0.60f &&
            abs(tvy) > 0.50f * palm2 && abs(tvy) > 0.9f * abs(tvx)

        val raw = when {
            thumbPose && tvy < 0f -> "VOL_UP"
            thumbPose && tvy > 0f -> "VOL_DOWN"
            st[3] == 1 && st[0] == 0 && st[1] == 0 && st[2] == 0 -> "VJ"
            allDown -> "FIST"
            allUp -> "PALM"
            st[0] == 1 && st[1] != 1 && st[2] != 1 -> "POINT"
            st[0] == 1 && st[1] == 1 && st[2] == 0 && st[3] == 0 -> "BACK"
            st[0] == 1 && st[1] == 1 && st[2] == 1 && st[3] == 0 -> "HOME"
            else -> "OTHER"
        }
        if (raw == cand) candN++ else {
            cand = raw
            candN = 1
        }
        val need = when (TrackingState.strict) {
            0 -> 2
            2 -> 5
            else -> 3
        }
        if (candN >= need) pose = cand

        // leaving a fist: wait a moment so the hand shape in between can't trigger anything
        if (prevPose == "FIST" && pose != "FIST") rearmUntil = now + REARM_MS
        val entry = now - seenSince < ENTRY_GRACE
        val eff = if ((now < rearmUntil && pose != "FIST") || entry) "WAIT" else pose

        svc.setActive(upC > 0)
        if (eff != "VOL_UP" && eff != "VOL_DOWN") volSince = 0L
        if (eff != "FIST") {
            fistSince = 0L
            doneFired = false
        }
        if (eff != "POINT") relInit = false

        // ---- TAP: flick the thumb away from the middle finger, then touch them together ----
        // A thumb that merely rests on the middle finger never taps: it must be clearly open first.
        if (st[0] == 1 && !(st[2] == 1 && st[3] == 1)) lastTapPose = now
        val tapEligible = now - lastTapPose < TAP_GRACE && now >= rearmUntil && !entry
        if (tapEligible && pinchM > tapArm) armedUntil = now + TAP_ARM_WINDOW
        if (tapEligible && now < armedUntil && pinchM < tapOn && now - lastTap > TAP_COOLDOWN) {
            armedUntil = 0L
            latch(now, svc)
            if (!TrackingState.suppress) svc.tapAt(tapX, tapY)
            fire(svc, "TAP", 25L)
            lastTap = now
        }

        if (TrackingState.wantDebug) {
            fun ch(i: Int, name: String) = if (st[i] == 1) name else if (st[i] == 0) "-" else "?"
            TrackingState.debug = "pose " + eff + "   fingers " + ch(0, "I") + ch(1, "M") + ch(2, "R") + ch(3, "P") +
                "\nthumb-middle " + fmt(pinchM) + "  taps under " + fmt(tapOn) + "  opens over " + fmt(tapArm) +
                (if (now < armedUntil) "  READY" else "") +
                (if (TrackingState.calOn > 0f) "  (calibrated)" else "")
        }

        if (TrackingState.suppress) {
            // calibration: report the gesture, do nothing
            TrackingState.gesture = "READY"
            prevPose = pose
            svc.frameUpdate()
            return
        }

        when (eff) {
            // ---- VOLUME (pinky only): hold still, then hand up = louder, down = quieter ----
            "VJ" -> {
                leaveHold()
                if (joyArm(now, lm[9].x(), lm[9].y(), "VJ", "VJ_WAIT", "VJ")) {
                    val dy = lm[9].y() - anchorY
                    val r = abs(dy) / DZ_V
                    TrackingState.offX = 0f
                    TrackingState.offY = dy / DZ_V
                    if (r > 1f) {
                        val cooldown = (800f - 350f * (r - 1f).coerceIn(0f, 1f)).toLong()
                        if (now - lastVol > cooldown) {
                            val louder = dy < 0
                            svc.volume(louder)
                            fire(svc, if (louder) "VOL_UP" else "VOL_DOWN", 20L)
                            lastVol = now
                        }
                    }
                }
            }

            // ---- VOLUME (thumbs-up / thumbs-down): hold; repeats while held ----
            "VOL_UP", "VOL_DOWN" -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = eff
                if (volSince == 0L) volSince = now
                val t = now - volSince
                if (t < VOL_DWELL) {
                    TrackingState.progress = t.toFloat() / VOL_DWELL
                } else if (now - lastVol > VOL_REPEAT) {
                    svc.volume(eff == "VOL_UP")
                    fire(svc, eff, 20L)
                    lastVol = now
                }
            }

            // ---- FIST held briefly: task finished. Reset everything and wait for a new command ----
            "FIST" -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "PAUSED"
                if (fistSince == 0L) fistSince = now
                if (!doneFired) {
                    val t = now - fistSince
                    TrackingState.progress = (t.toFloat() / FIST_HOLD).coerceIn(0f, 1f)
                    if (t >= FIST_HOLD) {
                        doneFired = true
                        resetSession()
                        fire(svc, "TASK_DONE", 30L)
                    }
                }
            }

            // ---- Open hand: hold still, then move away from the centre ----
            "PALM" -> {
                leaveHold()
                val x = lm[9].x()
                val y = lm[9].y()
                if (joyArm(now, x, y, "PALM", "PALM_WAIT", "PALM")) {
                    val dx = x - anchorX
                    val dy = y - anchorY
                    val rx = abs(dx) / DZ_H
                    val ry = abs(dy) / DZ_V
                    TrackingState.offX = dx / DZ_H
                    TrackingState.offY = dy / DZ_V
                    if (max(rx, ry) > 1f) {
                        if (ry >= rx) {
                            // farther from the centre = faster scrolling
                            val cooldown = (800f - 350f * (ry - 1f).coerceIn(0f, 1f)).toLong()
                            if (now - lastRepeat > cooldown) {
                                val handUp = dy < 0
                                val scrollUp = if (TrackingState.scrollInv) !handUp else handUp
                                if (scrollUp) {
                                    svc.swipe(1) // finger moves down -> content moves down -> see what is above
                                    TrackingState.event("SCROLL_UP")
                                } else {
                                    svc.swipe(-1)
                                    TrackingState.event("SCROLL_DOWN")
                                }
                                lastRepeat = now
                            }
                        } else if (now - lastRepeat > SLIDE_COOLDOWN) {
                            if (dx > 0) {
                                svc.swipeH(-1) // hand to your right -> next page
                                fire(svc, "PAGE_NEXT", 20L)
                            } else {
                                svc.swipeH(1)
                                fire(svc, "PAGE_PREV", 20L)
                            }
                            lastRepeat = now
                        }
                    }
                }
            }

            // ---- Pointer: RELATIVE movement, like a mouse ----
            "POINT" -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "MOVE"
                // hand position (index knuckle) in "cursor pixels": 1 hand-unit = screen / span
                val span = 0.9f - 0.07f * TrackingState.speed
                val px = lm[5].x() * svc.screenW / span
                val py = lm[5].y() * svc.screenH / span
                if (!relInit) {
                    // (re)start from where the cursor already is: no jump, however far the hand has travelled
                    relInit = true
                    euX.start(px, now)
                    euY.start(py, now)
                    prevPx = px
                    prevPy = py
                    curX = svc.cx
                    curY = svc.cy
                } else {
                    val minC = 15f / TrackingState.smooth // slider: low = fast, high = steady
                    val fx = euX.filter(px, now, minC, 0.012f)
                    val fy = euY.filter(py, now, minC, 0.012f)
                    curX = (curX + (fx - prevPx)).coerceIn(0f, svc.screenW - 1f)
                    curY = (curY + (fy - prevPy)).coerceIn(0f, svc.screenH - 1f)
                    prevPx = fx
                    prevPy = fy
                    if (abs(curX - svc.cx) + abs(curY - svc.cy) > 0.5f) {
                        svc.moveTo(curX, curY)
                        remember(curX, curY, now)
                    }
                }
            }

            "BACK" -> hold("BACK", now, svc)
            "HOME" -> hold("HOME", now, svc)

            else -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "READY"
            }
        }
        prevPose = pose
        svc.frameUpdate()
    }

    private fun hold(p: String, now: Long, svc: MouseAccessibilityService) {
        leavePalm()
        if (holdPose != p) {
            holdPose = p
            holdSince = now
            holdFired = false
        }
        val prog = ((now - holdSince).toFloat() / HOLD_MS).coerceIn(0f, 1f)
        TrackingState.progress = if (holdFired) 0f else prog
        TrackingState.gesture = p + "_HOLD"
        if (!holdFired && prog >= 1f && now - lastHold > HOLD_COOLDOWN) {
            holdFired = true
            lastHold = now
            fire(svc, p, 40L)
            if (p == "BACK") svc.back() else svc.home()
        }
    }
}
