package com.example.virtualmouse

import android.os.SystemClock
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/** Turns 21 hand landmarks into cursor moves, taps, Back/Home and scrolls. */
class GestureEngine {

    private companion object {
        const val MARGIN = 0.15f          // unused border of the camera view
        const val SMOOTH = 5f             // higher = smoother but slower
        const val PINCH = 0.30f           // pinch threshold relative to palm size
        const val ACTION_COOLDOWN = 600L  // ms between taps/back/home
        const val SCROLL_STEP = 0.05f     // palm travel (fraction of frame) per scroll
        const val SCROLL_COOLDOWN = 350L
    }

    private var sx = -1f
    private var sy = -1f
    private var palmY = -1f
    private var lastAction = 0L
    private var lastScroll = 0L

    fun update(lm: List<NormalizedLandmark>?) {
        val svc = MouseAccessibilityService.instance ?: return
        if (lm == null) {
            palmY = -1f
            return
        }
        val now = SystemClock.uptimeMillis()

        fun d(a: Int, b: Int) = hypot(lm[a].x() - lm[b].x(), lm[a].y() - lm[b].y())

        val palm = max(d(0, 9), 1e-6f)
        val up = booleanArrayOf(
            lm[8].y() < lm[6].y(),    // index
            lm[12].y() < lm[10].y(),  // middle
            lm[16].y() < lm[14].y(),  // ring
            lm[20].y() < lm[18].y()   // pinky
        )
        svc.setActive(up.any())

        when {
            // Fist: pause
            up.none { it } -> palmY = -1f

            // Open palm: scroll
            up.all { it } -> {
                val y = lm[9].y()
                if (palmY < 0) palmY = y
                val dy = y - palmY
                if (abs(dy) > SCROLL_STEP && now - lastScroll > SCROLL_COOLDOWN) {
                    svc.swipe(if (dy > 0) 1 else -1)
                    palmY = y
                    lastScroll = now
                }
            }

            // Pointer mode
            else -> {
                palmY = -1f
                val action = when {
                    d(4, 12) / palm < PINCH -> 1
                    d(4, 16) / palm < PINCH -> 2
                    d(4, 20) / palm < PINCH -> 3
                    else -> 0
                }
                if (action != 0) {
                    // cursor stays frozen while pinching
                    if (now - lastAction > ACTION_COOLDOWN) {
                        when (action) {
                            1 -> svc.tap()
                            2 -> svc.back()
                            else -> svc.home()
                        }
                        lastAction = now
                    }
                } else if (up[0]) {
                    val span = 1f - 2f * MARGIN
                    val tx = ((lm[8].x() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenW
                    val ty = ((lm[8].y() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenH
                    if (sx < 0) {
                        sx = svc.cx
                        sy = svc.cy
                    }
                    sx += (tx - sx) / SMOOTH
                    sy += (ty - sy) / SMOOTH
                    svc.moveTo(sx, sy)
                }
            }
        }
    }
}
