package com.example.virtualmouse

import android.os.SystemClock
import com.google.mediapipe.tasks.components.containers.Landmark
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/**
 * One Euro filter: smooths hard when the hand is still (no jitter) and barely at all when it
 * moves fast (no lag). This is the "time" dimension of the tracking.
 */
private class OneEuro {
    private var init = false
    private var xPrev = 0f
    private var dxPrev = 0f
    private var tPrev = 0L

    fun start(x: Float, t: Long) {
        init = true
        xPrev = x
        dxPrev = 0f
        tPrev = t
    }

    fun filter(x: Float, t: Long, minCutoff: Float, beta: Float): Float {
        if (!init) {
            start(x, t)
            return x
        }
        val dt = max((t - tPrev) / 1000f, 0.001f)
        tPrev = t
        dxPrev += alpha(dt, 1f) * ((x - xPrev) / dt - dxPrev)
        val cutoff = minCutoff + beta * abs(dxPrev)
        xPrev += alpha(dt, cutoff) * (x - xPrev)
        return xPrev
    }

    private fun alpha(dt: Float, cutoff: Float): Float {
        val tau = 1f / (2f * PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }
}

/**
 * Hand pose -> action, using real 3D hand points (depth) plus motion over time.
 *
 *  index only up ................ MOVE    (cursor follows the index KNUCKLE)
 *  thumb touches index tip ...... TAP     (3D distance, so depth can't fake a touch)
 *  open hand .................... SCROLL / PAGE SLIDE (hold still, then move away from the neutral point)
 *  OK sign (thumb+index, 3 up) .. ZOOM    (hand toward / away from camera, measured with 3D depth)
 *  thumbs-up / thumbs-down ...... VOLUME  (hold; repeats while held)
 *  fist ......................... TASK DONE (resets everything, waits for the next command)
 *  index+middle up, hold ........ BACK
 *  index+middle+ring up, hold ... HOME
 */
class GestureEngine {

    companion object {
        const val MARGIN = 0.20f          // unused border of the camera view
        const val DZ_H = 0.09f            // neutral zone (half-width) for page slide
        const val DZ_V = 0.07f            // neutral zone (half-height) for scroll
        private const val UP_ON = 0.70f   // finger straightness (cosine of the bend angle) above which it is "up"
        private const val UP_OFF = 0.45f  // ... and below which it is "down" (in between: keep previous state)
        private const val DEBOUNCE = 2    // frames a pose must repeat before it takes effect
        private const val OK_PINCH = 0.40f
        private const val TAP_ON = 0.26f
        private const val TAP_OFF = 0.42f
        private const val TAP_APPROACH = 0.46f
        private const val TAP_WINDOW = 700L
        private const val TAP_COOLDOWN = 350L
        private const val PALM_DWELL = 400L
        private const val SLIDE_COOLDOWN = 900L
        private const val HOLD_MS = 600L
        private const val HOLD_COOLDOWN = 1500L
        private const val ZOOM_DWELL = 400L
        private const val ZOOM_COOLDOWN = 700L
        private const val ZOOM_IN_RATIO = 1.15f
        private const val ZOOM_OUT_RATIO = 0.87f
        private const val VOL_DWELL = 350L
        private const val VOL_REPEAT = 500L
        private const val REARM_MS = 350L // after a fist, ignore the next hand shapes briefly
        private val PALM_BONES = intArrayOf(0, 5, 0, 9, 0, 13, 0, 17, 5, 9, 9, 13, 13, 17, 5, 17)
    }

    private val p3 = FloatArray(63)                 // 21 points x (x, y, z): metres if world landmarks exist
    private val up = BooleanArray(4)                // index, middle, ring, pinky
    private var pose = "NONE"
    private var prevPose = "NONE"
    private var cand = "NONE"
    private var candN = 0
    private var lostSince = 0L
    private var sx = -1f
    private var sy = -1f
    private val euX = OneEuro()
    private val euY = OneEuro()
    private var pinchF = 1f
    private var pinchInit = false
    private var pinchOn = false
    private var lastPointer = 0L
    private var lastTap = 0L
    private var palmSince = -1L
    private var anchorX = 0f
    private var anchorY = 0f
    private var lastRepeat = 0L
    private var holdPose = ""
    private var holdSince = 0L
    private var holdFired = false
    private var lastHold = 0L
    private var zoomBase = -1f
    private var zoomSince = 0L
    private var lastZoom = 0L
    private var volSince = 0L
    private var lastVol = 0L
    private var doneFired = false
    private var rearmUntil = 0L

    private fun d3(a: Int, b: Int): Float {
        val dx = p3[a * 3] - p3[b * 3]
        val dy = p3[a * 3 + 1] - p3[b * 3 + 1]
        val dz = p3[a * 3 + 2] - p3[b * 3 + 2]
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    /** Cosine of the angle between bone (m->p) and bone (p->t): 1 = straight finger, <0.5 = bent. */
    private fun straight(m: Int, p: Int, t: Int): Float {
        val ux = p3[p * 3] - p3[m * 3]
        val uy = p3[p * 3 + 1] - p3[m * 3 + 1]
        val uz = p3[p * 3 + 2] - p3[m * 3 + 2]
        val wx = p3[t * 3] - p3[p * 3]
        val wy = p3[t * 3 + 1] - p3[p * 3 + 1]
        val wz = p3[t * 3 + 2] - p3[p * 3 + 2]
        val lu = sqrt(ux * ux + uy * uy + uz * uz)
        val lw = sqrt(wx * wx + wy * wy + wz * wz)
        if (lu < 1e-6f || lw < 1e-6f) return 1f
        return (ux * wx + uy * wy + uz * wz) / (lu * lw)
    }

    private fun leavePalm() {
        palmSince = -1L
        TrackingState.anchorX = -1f
        TrackingState.offX = 0f
        TrackingState.offY = 0f
    }

    private fun leaveHold() {
        holdPose = ""
        holdFired = false
        TrackingState.progress = 0f
    }

    /** Fist = "this task is finished": forget everything in progress so the next command starts clean. */
    private fun resetSession() {
        leavePalm()
        leaveHold()
        zoomBase = -1f
        pinchOn = false
        lastPointer = 0L
        volSince = 0L
        sx = -1f
        sy = -1f
    }

    private fun fire(svc: MouseAccessibilityService, name: String, ms: Long) {
        TrackingState.event(name)
        svc.buzz(ms)
    }

    fun update(lm: List<NormalizedLandmark>?, world: List<Landmark>? = null) {
        val svc = MouseAccessibilityService.instance ?: return
        val now = SystemClock.uptimeMillis()

        if (lm == null) {
            if (lostSince == 0L) lostSince = now
            val lost = now - lostSince
            TrackingState.hint = when {
                lost > 8000L -> "Camera covered?"
                lost > 3000L -> "Add more light"
                else -> ""
            }
            leavePalm()
            leaveHold()
            zoomBase = -1f
            pinchOn = false
            pinchInit = false
            volSince = 0L
            pose = "NONE"
            prevPose = "NONE"
            cand = "NONE"
            candN = 0
            TrackingState.landmarks = null
            TrackingState.gesture = "NO_HAND"
            svc.frameUpdate()
            return
        }
        lostSince = 0L

        val pts = FloatArray(42)
        for (i in 0 until 21) {
            pts[i * 2] = lm[i].x()
            pts[i * 2 + 1] = lm[i].y()
        }
        TrackingState.landmarks = pts

        // 3D points: real metres from the world landmarks (depth-aware); falls back to image coordinates
        val w3 = if (world != null && world.size >= 21) world else null
        TrackingState.has3d = w3 != null
        for (i in 0 until 21) {
            if (w3 != null) {
                p3[i * 3] = w3[i].x()
                p3[i * 3 + 1] = w3[i].y()
                p3[i * 3 + 2] = w3[i].z()
            } else {
                p3[i * 3] = lm[i].x()
                p3[i * 3 + 1] = lm[i].y()
                p3[i * 3 + 2] = lm[i].z()
            }
        }

        fun d2(a: Int, b: Int) = hypot(lm[a].x() - lm[b].x(), lm[a].y() - lm[b].y())
        val palm3 = max(d3(0, 9), 1e-6f)

        // fingers up/down from 3D bend angles, with hysteresis
        fun upd(i: Int, m: Int, p: Int, t: Int) {
            val s = straight(m, p, t)
            if (s > UP_ON) up[i] = true else if (s < UP_OFF) up[i] = false
        }
        upd(0, 5, 6, 8)
        upd(1, 9, 10, 12)
        upd(2, 13, 14, 16)
        upd(3, 17, 18, 20)
        val e = up
        val n = e.count { it }

        // capture-quality tip
        val pw = d2(5, 17)
        TrackingState.hint = when {
            pw < 0.10f -> "Move closer"
            pw > 0.42f -> "Too close"
            lm.any { it.x() < 0.02f || it.x() > 0.98f || it.y() < 0.02f || it.y() > 0.98f } -> "Near edge"
            else -> ""
        }

        // thumb-tip to index-tip distance in 3D, lightly smoothed over time
        val pinchRaw = d3(4, 8) / palm3
        if (!pinchInit) {
            pinchInit = true
            pinchF = pinchRaw
        } else {
            pinchF += 0.5f * (pinchRaw - pinchF)
        }
        val pinch = pinchF
        if (pinch > TAP_OFF) pinchOn = false

        val folded = !e[1] && !e[2] && !e[3]
        val pointerPose = e[0] && folded
        if (pointerPose) lastPointer = now
        val indexOut = straight(5, 6, 8) > 0.30f

        // thumbs-up / thumbs-down: four fingers folded, thumb straight, away from the palm, pointing up/down
        val tvx = lm[4].x() - lm[2].x()
        val tvy = lm[4].y() - lm[2].y()
        val tlen = hypot(tvx, tvy)
        val thumbPose = n == 0 && straight(2, 3, 4) > 0.70f && d3(4, 5) / palm3 > 0.95f &&
            tlen > 1e-6f && abs(tvy) / tlen > 0.75f

        val raw = when {
            pinch < OK_PINCH && e[1] && e[2] && e[3] -> "OK"
            folded && pinch < TAP_APPROACH && (pinchOn || (indexOut && now - lastPointer < TAP_WINDOW)) -> "TAP"
            thumbPose && tvy < 0f -> "VOL_UP"
            thumbPose && tvy > 0f -> "VOL_DOWN"
            n == 0 -> "FIST"
            n == 4 -> "PALM"
            pointerPose -> "POINT"
            e[0] && e[1] && !e[2] && !e[3] -> "BACK"
            e[0] && e[1] && e[2] && !e[3] -> "HOME"
            else -> "OTHER"
        }
        if (raw == cand) candN++ else {
            cand = raw
            candN = 1
        }
        if (candN >= DEBOUNCE) pose = cand

        // leaving a fist: wait a moment so the hand shape in between can't trigger anything
        if (prevPose == "FIST" && pose != "FIST") rearmUntil = now + REARM_MS
        val eff = if (now < rearmUntil && pose != "FIST") "WAIT" else pose

        svc.setActive(n > 0 || pinchOn)
        if (eff != "OK") zoomBase = -1f
        if (eff != "VOL_UP" && eff != "VOL_DOWN") volSince = 0L
        if (eff != "FIST") doneFired = false
        if (eff != "POINT") {
            euX.start(svc.cx, now) // next time we point, glide from where the cursor is
            euY.start(svc.cy, now)
        }

        when (eff) {
            // ---- ZOOM: OK sign, then hand toward / away from the camera ----
            "OK" -> {
                leavePalm()
                leaveHold()
                // apparent size / real size of the rigid palm bones ~ 1 / distance to the camera
                var s = 0f
                if (w3 != null) {
                    var k = 0
                    while (k < PALM_BONES.size) {
                        val a = PALM_BONES[k]
                        val b = PALM_BONES[k + 1]
                        k += 2
                        val real = d3(a, b)
                        if (real > 1e-6f) s = max(s, d2(a, b) / real)
                    }
                } else {
                    s = d2(5, 17)
                }
                s = max(s, 1e-6f)
                if (zoomBase < 0f) {
                    zoomBase = s
                    zoomSince = now
                } else if (now - zoomSince < ZOOM_DWELL) {
                    zoomBase += (s - zoomBase) * 0.3f
                }
                var g = "ZOOM"
                if (now - zoomSince >= ZOOM_DWELL) {
                    val ratio = s / zoomBase
                    if (ratio > ZOOM_IN_RATIO) g = "ZOOM_IN" else if (ratio < ZOOM_OUT_RATIO) g = "ZOOM_OUT"
                    if (g != "ZOOM" && now - lastZoom > ZOOM_COOLDOWN) {
                        svc.zoom(g == "ZOOM_IN")
                        fire(svc, g, 25L)
                        lastZoom = now
                    }
                }
                TrackingState.gesture = g
            }

            // ---- TAP: thumb touches index fingertip while pointing ----
            "TAP" -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "PINCH" // cursor stays frozen
                if (!pinchOn && pinch < TAP_ON) {
                    pinchOn = true
                    if (now - lastTap > TAP_COOLDOWN) {
                        svc.tap()
                        fire(svc, "TAP", 25L)
                        lastTap = now
                    }
                }
            }

            // ---- VOLUME: thumbs-up / thumbs-down, hold; repeats while held ----
            "VOL_UP", "VOL_DOWN" -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = eff
                if (volSince == 0L) volSince = now
                val t = now - volSince
                if (t < VOL_DWELL) {
                    TrackingState.progress = t.toFloat() / VOL_DWELL
                } else if (now - lastVol > VOL_REPEAT) {
                    svc.volume(eff == "VOL_UP")
                    fire(svc, eff, 20L)
                    lastVol = now
                }
            }

            // ---- FIST: task finished. Reset everything and wait for a new command ----
            "FIST" -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "PAUSED"
                if (!doneFired) {
                    doneFired = true
                    resetSession()
                    fire(svc, "TASK_DONE", 30L)
                }
            }

            // ---- Open hand: hold still to set a neutral point, then move away from it ----
            "PALM" -> {
                leaveHold()
                val x = lm[9].x()
                val y = lm[9].y()
                if (palmSince < 0) {
                    palmSince = now
                    anchorX = x
                    anchorY = y
                }
                TrackingState.anchorX = anchorX
                TrackingState.anchorY = anchorY
                if (now - palmSince < PALM_DWELL) {
                    anchorX += (x - anchorX) * 0.3f
                    anchorY += (y - anchorY) * 0.3f
                    TrackingState.gesture = "PALM_WAIT"
                    TrackingState.progress = (now - palmSince).toFloat() / PALM_DWELL // ring fills around the cursor
                } else {
                    TrackingState.gesture = "PALM"
                    val dx = x - anchorX
                    val dy = y - anchorY
                    val rx = abs(dx) / DZ_H
                    val ry = abs(dy) / DZ_V
                    TrackingState.offX = dx / DZ_H
                    TrackingState.offY = dy / DZ_V
                    if (max(rx, ry) > 1f) {
                        if (ry >= rx) {
                            // farther from the neutral point = faster scrolling
                            val cooldown = (800f - 350f * (ry - 1f).coerceIn(0f, 1f)).toLong()
                            if (now - lastRepeat > cooldown) {
                                val handUp = dy < 0
                                val scrollUp = if (TrackingState.scrollInv) !handUp else handUp
                                if (scrollUp) {
                                    svc.swipe(1) // finger moves down -> content moves down -> see what is above
                                    TrackingState.event("SCROLL_UP")
                                } else {
                                    svc.swipe(-1)
                                    TrackingState.event("SCROLL_DOWN")
                                }
                                lastRepeat = now
                            }
                        } else if (now - lastRepeat > SLIDE_COOLDOWN) {
                            if (dx > 0) {
                                svc.swipeH(-1) // hand to your right -> next page
                                fire(svc, "PAGE_NEXT", 20L)
                            } else {
                                svc.swipeH(1)
                                fire(svc, "PAGE_PREV", 20L)
                            }
                            lastRepeat = now
                        }
                    }
                }
            }

            // ---- Pointer: index only ----
            "POINT" -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "MOVE"
                val span = 1f - 2f * MARGIN
                val tx = ((lm[5].x() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenW
                val ty = ((lm[5].y() - MARGIN) / span).coerceIn(0f, 1f) * svc.screenH
                val minC = 15f / TrackingState.smooth // slider: low = fast, high = steady
                val fx = euX.filter(tx, now, minC, 0.012f)
                val fy = euY.filter(ty, now, minC, 0.012f)
                if (sx < 0f) {
                    sx = svc.cx
                    sy = svc.cy
                }
                if (abs(fx - sx) + abs(fy - sy) > 0.8f) {
                    sx = fx
                    sy = fy
                    svc.moveTo(sx, sy)
                }
            }

            "BACK" -> hold("BACK", now, svc)
            "HOME" -> hold("HOME", now, svc)

            else -> {
                leavePalm()
                leaveHold()
                TrackingState.gesture = "READY"
            }
        }
        prevPose = pose
        svc.frameUpdate()
    }

    private fun hold(p: String, now: Long, svc: MouseAccessibilityService) {
        leavePalm()
        if (holdPose != p) {
            holdPose = p
            holdSince = now
            holdFired = false
        }
        val prog = ((now - holdSince).toFloat() / HOLD_MS).coerceIn(0f, 1f)
        TrackingState.progress = if (holdFired) 0f else prog
        TrackingState.gesture = p + "_HOLD"
        if (!holdFired && prog >= 1f && now - lastHold > HOLD_COOLDOWN) {
            holdFired = true
            lastHold = now
            fire(svc, p, 40L)
            if (p == "BACK") svc.back() else svc.home()
        }
    }
}
