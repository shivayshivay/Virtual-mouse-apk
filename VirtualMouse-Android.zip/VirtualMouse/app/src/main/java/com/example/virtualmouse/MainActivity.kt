package com.example.virtualmouse

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private data class Tile(val emoji: String, val title: String, val desc: String, val color: Int)

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var pageViews: List<View>
    private lateinit var tabViews: List<TextView>
    private lateinit var hero: TextView
    private lateinit var pulse: View
    private lateinit var chipStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvCamIcon: TextView
    private lateinit var tvAccIcon: TextView
    private lateinit var setupDetail: LinearLayout
    private lateinit var setupDone: TextView
    private lateinit var liveCard: LinearLayout
    private lateinit var preview: HandPreviewView
    private var pulseAnim: ObjectAnimator? = null
    private var lastRunning: Boolean? = null
    private var ticks = 0

    private val tick = object : Runnable {
        override fun run() {
            ticks++
            if (liveCard.visibility == View.VISIBLE) preview.invalidate()
            if (ticks % 4 == 0) refresh()
            ui.postDelayed(this, 70)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = this
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        TrackingState.smooth = prefs.getFloat("smooth", 5f)
        TrackingState.scrollInv = prefs.getBoolean("scroll_inv", false)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.CARD
        val pad = Ui.dp(c, 16)

        pageViews = listOf(buildHome(pad), buildGestures(pad), buildSettings(pad))
        val content = FrameLayout(c)
        for (p in pageViews) {
            content.addView(p, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }

        fun tab(emoji: String, label: String, i: Int): TextView {
            val t = Ui.text(c, "$emoji\n$label", 12f, Ui.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8))
            t.setOnClickListener { selectTab(i) }
            return t
        }
        tabViews = listOf(tab("🏠", "Home", 0), tab("✋", "Gestures", 1), tab("⚙️", "Settings", 2))
        val bar = LinearLayout(c)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Ui.CARD)
        bar.setPadding(Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6))
        for (t in tabViews) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(Ui.dp(c, 4), 0, Ui.dp(c, 4), 0)
            bar.addView(t, lp)
        }

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bar)
        setContentView(root)
        selectTab(0)

        if (!prefs.getBoolean("tutorial_done", false)) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }
    }

    // ------------------------------------------------------------------ Home

    private fun buildHome(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)

        // gradient banner with the big start / stop button
        val banner = LinearLayout(c)
        banner.orientation = LinearLayout.VERTICAL
        banner.gravity = Gravity.CENTER_HORIZONTAL
        banner.background = Ui.gradient(Ui.ACCENT, Ui.PINK, Ui.dp(c, 30), GradientDrawable.Orientation.TL_BR)
        banner.setPadding(pad, pad, pad, Ui.dp(c, 20))

        val header = LinearLayout(c)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val icon = ImageView(c)
        icon.setImageResource(R.mipmap.ic_launcher)
        header.addView(icon, LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)))
        val titles = LinearLayout(c)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(Ui.dp(c, 12), 0, 0, 0)
        titles.addView(Ui.text(c, "Virtual Mouse", 20f, Color.WHITE, true))
        titles.addView(Ui.text(c, "Hand control for your phone", 12f, Ui.tint(Color.WHITE, 210)))
        header.addView(titles)
        banner.addView(header, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val frame = FrameLayout(c)
        pulse = View(c)
        val ringShape = GradientDrawable()
        ringShape.shape = GradientDrawable.OVAL
        ringShape.setColor(Color.TRANSPARENT)
        ringShape.setStroke(Ui.dp(c, 3), Color.WHITE)
        pulse.background = ringShape
        pulse.alpha = 0f
        frame.addView(pulse, FrameLayout.LayoutParams(Ui.dp(c, 140), Ui.dp(c, 140), Gravity.CENTER))

        hero = TextView(c)
        hero.text = "START"
        hero.textSize = 24f
        hero.setTextColor(Ui.ACCENT)
        hero.setTypeface(hero.typeface, Typeface.BOLD)
        hero.gravity = Gravity.CENTER
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(Color.WHITE)
        hero.background = circle
        hero.elevation = Ui.dp(c, 8).toFloat()
        hero.setOnClickListener { toggle() }
        frame.addView(hero, FrameLayout.LayoutParams(Ui.dp(c, 140), Ui.dp(c, 140), Gravity.CENTER))
        val flp = LinearLayout.LayoutParams(Ui.dp(c, 200), Ui.dp(c, 190))
        flp.topMargin = Ui.dp(c, 8)
        banner.addView(frame, flp)

        chipStatus = Ui.chip(c, "Not running", Color.WHITE)
        banner.addView(chipStatus, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        tvHint = Ui.text(c, "", 12f, Ui.tint(Color.WHITE, 220))
        tvHint.gravity = Gravity.CENTER
        val hl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        hl.topMargin = Ui.dp(c, 10)
        banner.addView(tvHint, hl)
        col.addView(banner)

        // setup checklist (collapses to one line when done)
        val setup = Ui.card(c)
        setup.addView(Ui.text(c, "Quick setup", 18f, Ui.TEXT, true))
        setupDone = Ui.chip(c, "✅  All set. You're ready to go", Ui.GOOD)
        Ui.add(setup, setupDone, 10)
        setupDetail = LinearLayout(c)
        setupDetail.orientation = LinearLayout.VERTICAL
        tvCamIcon = row(setupDetail, "📷", "Camera", "Needed to see your hand", "Allow") {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        tvAccIcon = row(setupDetail, "♿", "Accessibility", "Lets the app move a cursor and tap for you", "Enable") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        Ui.add(setupDetail, Ui.button(c, "Switch greyed out? Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, 14)
        Ui.add(setup, setupDetail, 0)
        Ui.add(col, setup, 16)

        // live view while tracking
        liveCard = Ui.card(c)
        liveCard.addView(Ui.text(c, "Live view", 18f, Ui.TEXT, true))
        Ui.add(liveCard, Ui.text(c, "What the camera sees. The skeleton should sit on your hand.", 12f, Ui.MUTED), 4)
        preview = HandPreviewView(c, c.resources.displayMetrics.density)
        val plp = LinearLayout.LayoutParams(Ui.dp(c, 216), Ui.dp(c, 316))
        plp.gravity = Gravity.CENTER_HORIZONTAL
        plp.topMargin = Ui.dp(c, 12)
        liveCard.addView(preview, plp)
        liveCard.visibility = View.GONE
        Ui.add(col, liveCard, 14)

        // learn
        val learn = Ui.card(c)
        learn.addView(Ui.text(c, "New here?", 18f, Ui.TEXT, true))
        Ui.add(learn, Ui.text(c, "A 2-minute tutorial lets you practise every gesture and ticks each one green when it works.", 13f, Ui.MUTED), 4)
        Ui.add(learn, Ui.button(c, "Start the tutorial", true) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }, 14)
        Ui.add(col, learn, 14)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    // ------------------------------------------------------------------ Gestures

    private fun buildGestures(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Gestures", 24f, Ui.TEXT, true))
        Ui.add(col, Ui.text(c, "Keep your hand 30-50 cm from the front camera, palm facing it.", 13f, Ui.MUTED), 4)

        var i = 0
        while (i < TILES.size) {
            val row = LinearLayout(c)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                if (k == 1) lp.leftMargin = Ui.dp(c, 10)
                if (i + k < TILES.size) {
                    val t = TILES[i + k]
                    row.addView(tile(t), lp)
                } else {
                    row.addView(View(c), lp)
                }
            }
            Ui.add(col, row, 10)
            i += 2
        }
        Ui.add(col, Ui.button(c, "Open interactive tutorial", true) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }, 18)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    private fun tile(t: Tile): LinearLayout {
        val c = this
        val card = Ui.card(c)
        card.addView(Ui.badge(c, t.emoji, t.color, 50), LinearLayout.LayoutParams(Ui.dp(c, 50), Ui.dp(c, 50)))
        Ui.add(card, Ui.text(c, t.title, 16f, Ui.TEXT, true), 10)
        Ui.add(card, Ui.text(c, t.desc, 12f, Ui.MUTED), 4)
        return card
    }

    // ------------------------------------------------------------------ Settings

    private fun buildSettings(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Settings", 24f, Ui.TEXT, true))

        val prev = Ui.card(c)
        prev.addView(Ui.text(c, "Hand preview box", 16f, Ui.TEXT, true))
        Ui.add(
            prev,
            Ui.text(c, "Auto-hide shows it until your hand is recognised, then hides it and keeps it hidden until you press START again. You still feel a buzz on actions and see the cursor change colour.", 12f, Ui.MUTED),
            4
        )
        Ui.add(prev, segmented(listOf("Auto-hide", "Always on", "Hidden"), prefs.getInt("hud_mode", 1)) { m ->
            prefs.edit().putInt("hud_mode", m).apply()
            MouseAccessibilityService.instance?.setHudMode(m)
        }, 12)
        Ui.add(col, prev, 14)

        val scrollCard = Ui.card(c)
        scrollCard.addView(Ui.text(c, "Scroll direction", 16f, Ui.TEXT, true))
        Ui.add(scrollCard, Ui.text(c, "Choose how your open hand moves the page.", 12f, Ui.MUTED), 4)
        Ui.add(scrollCard, segmented(listOf("Hand up = page up", "Hand up = page down"), if (prefs.getBoolean("scroll_inv", false)) 1 else 0) { i ->
            prefs.edit().putBoolean("scroll_inv", i == 1).apply()
            TrackingState.scrollInv = (i == 1)
        }, 12)
        Ui.add(col, scrollCard, 14)

        val feel = Ui.card(c)
        feel.addView(Ui.text(c, "Feel", 16f, Ui.TEXT, true))
        val sw = Switch(c)
        sw.text = "Vibrate on tap, Back, Home, zoom, volume"
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = prefs.getBoolean("haptics", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("haptics", on).apply()
            MouseAccessibilityService.instance?.setHapticsEnabled(on)
        }
        Ui.add(feel, sw, 12)
        val tvSmooth = Ui.text(c, "", 14f, Ui.TEXT)
        Ui.add(feel, tvSmooth, 16)
        val bar = SeekBar(c)
        bar.max = 10
        bar.progress = (TrackingState.smooth - 2f).toInt().coerceIn(0, 10)
        tvSmooth.text = "Cursor smoothness: ${bar.progress + 2}  (low = fast, high = steady)"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                TrackingState.smooth = 2f + p
                tvSmooth.text = "Cursor smoothness: ${p + 2}  (low = fast, high = steady)"
                if (fromUser) prefs.edit().putFloat("smooth", 2f + p).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        Ui.add(feel, bar, 4)
        Ui.add(col, feel, 14)

        val tools = Ui.card(c)
        tools.addView(Ui.text(c, "Test volume", 16f, Ui.TEXT, true))
        Ui.add(tools, Ui.text(c, "Checks that the phone accepts volume changes from this app, independent of any gesture.", 12f, Ui.MUTED), 4)
        val vrow = LinearLayout(c)
        vrow.orientation = LinearLayout.HORIZONTAL
        vrow.addView(Ui.button(c, "🔊  Louder", false) { testVolume(true) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val dl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        dl.leftMargin = Ui.dp(c, 8)
        vrow.addView(Ui.button(c, "🔉  Quieter", false) { testVolume(false) }, dl)
        Ui.add(tools, vrow, 12)
        Ui.add(col, tools, 14)

        val sec = Ui.card(c)
        sec.addView(Ui.text(c, "Privacy & security", 16f, Ui.TEXT, true))
        Ui.add(
            sec,
            Ui.text(
                c,
                "• Camera images are analysed on your phone only. They are never saved or sent anywhere.\n\n" +
                    "• The app does not request internet permission.\n\n" +
                    "• The accessibility service is only used to draw the cursor and perform taps, swipes, pinch-zoom, Back and Home. It is not given access to read your screen or key presses.\n\n" +
                    "• Volume gestures only change the media volume.\n\n" +
                    "• The camera stops automatically when the screen turns off, or after 5 minutes without a hand.\n\n" +
                    "• A notification and Android's camera indicator show whenever the camera is on.",
                13f, Ui.MUTED
            ),
            8
        )
        Ui.add(col, sec, 14)
        Ui.add(col, Ui.text(c, "Virtual Mouse 1.6", 12f, Ui.MUTED).also { it.gravity = Gravity.CENTER }, 16)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    // ------------------------------------------------------------------ logic

    private fun selectTab(i: Int) {
        for (k in pageViews.indices) pageViews[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in tabViews.indices) {
            val sel = k == i
            tabViews[k].setTextColor(if (sel) Color.WHITE else Ui.MUTED)
            tabViews[k].background = if (sel) Ui.shape(Ui.tint(Ui.ACCENT, 110), Ui.dp(this, 18)) else null
        }
    }

    private fun toggle() {
        if (TrackingState.running) {
            stopService(Intent(this, HandTrackingService::class.java))
            toast("Stopped")
            return
        }
        val err = startTracking(this)
        toast(err ?: "Started. Press Home and raise your hand in front of the front camera.")
    }

    private fun testVolume(up: Boolean) {
        val svc = MouseAccessibilityService.instance
        if (svc == null) toast("Enable the accessibility service first (Home tab)") else svc.volume(up)
    }

    private fun startPulse() {
        if (pulseAnim != null) return
        val a = ObjectAnimator.ofPropertyValuesHolder(
            pulse,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.4f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.4f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.8f, 0f)
        )
        a.duration = 1500
        a.repeatCount = ValueAnimator.INFINITE
        a.start()
        pulseAnim = a
    }

    private fun stopPulse() {
        pulseAnim?.cancel()
        pulseAnim = null
        pulse.alpha = 0f
        pulse.scaleX = 1f
        pulse.scaleY = 1f
    }

    private fun refresh() {
        val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val acc = MouseAccessibilityService.instance != null
        tvCamIcon.text = if (cam) "✅" else "⭕"
        tvAccIcon.text = if (acc) "✅" else "⭕"
        val allSet = cam && acc
        setupDetail.visibility = if (allSet) View.GONE else View.VISIBLE
        setupDone.visibility = if (allSet) View.VISIBLE else View.GONE

        val running = TrackingState.running
        liveCard.visibility = if (running) View.VISIBLE else View.GONE
        if (running) {
            Ui.setChip(
                chipStatus,
                "● ${TrackingState.statusLine()}  |  ${TrackingState.fps} fps" + if (TrackingState.has3d) "  |  3D" else "",
                Color.WHITE
            )
            startPulse()
        } else {
            Ui.setChip(chipStatus, "● Not running", Color.WHITE)
            stopPulse()
        }
        tvHint.text = when {
            !allSet -> "Finish the quick setup below, then press START."
            running -> "Press Home to use your phone. The preview hides itself once your hand is recognised."
            else -> "Press START, then raise your hand in front of the front camera."
        }
        if (lastRunning != running) {
            lastRunning = running
            hero.text = if (running) "STOP" else "START"
            hero.setTextColor(if (running) Ui.BAD else Ui.ACCENT)
        }
    }

    override fun onResume() {
        super.onResume()
        TrackingState.inApp = true // this screen has its own live view, so hide the floating box
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        TrackingState.inApp = false
        MouseAccessibilityService.instance?.refreshHud()
        ui.removeCallbacks(tick)
        stopPulse()
    }

    private fun row(parent: LinearLayout, emoji: String, title: String, desc: String, btn: String, onClick: () -> Unit): TextView {
        val c = this
        val r = LinearLayout(c)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(Ui.badge(c, emoji, Ui.ACCENT, 40), LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)))
        val mid = LinearLayout(c)
        mid.orientation = LinearLayout.VERTICAL
        mid.setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 8), 0)
        mid.addView(Ui.text(c, title, 15f, Ui.TEXT, true))
        mid.addView(Ui.text(c, desc, 12f, Ui.MUTED))
        r.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val status = Ui.text(c, "⭕", 20f)
        status.setPadding(0, 0, Ui.dp(c, 8), 0)
        r.addView(status)
        r.addView(Ui.button(c, btn, false, onClick))
        Ui.add(parent, r, 14)
        return status
    }

    private fun segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val c = this
        val rowView = LinearLayout(c)
        rowView.orientation = LinearLayout.HORIZONTAL
        val btns = ArrayList<Button>()
        fun select(k: Int) {
            for (j in btns.indices) Ui.styleButton(btns[j], j == k)
            onSelect(k)
        }
        for (i in labels.indices) {
            val b = Ui.button(c, labels[i], i == selected) { }
            b.textSize = 13f
            b.setOnClickListener { select(i) }
            btns.add(b)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = Ui.dp(c, 6)
            rowView.addView(b, lp)
        }
        return rowView
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private val TILES = listOf(
            Tile("☝️", "Move", "Index finger up, middle and ring folded.", Ui.TEAL),
            Tile("🤏", "Tap", "Touch your thumb to your pinky.", Ui.PINK),
            Tile("✋", "Scroll", "Open hand, hold still, then move up or down.", Ui.ACCENT),
            Tile("↔️", "Slide pages", "Open hand, hold still, then move left or right.", Ui.ACCENT),
            Tile("👌", "Zoom", "OK sign, then hand toward or away.", Ui.WARN),
            Tile("👍", "Volume", "Thumbs up or down. Hold to repeat.", Ui.GOOD),
            Tile("✊", "Task done", "Fist when finished. Resets and waits.", Ui.MUTED),
            Tile("↩️", "Back", "Index + middle up (V). Hold.", Ui.TEAL),
            Tile("🏠", "Home", "Index + middle + ring up. Hold.", Ui.PINK)
        )
    }
}
