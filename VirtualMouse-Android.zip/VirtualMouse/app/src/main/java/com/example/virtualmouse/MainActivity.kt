package com.example.virtualmouse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.graphics.Typeface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var tvStatus: TextView

    private val tick = object : Runnable {
        override fun run() {
            tvStatus.text = statusText()
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("vm", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = HELP; textSize = 15f })

        tvStatus = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(tvStatus)

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        button("Open tutorial (practice with live feedback)") {
            startActivity(Intent(this, TutorialActivity::class.java))
        }
        button("1. Allow camera") {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        button("2a. Open App info (allow restricted settings)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("2b. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("3. START virtual mouse") {
            val err = startTracking(this)
            toast(err ?: "Started. Press Home and watch the preview box at the top-right.")
        }
        button("STOP") {
            stopService(Intent(this, HandTrackingService::class.java))
            toast("Stopped")
        }

        root.addView(Switch(this).apply {
            text = "Show live hand preview (skeleton + status)"
            isChecked = prefs.getBoolean("hud", true)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("hud", on).apply()
                MouseAccessibilityService.instance?.setHudEnabled(on)
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })

        if (!prefs.getBoolean("tutorial_done", false)) {
            startActivity(Intent(this, TutorialActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    private fun statusText(): String {
        val cam = if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) "OK" else "NOT ALLOWED"
        val acc = if (MouseAccessibilityService.instance != null) "ON" else "OFF"
        val trk = if (TrackingState.running) "RUNNING | ${TrackingState.statusLine()} | ${TrackingState.fps} fps" else "STOPPED"
        return "Camera:        $cam\nAccessibility: $acc\nTracking:      $trk"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val HELP = """VIRTUAL MOUSE
Prop the phone up so the FRONT camera sees your hand.
Set-up checklist (live status below):"""
    }
}
