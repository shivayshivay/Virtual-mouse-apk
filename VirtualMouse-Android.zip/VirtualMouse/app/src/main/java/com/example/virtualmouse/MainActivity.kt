package com.example.virtualmouse

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private data class Tile(val pose: String, val title: String, val desc: String)

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var pageViews: List<View>
    private val tabIcons = ArrayList<IconView>()
    private val tabPills = ArrayList<FrameLayout>()
    private val tabLabels = ArrayList<TextView>()
    private lateinit var tvHeadline: TextView
    private lateinit var tvSub: TextView
    private lateinit var tvHeroLabel: TextView
    private lateinit var heroCircle: FrameLayout
    private lateinit var heroIcon: IconView
    private lateinit var pulse: View
    private lateinit var chipStatus: TextView
    private lateinit var tvDebug: TextView
    private lateinit var tvCam: TextView
    private lateinit var tvCamDot: TextView
    private lateinit var tvAcc: TextView
    private lateinit var tvAccDot: TextView
    private lateinit var tvCal: TextView
    private lateinit var helpBtn: Button
    private lateinit var preview: HandPreviewView
    private val demoViews = ArrayList<HandPreviewView>()
    private var pulseAnim: ObjectAnimator? = null
    private var currentTab = 0
    private var lastRunning: Boolean? = null
    private var ticks = 0

    private val tick = object : Runnable {
        override fun run() {
            ticks++
            if (currentTab == 0) preview.invalidate() // keeps the 3D hand turning
            if (currentTab == 1) for (v in demoViews) v.invalidate() // gesture pictures animate
            if (ticks % 4 == 0) refresh()
            ui.postDelayed(this, 50)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Ui.applyTheme(this)
        setTheme(Ui.themeRes())
        super.onCreate(savedInstanceState)
        val c = this
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        migrateCalibration(this)
        TrackingState.smooth = prefs.getFloat("smooth", 5f)
        TrackingState.speed = prefs.getFloat("speed", 5f)
        TrackingState.tapSens = prefs.getFloat("tap_sens", 5f)
        TrackingState.calOn = prefs.getFloat("tap_on", -1f)
        TrackingState.calArm = prefs.getFloat("tap_arm", -1f)
        TrackingState.strict = prefs.getInt("strict", 1)
        TrackingState.mode3d = prefs.getBoolean("mode3d", false)
        TrackingState.scrollInv = prefs.getBoolean("scroll_inv", false)
        Ui.systemBars(this)
        val pad = Ui.dp(c, 20)

        pageViews = listOf(buildHome(pad), buildGestures(pad), buildSettings(pad))
        val content = FrameLayout(c)
        for (p in pageViews) {
            content.addView(p, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }

        fun tab(icon: Int, label: String, i: Int): LinearLayout {
            val t = LinearLayout(c)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER_HORIZONTAL
            t.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8))
            val pill = FrameLayout(c)
            val iv = IconView(c, icon)
            pill.addView(iv, FrameLayout.LayoutParams(Ui.dp(c, 24), Ui.dp(c, 24), Gravity.CENTER))
            t.addView(pill, LinearLayout.LayoutParams(Ui.dp(c, 62), Ui.dp(c, 32)))
            val tv = Ui.text(c, label, 11f, Ui.MUTED, true)
            tv.gravity = Gravity.CENTER
            t.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(c, 2) })
            t.setOnClickListener { selectTab(i) }
            tabIcons.add(iv)
            tabPills.add(pill)
            tabLabels.add(tv)
            return t
        }
        val bar = LinearLayout(c)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Ui.CARD)
        for (t in listOf(tab(IconView.HOME, "Home", 0), tab(IconView.GRID, "Gestures", 1), tab(IconView.TUNE, "Settings", 2))) {
            bar.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        val hair = View(c)
        hair.setBackgroundColor(Ui.STROKE)

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(hair, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 1)))
        root.addView(bar)
        setContentView(root)
        selectTab(0)

        if (!prefs.getBoolean("tutorial_done", false)) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }
    }

    // ------------------------------------------------------------------ Home

    private fun buildHome(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)

        // app bar
        val top = LinearLayout(c)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(c)
        logo.setImageResource(R.drawable.gf_logo)
        top.addView(logo, LinearLayout.LayoutParams(Ui.dp(c, 38), Ui.dp(c, 38)))
        val titles = LinearLayout(c)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(Ui.dp(c, 12), 0, 0, 0)
        titles.addView(Ui.text(c, "GestureFlow", 20f, Ui.TEXT, true))
        titles.addView(Ui.text(c, "Control your phone with your hand", 12f, Ui.MUTED))
        top.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val themeBox = FrameLayout(c)
        themeBox.background = Ui.dot(Ui.CARD2)
        val themeIcon = IconView(c, if (Ui.isDark) IconView.SUN else IconView.MOON)
        themeIcon.color = Ui.TEXT
        themeBox.addView(themeIcon, FrameLayout.LayoutParams(Ui.dp(c, 22), Ui.dp(c, 22), Gravity.CENTER))
        themeBox.setOnClickListener {
            prefs.edit().putInt("theme", if (Ui.isDark) 1 else 2).apply()
            recreate()
        }
        top.addView(themeBox, LinearLayout.LayoutParams(Ui.dp(c, 42), Ui.dp(c, 42)))
        col.addView(top)

        // status headline
        tvHeadline = Ui.text(c, "", 30f, Ui.TEXT, true)
        Ui.add(col, tvHeadline, 28)
        tvSub = Ui.text(c, "", 14f, Ui.MUTED)
        Ui.add(col, tvSub, 6)

        // the big start / stop button
        val heroBox = FrameLayout(c)
        pulse = View(c)
        pulse.background = Ui.ring(c, 3, Ui.tint(Ui.ACCENT, 170))
        pulse.alpha = 0f
        heroBox.addView(pulse, FrameLayout.LayoutParams(Ui.dp(c, 150), Ui.dp(c, 150), Gravity.CENTER))
        heroCircle = FrameLayout(c)
        heroCircle.background = Ui.dot(Ui.ACCENT)
        heroCircle.elevation = Ui.dp(c, 6).toFloat()
        heroIcon = IconView(c, IconView.PLAY)
        heroIcon.color = Ui.ON_ACCENT
        heroCircle.addView(heroIcon, FrameLayout.LayoutParams(Ui.dp(c, 56), Ui.dp(c, 56), Gravity.CENTER))
        heroCircle.setOnClickListener { toggle() }
        heroBox.addView(heroCircle, FrameLayout.LayoutParams(Ui.dp(c, 150), Ui.dp(c, 150), Gravity.CENTER))
        val hb = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 220))
        hb.topMargin = Ui.dp(c, 14)
        col.addView(heroBox, hb)
        tvHeroLabel = Ui.text(c, "Start tracking", 16f, Ui.TEXT, true)
        tvHeroLabel.gravity = Gravity.CENTER
        Ui.add(col, tvHeroLabel, 0)
        chipStatus = Ui.chip(c, "Not running", Ui.MUTED)
        val cl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        cl.gravity = Gravity.CENTER_HORIZONTAL
        cl.topMargin = Ui.dp(c, 10)
        col.addView(chipStatus, cl)
        tvDebug = Ui.text(c, "", 11f, Ui.MUTED)
        tvDebug.typeface = Typeface.MONOSPACE
        tvDebug.gravity = Gravity.CENTER
        Ui.add(col, tvDebug, 8)

        // two setup pills
        val pills = LinearLayout(c)
        pills.orientation = LinearLayout.HORIZONTAL
        pills.addView(setupPill("Camera", { requestCamera() }) { dot, st -> tvCamDot = dot; tvCam = st },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        val pl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        pl.leftMargin = Ui.dp(c, 10)
        pills.addView(setupPill("Accessibility", { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { dot, st -> tvAccDot = dot; tvAcc = st }, pl)
        Ui.add(col, pills, 22)
        helpBtn = Ui.button(c, "Accessibility switch greyed out? Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        Ui.add(col, helpBtn, 10)

        // live hand
        val live = Ui.card(c)
        live.addView(Ui.text(c, "Live hand", 16f, Ui.TEXT, true))
        Ui.add(live, Ui.text(c, "What the camera sees, as a 3D model. Drag it to rotate.", 12f, Ui.MUTED), 2)
        val vp = FrameLayout(c)
        vp.background = Ui.shape(Color.rgb(20, 24, 38), Ui.dp(c, 16))
        preview = HandPreviewView(c, c.resources.displayMetrics.density)
        preview.interactive = true
        preview.cornerDp = 16f
        vp.addView(preview, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val vl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 280))
        vl.topMargin = Ui.dp(c, 12)
        live.addView(vp, vl)
        Ui.add(col, live, 18)

        // tutorial
        val learn = Ui.card(c)
        learn.addView(Ui.text(c, "Learn the gestures", 16f, Ui.TEXT, true))
        Ui.add(learn, Ui.text(c, "An animated hand shows each move, and the tutorial moves on by itself when you get it right.", 13f, Ui.MUTED), 4)
        Ui.add(learn, Ui.button(c, "Start the tutorial", false) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }, 14)
        Ui.add(col, learn, 14)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    private fun setupPill(title: String, onClick: () -> Unit, bind: (TextView, TextView) -> Unit): LinearLayout {
        val c = this
        val t = Ui.card(c)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        val r = LinearLayout(c)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val dot = Ui.text(c, "●", 18f, Ui.WARN)
        r.addView(dot)
        val txt = LinearLayout(c)
        txt.orientation = LinearLayout.VERTICAL
        txt.setPadding(Ui.dp(c, 10), 0, 0, 0)
        txt.addView(Ui.text(c, title, 15f, Ui.TEXT, true))
        val st = Ui.text(c, "", 12f, Ui.MUTED)
        txt.addView(st)
        r.addView(txt)
        t.addView(r)
        bind(dot, st)
        return t
    }

    private fun requestCamera() {
        val perms = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    // ------------------------------------------------------------------ Gestures

    private fun buildGestures(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Gestures", 28f, Ui.TEXT, true))
        Ui.add(col, Ui.text(c, "Keep your hand 30-50 cm from the front camera, palm facing it.", 14f, Ui.MUTED), 4)

        val list = Ui.card(c)
        for ((i, t) in TILES.withIndex()) {
            if (i > 0) {
                val line = View(c)
                line.setBackgroundColor(Ui.STROKE)
                val ll = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 1))
                ll.topMargin = Ui.dp(c, 12)
                ll.bottomMargin = Ui.dp(c, 12)
                list.addView(line, ll)
            }
            list.addView(gestureRow(t))
        }
        Ui.add(col, list, 18)
        Ui.add(col, Ui.button(c, "Open interactive tutorial", true) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }, 18)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    private fun gestureRow(t: Tile): LinearLayout {
        val c = this
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val pic = FrameLayout(c)
        pic.background = Ui.shape(Color.rgb(20, 24, 38), Ui.dp(c, 16))
        val hv = HandPreviewView(c, c.resources.displayMetrics.density)
        hv.demo = t.pose
        hv.showStrip = false
        hv.cornerDp = 16f
        demoViews.add(hv)
        pic.addView(hv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        row.addView(pic, LinearLayout.LayoutParams(Ui.dp(c, 92), Ui.dp(c, 92)))
        val txt = LinearLayout(c)
        txt.orientation = LinearLayout.VERTICAL
        txt.setPadding(Ui.dp(c, 14), 0, 0, 0)
        txt.addView(Ui.text(c, t.title, 17f, Ui.TEXT, true))
        txt.addView(Ui.text(c, t.desc, 13f, Ui.MUTED).also { it.setLineSpacing(0f, 1.1f) })
        row.addView(txt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    // ------------------------------------------------------------------ Settings

    private fun buildSettings(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Settings", 28f, Ui.TEXT, true))

        // gestures
        val acc = Ui.card(c)
        acc.addView(Ui.text(c, "Gestures", 17f, Ui.TEXT, true))
        Ui.add(acc, Ui.text(c, "Tracking mode", 12f, Ui.MUTED), 12)
        Ui.add(acc, segmented(listOf("Classic 2D (steady)", "Depth 3D (beta)"), if (prefs.getBoolean("mode3d", false)) 1 else 0) { i ->
            prefs.edit().putBoolean("mode3d", i == 1).remove("tap_on").remove("tap_arm").apply()
            TrackingState.mode3d = (i == 1)
            TrackingState.calOn = -1f
            TrackingState.calArm = -1f
            refreshCal()
            toast("Mode changed. Run Calibrate tap again for best results.")
        }, 6)
        Ui.add(acc, Ui.text(c, "Strictness: how sure the app must be before it acts. If gestures trigger by accident, choose Strict.", 12f, Ui.MUTED), 16)
        Ui.add(acc, segmented(listOf("Relaxed", "Normal", "Strict"), prefs.getInt("strict", 1)) { i ->
            prefs.edit().putInt("strict", i).apply()
            TrackingState.strict = i
        }, 6)
        Ui.add(acc, Ui.text(c, "Tap = flick your thumb away from your middle finger, then touch them together.", 12f, Ui.MUTED), 16)
        tvCal = Ui.text(c, "", 13f, Ui.TEXT, true)
        Ui.add(acc, tvCal, 6)
        val calRow = LinearLayout(c)
        calRow.orientation = LinearLayout.HORIZONTAL
        calRow.addView(Ui.button(c, "Calibrate tap", true) { startActivity(Intent(c, CalibrationActivity::class.java)) },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f))
        val rl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        rl.leftMargin = Ui.dp(c, 8)
        calRow.addView(Ui.button(c, "Reset", false) {
            prefs.edit().remove("tap_on").remove("tap_arm").apply()
            TrackingState.calOn = -1f
            TrackingState.calArm = -1f
            refreshCal()
        }, rl)
        Ui.add(acc, calRow, 6)
        Ui.add(acc, Ui.text(c, "Scroll direction", 12f, Ui.MUTED), 16)
        Ui.add(acc, segmented(listOf("Hand up = page up", "Hand up = page down"), if (prefs.getBoolean("scroll_inv", false)) 1 else 0) { i ->
            prefs.edit().putBoolean("scroll_inv", i == 1).apply()
            TrackingState.scrollInv = (i == 1)
        }, 6)
        Ui.add(col, acc, 16)

        // cursor
        val cur = Ui.card(c)
        cur.addView(Ui.text(c, "Cursor", 17f, Ui.TEXT, true))
        slider(cur, "Speed", "higher = less hand movement", "speed", 1, 10, 5f) { TrackingState.speed = it }
        slider(cur, "Smoothness", "low = fast, high = steady", "smooth", 2, 12, 5f) { TrackingState.smooth = it }
        Ui.add(cur, Ui.text(c, "The cursor moves like a mouse: it follows how far your hand moves. Run out of room? Make a fist, reposition your hand, then point again. The cursor stays where it was.", 12f, Ui.MUTED), 14)
        Ui.add(col, cur, 16)

        // floating preview
        val fp = Ui.card(c)
        fp.addView(Ui.text(c, "Floating hand preview", 17f, Ui.TEXT, true))
        Ui.add(
            fp,
            Ui.text(c, "Auto-hide shows it until your hand is recognised, then hides it until you press Start again. You still feel a buzz on actions and see the cursor change colour.", 12f, Ui.MUTED),
            4
        )
        Ui.add(fp, segmented(listOf("Auto-hide", "Always on", "Hidden"), prefs.getInt("hud_mode", 1)) { m ->
            prefs.edit().putInt("hud_mode", m).apply()
            MouseAccessibilityService.instance?.setHudMode(m)
        }, 12)
        Ui.add(fp, Ui.text(c, "Position", 12f, Ui.MUTED), 16)
        val corners = LinearLayout(c)
        corners.orientation = LinearLayout.HORIZONTAL
        val labels = listOf("↖", "↗", "↙", "↘")
        for (i in labels.indices) {
            val b = Ui.button(c, labels[i], false) { withService { it.setHudCorner(i) } }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = Ui.dp(c, 6)
            corners.addView(b, lp)
        }
        Ui.add(fp, corners, 6)
        Ui.add(fp, Ui.button(c, "Drag it where you want", false) {
            withService {
                it.showHudForMove()
                toast("The preview box is showing for 12 seconds. Drag it with your finger.")
            }
        }, 8)
        Ui.add(fp, Ui.text(c, "Size", 12f, Ui.MUTED), 14)
        Ui.add(fp, segmented(listOf("Small", "Medium", "Large"), prefs.getInt("hud_scale", 1)) { i ->
            prefs.edit().putInt("hud_scale", i).apply()
            MouseAccessibilityService.instance?.setHudScale(i)
        }, 6)
        Ui.add(col, fp, 16)

        // appearance + feel
        val look = Ui.card(c)
        look.addView(Ui.text(c, "Appearance & feel", 17f, Ui.TEXT, true))
        Ui.add(look, Ui.text(c, "Theme", 12f, Ui.MUTED), 12)
        Ui.add(look, segmented(listOf("System", "Light", "Dark"), prefs.getInt("theme", 0)) { i ->
            prefs.edit().putInt("theme", i).apply()
            recreate()
        }, 6)
        val sw = Switch(c)
        sw.text = "Vibrate on tap, Back, Home, volume"
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = prefs.getBoolean("haptics", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("haptics", on).apply()
            MouseAccessibilityService.instance?.setHapticsEnabled(on)
        }
        Ui.add(look, sw, 18)
        Ui.add(look, Ui.text(c, "Test volume: checks that the phone accepts volume changes from this app, independent of any gesture.", 12f, Ui.MUTED), 14)
        val vrow = LinearLayout(c)
        vrow.orientation = LinearLayout.HORIZONTAL
        vrow.addView(Ui.button(c, "Louder", false) { testVolume(true) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val dl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        dl.leftMargin = Ui.dp(c, 8)
        vrow.addView(Ui.button(c, "Quieter", false) { testVolume(false) }, dl)
        Ui.add(look, vrow, 8)
        Ui.add(col, look, 16)

        // advanced
        val adv = Ui.card(c)
        val advBody = LinearLayout(c)
        advBody.orientation = LinearLayout.VERTICAL
        advBody.visibility = View.GONE
        val advBtn = Ui.button(c, "Advanced  ▾", false) { }
        advBtn.setOnClickListener {
            val open = advBody.visibility != View.VISIBLE
            advBody.visibility = if (open) View.VISIBLE else View.GONE
            advBtn.text = if (open) "Advanced  ▴" else "Advanced  ▾"
        }
        adv.addView(advBtn)
        slider(advBody, "Tap sensitivity", "used until you calibrate", "tap_sens", 1, 10, 5f) { TrackingState.tapSens = it }
        val diag = Switch(c)
        diag.text = "Show live numbers (diagnostics)"
        diag.setTextColor(Ui.TEXT)
        diag.isChecked = prefs.getBoolean("diag", false)
        diag.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("diag", on).apply() }
        Ui.add(advBody, diag, 18)
        Ui.add(adv, advBody, 8)
        Ui.add(col, adv, 16)

        // about
        val about = Ui.card(c)
        about.addView(Ui.text(c, "About & privacy", 17f, Ui.TEXT, true))
        Ui.add(about, Ui.text(c, "Developer details, privacy policy, permissions explained and open-source credits.", 12f, Ui.MUTED), 4)
        Ui.add(about, Ui.button(c, "Open", false) { startActivity(Intent(c, AboutActivity::class.java)) }, 12)
        Ui.add(col, about, 16)

        Ui.add(col, Ui.text(c, "GestureFlow 2.0", 12f, Ui.MUTED).also { it.gravity = Gravity.CENTER }, 18)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    private fun refreshCal() {
        tvCal.text = if (TrackingState.calOn > 0f) {
            "Tap: calibrated  (taps under ${"%.2f".format(TrackingState.calOn)})"
        } else {
            "Tap: not calibrated yet. Calibrating takes 10 seconds and fixes most missed taps."
        }
    }

    private fun slider(parent: LinearLayout, label: String, hint: String, key: String, lo: Int, hi: Int, def: Float, apply: (Float) -> Unit) {
        val c = this
        val tv = Ui.text(c, "", 14f, Ui.TEXT)
        Ui.add(parent, tv, 16)
        val sb = SeekBar(c)
        sb.max = hi - lo
        sb.progress = (prefs.getFloat(key, def).toInt() - lo).coerceIn(0, hi - lo)
        tv.text = "$label: ${sb.progress + lo}   ($hint)"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = lo + p
                tv.text = "$label: $v   ($hint)"
                apply(v.toFloat())
                if (fromUser) prefs.edit().putFloat(key, v.toFloat()).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        Ui.add(parent, sb, 2)
    }

    // ------------------------------------------------------------------ logic

    private fun withService(block: (MouseAccessibilityService) -> Unit) {
        val s = MouseAccessibilityService.instance
        if (s == null) toast("Enable the accessibility service first (Home tab)") else block(s)
    }

    private fun selectTab(i: Int) {
        currentTab = i
        for (k in pageViews.indices) pageViews[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in tabIcons.indices) {
            val sel = k == i
            tabIcons[k].color = if (sel) Ui.ACCENT else Ui.MUTED
            tabLabels[k].setTextColor(if (sel) Ui.ACCENT else Ui.MUTED)
            tabPills[k].background = if (sel) Ui.shape(Ui.tint(Ui.ACCENT, 34), Ui.dp(this, 16)) else null
        }
    }

    private fun toggle() {
        if (TrackingState.running) {
            stopService(Intent(this, HandTrackingService::class.java))
            toast("Stopped")
            return
        }
        val err = startTracking(this)
        toast(err ?: "Started. Press Home and raise your hand in front of the front camera.")
    }

    private fun testVolume(up: Boolean) = withService { it.volume(up) }

    private fun startPulse() {
        if (pulseAnim != null) return
        val a = ObjectAnimator.ofPropertyValuesHolder(
            pulse,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.45f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.45f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.8f, 0f)
        )
        a.duration = 1500
        a.repeatCount = ValueAnimator.INFINITE
        a.start()
        pulseAnim = a
    }

    private fun stopPulse() {
        pulseAnim?.cancel()
        pulseAnim = null
        pulse.alpha = 0f
        pulse.scaleX = 1f
        pulse.scaleY = 1f
    }

    private fun refresh() {
        val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val acc = MouseAccessibilityService.instance != null
        tvCam.text = if (cam) "Allowed" else "Tap to allow"
        tvCamDot.setTextColor(if (cam) Ui.GOOD else Ui.WARN)
        tvAcc.text = if (acc) "Enabled" else "Tap to enable"
        tvAccDot.setTextColor(if (acc) Ui.GOOD else Ui.WARN)
        helpBtn.visibility = if (acc) View.GONE else View.VISIBLE
        val allSet = cam && acc

        val running = TrackingState.running
        if (running) {
            tvHeadline.text = TrackingState.statusLine().replaceFirstChar { it.uppercase() }
            tvSub.text = "Press Home to use your phone. The floating box hides itself once your hand is recognised."
            Ui.setChip(chipStatus, "${TrackingState.fps} fps  |  " + (if (TrackingState.has3d) "3D" else "2D") + " tracking", TrackingState.color())
            startPulse()
        } else {
            tvHeadline.text = if (allSet) "Ready to start" else "Almost ready"
            tvSub.text = if (allSet) "Press the button, then raise your hand in front of the front camera." else "Allow the camera and enable the accessibility service below."
            Ui.setChip(chipStatus, "Not running", Ui.MUTED)
            stopPulse()
        }
        if (running && prefs.getBoolean("diag", false)) {
            tvDebug.text = TrackingState.debug
            tvDebug.visibility = View.VISIBLE
        } else {
            tvDebug.visibility = View.GONE
        }
        if (lastRunning != running) {
            lastRunning = running
            tvHeroLabel.text = if (running) "Stop tracking" else "Start tracking"
            heroIcon.type = if (running) IconView.STOP else IconView.PLAY
            heroIcon.color = if (running) Color.WHITE else Ui.ON_ACCENT
            heroCircle.background = Ui.dot(if (running) Ui.BAD else Ui.ACCENT)
        }
    }

    override fun onResume() {
        super.onResume()
        TrackingState.inApp = true // this screen has its own 3D view, so hide the floating box
        TrackingState.wantDebug = prefs.getBoolean("diag", false)
        TrackingState.calOn = prefs.getFloat("tap_on", -1f)
        TrackingState.calArm = prefs.getFloat("tap_arm", -1f)
        refreshCal()
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        TrackingState.inApp = false
        TrackingState.wantDebug = false
        MouseAccessibilityService.instance?.refreshHud()
        ui.removeCallbacks(tick)
        stopPulse()
    }

    private fun segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val c = this
        val rowView = LinearLayout(c)
        rowView.orientation = LinearLayout.HORIZONTAL
        val btns = ArrayList<Button>()
        fun select(k: Int) {
            for (j in btns.indices) Ui.styleButton(btns[j], j == k)
            onSelect(k)
        }
        for (i in labels.indices) {
            val b = Ui.button(c, labels[i], i == selected) { }
            b.textSize = 13f
            b.setOnClickListener { select(i) }
            btns.add(b)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = Ui.dp(c, 6)
            rowView.addView(b, lp)
        }
        return rowView
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private val TILES = listOf(
            Tile("MOVE", "Move", "Index finger up, others folded. Moves like a mouse."),
            Tile("TAP", "Tap", "Flick your thumb away from your middle finger, then touch them together."),
            Tile("SCROLL", "Scroll", "Open hand, hold still, then move up or down."),
            Tile("PAGE", "Slide pages", "Open hand, hold still, then move left or right."),
            Tile("VOLUME", "Volume", "Pinky only, hold still, then hand up or down."),
            Tile("DONE", "Task done", "Hold a fist when you finish. Resets and waits."),
            Tile("BACK", "Back", "Index + middle up (V sign). Hold."),
            Tile("HOME", "Home", "Index + middle + ring up. Hold.")
        )
    }
}
