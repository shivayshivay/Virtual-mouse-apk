package com.example.virtualmouse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private data class Tile(val pose: String, val title: String, val desc: String)

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var pageViews: List<View>
    private lateinit var tabViews: List<TextView>
    private lateinit var btnToggle: Button
    private lateinit var chipStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvDebug: TextView
    private lateinit var tvCam: TextView
    private lateinit var tvAcc: TextView
    private lateinit var tvCal: TextView
    private lateinit var helpBtn: Button
    private lateinit var preview: HandPreviewView
    private val demoViews = ArrayList<HandPreviewView>()
    private var currentTab = 0
    private var lastRunning: Boolean? = null
    private var ticks = 0

    private val tick = object : Runnable {
        override fun run() {
            ticks++
            if (currentTab == 0) preview.invalidate() // keeps the 3D hand turning
            if (currentTab == 1) for (v in demoViews) v.invalidate() // gesture pictures animate
            if (ticks % 4 == 0) refresh()
            ui.postDelayed(this, 50)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Ui.applyTheme(this)
        setTheme(Ui.themeRes())
        super.onCreate(savedInstanceState)
        val c = this
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        TrackingState.smooth = prefs.getFloat("smooth", 5f)
        TrackingState.speed = prefs.getFloat("speed", 5f)
        TrackingState.tapSens = prefs.getFloat("tap_sens", 5f)
        TrackingState.calOn = prefs.getFloat("tap_on", -1f)
        TrackingState.calArm = prefs.getFloat("tap_arm", -1f)
        TrackingState.strict = prefs.getInt("strict", 1)
        TrackingState.scrollInv = prefs.getBoolean("scroll_inv", false)
        Ui.systemBars(this)
        val pad = Ui.dp(c, 16)

        pageViews = listOf(buildHome(pad), buildGestures(pad), buildSettings(pad))
        val content = FrameLayout(c)
        for (p in pageViews) {
            content.addView(p, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }

        fun tab(emoji: String, label: String, i: Int): TextView {
            val t = Ui.text(c, "$emoji\n$label", 11f, Ui.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8))
            t.setOnClickListener { selectTab(i) }
            return t
        }
        tabViews = listOf(tab("🏠", "Home", 0), tab("✋", "Gestures", 1), tab("⚙️", "Settings", 2))
        val bar = LinearLayout(c)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.background = Ui.shape(Ui.CARD, Ui.dp(c, 30)).apply { setStroke(Ui.dp(c, 1), Ui.STROKE) }
        if (!Ui.isDark) bar.elevation = Ui.dp(c, 4).toFloat()
        bar.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6))
        for (t in tabViews) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(Ui.dp(c, 3), 0, Ui.dp(c, 3), 0)
            bar.addView(t, lp)
        }
        val barWrap = LinearLayout(c)
        barWrap.setPadding(Ui.dp(c, 14), Ui.dp(c, 4), Ui.dp(c, 14), Ui.dp(c, 10))
        barWrap.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(barWrap)
        setContentView(root)
        selectTab(0)

        if (!prefs.getBoolean("tutorial_done", false)) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }
    }

    // ------------------------------------------------------------------ Home

    private fun buildHome(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)

        // header: logo, name, theme switch
        val top = LinearLayout(c)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(c)
        logo.setImageResource(R.drawable.gf_logo)
        top.addView(logo, LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)))
        val titles = LinearLayout(c)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(Ui.dp(c, 12), 0, 0, 0)
        titles.addView(Ui.text(c, "GestureFlow", 22f, Ui.TEXT, true))
        titles.addView(Ui.text(c, "Control your phone with your hand", 12f, Ui.MUTED))
        top.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val themeBtn = Ui.badge(c, if (Ui.isDark) "☀️" else "🌙", Ui.ACCENT, 42)
        themeBtn.setOnClickListener {
            prefs.edit().putInt("theme", if (Ui.isDark) 1 else 2).apply()
            recreate()
        }
        top.addView(themeBtn, LinearLayout.LayoutParams(Ui.dp(c, 42), Ui.dp(c, 42)))
        col.addView(top)

        // the live 3D hand model
        val viewport = FrameLayout(c)
        viewport.background = Ui.shape(Color.rgb(6, 10, 22), Ui.dp(c, 24)).apply {
            setStroke(Ui.dp(c, 1), Ui.tint(Ui.ACCENT, 130))
        }
        preview = HandPreviewView(c, c.resources.displayMetrics.density)
        preview.interactive = true
        preview.cornerDp = 24f
        viewport.addView(preview, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        chipStatus = Ui.chip(c, "Not running", Color.rgb(170, 185, 220))
        val chl = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        chl.setMargins(Ui.dp(c, 12), Ui.dp(c, 12), 0, 0)
        viewport.addView(chipStatus, chl)
        val vl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 360))
        vl.topMargin = Ui.dp(c, 16)
        col.addView(viewport, vl)

        tvHint = Ui.text(c, "", 12f, Ui.MUTED)
        tvHint.gravity = Gravity.CENTER
        Ui.add(col, tvHint, 10)
        tvDebug = Ui.text(c, "", 11f, Ui.MUTED)
        tvDebug.typeface = Typeface.MONOSPACE
        tvDebug.gravity = Gravity.CENTER
        Ui.add(col, tvDebug, 6)

        btnToggle = Ui.button(c, "▶  Start tracking", true) { toggle() }
        btnToggle.minimumHeight = Ui.dp(c, 58)
        btnToggle.textSize = 16f
        Ui.add(col, btnToggle, 12)

        // setup tiles
        val tiles = LinearLayout(c)
        tiles.orientation = LinearLayout.HORIZONTAL
        tiles.addView(setupTile("📷", "Camera", { requestCamera() }) { tvCam = it },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        val tl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        tl.leftMargin = Ui.dp(c, 10)
        tiles.addView(setupTile("♿", "Accessibility", { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { tvAcc = it }, tl)
        Ui.add(col, tiles, 16)
        helpBtn = Ui.button(c, "Accessibility switch greyed out? Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        Ui.add(col, helpBtn, 10)

        val learn = Ui.card(c)
        learn.addView(Ui.text(c, "New here?", 17f, Ui.TEXT, true))
        Ui.add(learn, Ui.text(c, "An animated 3D hand shows every gesture, and each step ticks green when you do it.", 13f, Ui.MUTED), 4)
        Ui.add(learn, Ui.button(c, "Start the tutorial", false) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }, 14)
        Ui.add(col, learn, 16)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    private fun setupTile(emoji: String, title: String, onClick: () -> Unit, bind: (TextView) -> Unit): LinearLayout {
        val c = this
        val t = Ui.card(c)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        t.addView(Ui.badge(c, emoji, Ui.ACCENT, 40), LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)))
        Ui.add(t, Ui.text(c, title, 15f, Ui.TEXT, true), 8)
        val st = Ui.text(c, "", 12f, Ui.MUTED)
        Ui.add(t, st, 2)
        bind(st)
        return t
    }

    private fun requestCamera() {
        val perms = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    // ------------------------------------------------------------------ Gestures

    private fun buildGestures(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Gestures", 24f, Ui.TEXT, true))
        Ui.add(col, Ui.text(c, "Keep your hand 30-50 cm from the front camera, palm facing it. Each picture is a live 3D hand showing the move.", 13f, Ui.MUTED), 4)

        var i = 0
        while (i < TILES.size) {
            val rowView = LinearLayout(c)
            rowView.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                if (k == 1) lp.leftMargin = Ui.dp(c, 10)
                if (i + k < TILES.size) rowView.addView(tile(TILES[i + k]), lp) else rowView.addView(View(c), lp)
            }
            Ui.add(col, rowView, 10)
            i += 2
        }
        Ui.add(col, Ui.button(c, "Open interactive tutorial", true) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }, 18)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    private fun tile(t: Tile): LinearLayout {
        val c = this
        val card = Ui.card(c)
        val pic = FrameLayout(c)
        pic.background = Ui.shape(Color.rgb(6, 10, 22), Ui.dp(c, 16))
        val hv = HandPreviewView(c, c.resources.displayMetrics.density)
        hv.demo = t.pose
        hv.showStrip = false
        hv.cornerDp = 16f
        demoViews.add(hv)
        pic.addView(hv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        card.addView(pic, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 150)))
        Ui.add(card, Ui.text(c, t.title, 16f, Ui.TEXT, true), 10)
        Ui.add(card, Ui.text(c, t.desc, 12f, Ui.MUTED), 4)
        return card
    }

    // ------------------------------------------------------------------ Settings

    private fun buildSettings(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Settings", 24f, Ui.TEXT, true))

        // appearance
        val look = Ui.card(c)
        look.addView(Ui.text(c, "Appearance", 16f, Ui.TEXT, true))
        Ui.add(look, Ui.text(c, "Theme", 12f, Ui.MUTED), 10)
        Ui.add(look, segmented(listOf("System", "Light", "Dark"), prefs.getInt("theme", 0)) { i ->
            prefs.edit().putInt("theme", i).apply()
            recreate()
        }, 6)
        Ui.add(col, look, 14)

        // gesture accuracy
        val acc = Ui.card(c)
        acc.addView(Ui.text(c, "Gesture accuracy", 16f, Ui.TEXT, true))
        Ui.add(acc, Ui.text(c, "Strictness: how sure the app must be before it acts. If gestures trigger by accident, choose Strict.", 12f, Ui.MUTED), 4)
        Ui.add(acc, segmented(listOf("Relaxed", "Normal", "Strict"), prefs.getInt("strict", 1)) { i ->
            prefs.edit().putInt("strict", i).apply()
            TrackingState.strict = i
        }, 12)
        Ui.add(acc, Ui.text(c, "Tap = flick your thumb away from your middle finger, then touch them together.", 12f, Ui.MUTED), 16)
        tvCal = Ui.text(c, "", 13f, Ui.TEXT, true)
        Ui.add(acc, tvCal, 6)
        val calRow = LinearLayout(c)
        calRow.orientation = LinearLayout.HORIZONTAL
        calRow.addView(Ui.button(c, "Calibrate tap", true) { startActivity(Intent(c, CalibrationActivity::class.java)) },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f))
        val rl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        rl.leftMargin = Ui.dp(c, 8)
        calRow.addView(Ui.button(c, "Reset", false) {
            prefs.edit().remove("tap_on").remove("tap_arm").apply()
            TrackingState.calOn = -1f
            TrackingState.calArm = -1f
            refreshCal()
        }, rl)
        Ui.add(acc, calRow, 6)
        Ui.add(acc, Ui.text(c, "Scroll direction", 12f, Ui.MUTED), 16)
        Ui.add(acc, segmented(listOf("Hand up = page up", "Hand up = page down"), if (prefs.getBoolean("scroll_inv", false)) 1 else 0) { i ->
            prefs.edit().putBoolean("scroll_inv", i == 1).apply()
            TrackingState.scrollInv = (i == 1)
        }, 6)
        Ui.add(col, acc, 14)

        // cursor
        val cur = Ui.card(c)
        cur.addView(Ui.text(c, "Cursor", 16f, Ui.TEXT, true))
        slider(cur, "Speed", "higher = less hand movement", "speed", 1, 10, 5f) { TrackingState.speed = it }
        slider(cur, "Smoothness", "low = fast, high = steady", "smooth", 2, 12, 5f) { TrackingState.smooth = it }
        Ui.add(cur, Ui.text(c, "The cursor moves like a mouse: it follows how far your hand moves. Run out of room? Make a fist, reposition your hand, then point again. The cursor stays where it was.", 12f, Ui.MUTED), 14)
        Ui.add(col, cur, 14)

        // floating preview
        val fp = Ui.card(c)
        fp.addView(Ui.text(c, "Floating hand preview", 16f, Ui.TEXT, true))
        Ui.add(
            fp,
            Ui.text(c, "Auto-hide shows it until your hand is recognised, then hides it and keeps it hidden until you press START again. You still feel a buzz on actions and see the cursor change colour.", 12f, Ui.MUTED),
            4
        )
        Ui.add(fp, segmented(listOf("Auto-hide", "Always on", "Hidden"), prefs.getInt("hud_mode", 1)) { m ->
            prefs.edit().putInt("hud_mode", m).apply()
            MouseAccessibilityService.instance?.setHudMode(m)
        }, 12)
        Ui.add(fp, Ui.text(c, "Position", 12f, Ui.MUTED), 16)
        val corners = LinearLayout(c)
        corners.orientation = LinearLayout.HORIZONTAL
        val labels = listOf("↖", "↗", "↙", "↘")
        for (i in labels.indices) {
            val b = Ui.button(c, labels[i], false) { withService { it.setHudCorner(i) } }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = Ui.dp(c, 6)
            corners.addView(b, lp)
        }
        Ui.add(fp, corners, 6)
        Ui.add(fp, Ui.button(c, "✋  Drag it where you want", false) {
            withService {
                it.showHudForMove()
                toast("The preview box is showing for 12 seconds. Drag it with your finger.")
            }
        }, 8)
        Ui.add(fp, Ui.text(c, "Size", 12f, Ui.MUTED), 14)
        Ui.add(fp, segmented(listOf("Small", "Medium", "Large"), prefs.getInt("hud_scale", 1)) { i ->
            prefs.edit().putInt("hud_scale", i).apply()
            MouseAccessibilityService.instance?.setHudScale(i)
        }, 6)
        Ui.add(col, fp, 14)

        // feel + tools
        val feel = Ui.card(c)
        feel.addView(Ui.text(c, "Feel & tools", 16f, Ui.TEXT, true))
        val sw = Switch(c)
        sw.text = "Vibrate on tap, Back, Home, volume"
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = prefs.getBoolean("haptics", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("haptics", on).apply()
            MouseAccessibilityService.instance?.setHapticsEnabled(on)
        }
        Ui.add(feel, sw, 12)
        Ui.add(feel, Ui.text(c, "Test volume: checks that the phone accepts volume changes from this app, independent of any gesture.", 12f, Ui.MUTED), 14)
        val vrow = LinearLayout(c)
        vrow.orientation = LinearLayout.HORIZONTAL
        vrow.addView(Ui.button(c, "🔊  Louder", false) { testVolume(true) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val dl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        dl.leftMargin = Ui.dp(c, 8)
        vrow.addView(Ui.button(c, "🔉  Quieter", false) { testVolume(false) }, dl)
        Ui.add(feel, vrow, 8)
        Ui.add(col, feel, 14)

        // advanced (collapsed)
        val adv = Ui.card(c)
        val advBody = LinearLayout(c)
        advBody.orientation = LinearLayout.VERTICAL
        advBody.visibility = View.GONE
        val advBtn = Ui.button(c, "Advanced  ▾", false) { }
        advBtn.setOnClickListener {
            val open = advBody.visibility != View.VISIBLE
            advBody.visibility = if (open) View.VISIBLE else View.GONE
            advBtn.text = if (open) "Advanced  ▴" else "Advanced  ▾"
        }
        adv.addView(advBtn)
        slider(advBody, "Tap sensitivity", "used until you calibrate", "tap_sens", 1, 10, 5f) { TrackingState.tapSens = it }
        val diag = Switch(c)
        diag.text = "Show live numbers (diagnostics)"
        diag.setTextColor(Ui.TEXT)
        diag.isChecked = prefs.getBoolean("diag", false)
        diag.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("diag", on).apply() }
        Ui.add(advBody, diag, 18)
        Ui.add(adv, advBody, 8)
        Ui.add(col, adv, 14)

        // about
        val about = Ui.card(c)
        about.addView(Ui.text(c, "About & privacy", 16f, Ui.TEXT, true))
        Ui.add(about, Ui.text(c, "Developer details, privacy policy, permissions explained and open-source credits.", 12f, Ui.MUTED), 4)
        Ui.add(about, Ui.button(c, "Open", false) { startActivity(Intent(c, AboutActivity::class.java)) }, 12)
        Ui.add(col, about, 14)

        Ui.add(col, Ui.text(c, "GestureFlow 1.9", 12f, Ui.MUTED).also { it.gravity = Gravity.CENTER }, 16)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    private fun refreshCal() {
        tvCal.text = if (TrackingState.calOn > 0f) {
            "Tap: calibrated  (taps under ${"%.2f".format(TrackingState.calOn)})"
        } else {
            "Tap: not calibrated yet. Calibrating takes 10 seconds and fixes most missed taps."
        }
    }

    private fun slider(parent: LinearLayout, label: String, hint: String, key: String, lo: Int, hi: Int, def: Float, apply: (Float) -> Unit) {
        val c = this
        val tv = Ui.text(c, "", 14f, Ui.TEXT)
        Ui.add(parent, tv, 16)
        val sb = SeekBar(c)
        sb.max = hi - lo
        sb.progress = (prefs.getFloat(key, def).toInt() - lo).coerceIn(0, hi - lo)
        tv.text = "$label: ${sb.progress + lo}   ($hint)"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = lo + p
                tv.text = "$label: $v   ($hint)"
                apply(v.toFloat())
                if (fromUser) prefs.edit().putFloat(key, v.toFloat()).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        Ui.add(parent, sb, 2)
    }

    // ------------------------------------------------------------------ logic

    private fun withService(block: (MouseAccessibilityService) -> Unit) {
        val s = MouseAccessibilityService.instance
        if (s == null) toast("Enable the accessibility service first (Home tab)") else block(s)
    }

    private fun selectTab(i: Int) {
        currentTab = i
        for (k in pageViews.indices) pageViews[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in tabViews.indices) {
            val sel = k == i
            tabViews[k].setTextColor(if (sel) Color.WHITE else Ui.MUTED)
            tabViews[k].background = if (sel) Ui.gradient(Ui.BLUE, Ui.VIOLET, Ui.dp(this, 22)) else null
        }
    }

    private fun toggle() {
        if (TrackingState.running) {
            stopService(Intent(this, HandTrackingService::class.java))
            toast("Stopped")
            return
        }
        val err = startTracking(this)
        toast(err ?: "Started. Press Home and raise your hand in front of the front camera.")
    }

    private fun testVolume(up: Boolean) = withService { it.volume(up) }

    private fun refresh() {
        val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val acc = MouseAccessibilityService.instance != null
        tvCam.text = if (cam) "Allowed ✅" else "Tap to allow"
        tvCam.setTextColor(if (cam) Ui.GOOD else Ui.WARN)
        tvAcc.text = if (acc) "Enabled ✅" else "Tap to enable"
        tvAcc.setTextColor(if (acc) Ui.GOOD else Ui.WARN)
        helpBtn.visibility = if (acc) View.GONE else View.VISIBLE
        val allSet = cam && acc

        val running = TrackingState.running
        if (running) {
            Ui.setChip(
                chipStatus,
                "● ${TrackingState.statusLine()}  |  ${TrackingState.fps} fps" + if (TrackingState.has3d) "  |  3D" else "",
                TrackingState.color()
            )
        } else {
            Ui.setChip(chipStatus, "● Not running", Color.rgb(170, 185, 220))
        }
        if (running && prefs.getBoolean("diag", false)) {
            tvDebug.text = TrackingState.debug
            tvDebug.visibility = View.VISIBLE
        } else {
            tvDebug.visibility = View.GONE
        }
        tvHint.text = when {
            !allSet -> "Finish the two setup tiles below, then press Start."
            running -> "Press Home to use your phone. The floating box hides itself once your hand is recognised."
            else -> "Press Start, then raise your hand in front of the front camera."
        }
        if (lastRunning != running) {
            lastRunning = running
            btnToggle.text = if (running) "■  Stop" else "▶  Start tracking"
            if (running) Ui.restyle(btnToggle, Ui.BAD) else Ui.styleButton(btnToggle, true)
        }
    }

    override fun onResume() {
        super.onResume()
        TrackingState.inApp = true // this screen has its own 3D view, so hide the floating box
        TrackingState.wantDebug = prefs.getBoolean("diag", false)
        TrackingState.calOn = prefs.getFloat("tap_on", -1f)
        TrackingState.calArm = prefs.getFloat("tap_arm", -1f)
        refreshCal()
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        TrackingState.inApp = false
        TrackingState.wantDebug = false
        MouseAccessibilityService.instance?.refreshHud()
        ui.removeCallbacks(tick)
    }

    private fun segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val c = this
        val rowView = LinearLayout(c)
        rowView.orientation = LinearLayout.HORIZONTAL
        val btns = ArrayList<Button>()
        fun select(k: Int) {
            for (j in btns.indices) Ui.styleButton(btns[j], j == k)
            onSelect(k)
        }
        for (i in labels.indices) {
            val b = Ui.button(c, labels[i], i == selected) { }
            b.textSize = 13f
            b.setOnClickListener { select(i) }
            btns.add(b)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = Ui.dp(c, 6)
            rowView.addView(b, lp)
        }
        return rowView
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private val TILES = listOf(
            Tile("MOVE", "Move", "Index finger up, others folded. Moves like a mouse."),
            Tile("TAP", "Tap", "Flick thumb away from your middle finger, then touch them."),
            Tile("SCROLL", "Scroll", "Open hand, hold still, then move up or down."),
            Tile("PAGE", "Slide pages", "Open hand, hold still, then move left or right."),
            Tile("VOLUME", "Volume", "Pinky only, hold still, then hand up or down."),
            Tile("DONE", "Task done", "Hold a fist when finished. Resets and waits."),
            Tile("BACK", "Back", "Index + middle up (V). Hold."),
            Tile("HOME", "Home", "Index + middle + ring up. Hold.")
        )
    }
}
