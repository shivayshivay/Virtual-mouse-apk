package com.example.virtualmouse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = HELP; textSize = 15f })

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        button("1. Allow camera") {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        button("2a. Open App info (allow restricted settings)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("2b. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("3. START virtual mouse") {
            when {
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ->
                    toast("Allow the camera first (step 1)")
                MouseAccessibilityService.instance == null ->
                    toast("Enable Virtual Mouse in Accessibility settings first (step 2)")
                else -> {
                    ContextCompat.startForegroundService(this, Intent(this, HandTrackingService::class.java))
                    toast("Started. Press Home and use your hand.")
                }
            }
        }
        button("STOP") {
            stopService(Intent(this, HandTrackingService::class.java))
            toast("Stopped")
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val HELP = """VIRTUAL MOUSE
Prop the phone up so the FRONT camera sees your hand.

Gestures:
- Index finger up: move cursor
- Thumb + middle finger pinch: tap
- Thumb + ring finger pinch: Back
- Thumb + pinky pinch: Home
- Open palm, then move it up/down: scroll (at the cursor position)
- Fist: pause (cursor turns faint)
"""
    }
}
