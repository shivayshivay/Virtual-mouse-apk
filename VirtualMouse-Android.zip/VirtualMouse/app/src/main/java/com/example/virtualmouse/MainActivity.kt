package com.example.virtualmouse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var chipStatus: TextView
    private lateinit var btnToggle: Button
    private lateinit var tvCamIcon: TextView
    private lateinit var tvAccIcon: TextView
    private var lastRunning: Boolean? = null

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        TrackingState.smooth = prefs.getFloat("smooth", 5f)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val pad = Ui.dp(ctx, 16)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad * 2)
        }

        // ---- header ----
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = ImageView(ctx)
        icon.setImageResource(R.mipmap.ic_launcher)
        header.addView(icon, LinearLayout.LayoutParams(Ui.dp(ctx, 60), Ui.dp(ctx, 60)))
        val titles = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(ctx, 14), 0, 0, 0)
        }
        titles.addView(Ui.text(ctx, "Virtual Mouse", 24f, Ui.TEXT, true))
        titles.addView(Ui.text(ctx, "Control your phone with your hand", 13f, Ui.MUTED))
        header.addView(titles)
        col.addView(header)

        // ---- status + start/stop ----
        val status = Ui.card(ctx)
        chipStatus = Ui.chip(ctx, "Not running", Ui.MUTED)
        status.addView(chipStatus)
        btnToggle = Ui.button(ctx, "Start virtual mouse", true) { toggle() }
        Ui.add(status, btnToggle, 12)
        Ui.add(
            status,
            Ui.text(ctx, "After starting, press Home. A small preview box at the top-right shows what the camera sees.", 12f, Ui.MUTED),
            8
        )
        Ui.add(col, status, 16)

        // ---- setup ----
        val setup = Ui.card(ctx)
        setup.addView(Ui.text(ctx, "Setup", 18f, Ui.TEXT, true))
        tvCamIcon = row(setup, "Camera", "Needed to see your hand", "Allow") {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        tvAccIcon = row(setup, "Accessibility service", "Lets the app move a cursor and tap for you", "Enable") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        Ui.add(
            setup,
            Ui.button(ctx, "Switch greyed out? Open App info", false) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            },
            14
        )
        Ui.add(col, setup, 14)

        // ---- gestures ----
        val g = Ui.card(ctx)
        g.addView(Ui.text(ctx, "Gestures", 18f, Ui.TEXT, true))
        for ((e, t) in GESTURES) Ui.add(g, gestureRow(e, t), 10)
        Ui.add(g, Ui.button(ctx, "Open interactive tutorial", true) {
            startActivity(Intent(ctx, TutorialActivity::class.java))
        }, 14)
        Ui.add(col, g, 14)

        // ---- settings ----
        val s = Ui.card(ctx)
        s.addView(Ui.text(ctx, "Settings", 18f, Ui.TEXT, true))
        val sw = Switch(ctx)
        sw.text = "Show live hand preview"
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = prefs.getBoolean("hud", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("hud", on).apply()
            MouseAccessibilityService.instance?.setHudEnabled(on)
        }
        Ui.add(s, sw, 12)

        val tvSmooth = Ui.text(ctx, "", 14f, Ui.TEXT)
        Ui.add(s, tvSmooth, 16)
        val bar = SeekBar(ctx)
        bar.max = 10
        bar.progress = (TrackingState.smooth - 2f).toInt().coerceIn(0, 10)
        tvSmooth.text = "Cursor smoothness: ${bar.progress + 2}  (low = fast, high = steady)"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                TrackingState.smooth = 2f + p
                tvSmooth.text = "Cursor smoothness: ${p + 2}  (low = fast, high = steady)"
                if (fromUser) prefs.edit().putFloat("smooth", 2f + p).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        Ui.add(s, bar, 4)
        Ui.add(col, s, 14)

        Ui.add(
            col,
            Ui.text(ctx, "Camera frames are processed on your phone and are never saved or uploaded.", 12f, Ui.MUTED)
                .apply { gravity = Gravity.CENTER },
            16
        )

        setContentView(ScrollView(ctx).apply {
            setBackgroundColor(Ui.BG)
            addView(col)
        })

        if (!prefs.getBoolean("tutorial_done", false)) {
            startActivity(Intent(ctx, TutorialActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    private fun toggle() {
        if (TrackingState.running) {
            stopService(Intent(this, HandTrackingService::class.java))
            toast("Stopped")
            return
        }
        val err = startTracking(this)
        toast(err ?: "Started. Press Home and watch the preview box at the top-right.")
    }

    private fun refresh() {
        val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val acc = MouseAccessibilityService.instance != null
        tvCamIcon.text = if (cam) "✅" else "⭕"
        tvAccIcon.text = if (acc) "✅" else "⭕"

        val running = TrackingState.running
        if (running) {
            Ui.setChip(chipStatus, "● Running  |  ${TrackingState.statusLine()}  |  ${TrackingState.fps} fps", TrackingState.color())
        } else {
            Ui.setChip(chipStatus, "● Not running", Ui.MUTED)
        }
        if (lastRunning != running) {
            lastRunning = running
            btnToggle.text = if (running) "Stop" else "Start virtual mouse"
            Ui.restyle(btnToggle, if (running) Ui.BAD else Ui.ACCENT)
        }
    }

    private fun row(parent: LinearLayout, title: String, desc: String, btn: String, onClick: () -> Unit): TextView {
        val c = this
        val r = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = Ui.text(c, "⭕", 22f)
        r.addView(icon)
        val mid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(c, 10), 0, Ui.dp(c, 8), 0)
        }
        mid.addView(Ui.text(c, title, 15f, Ui.TEXT, true))
        mid.addView(Ui.text(c, desc, 12f, Ui.MUTED))
        r.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Ui.button(c, btn, false, onClick))
        Ui.add(parent, r, 14)
        return icon
    }

    private fun gestureRow(e: String, t: String): LinearLayout {
        val c = this
        return LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(Ui.text(c, e, 22f), LinearLayout.LayoutParams(Ui.dp(c, 40), LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(Ui.text(c, t, 14f, Ui.TEXT))
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private val GESTURES = listOf(
            "☝️" to "Index finger up, thumb away: move the cursor",
            "🤏" to "While pointing, touch thumb to index tip: tap",
            "✋" to "Open hand, hold still, then raise / lower: scroll up / down",
            "↔️" to "Open hand, hold still, then move right / left: next / previous page",
            "👌" to "OK sign, then hand toward / away: zoom in / out",
            "✊" to "Fist: pause",
            "↩️" to "Index + middle up (V), hold: Back",
            "🏠" to "Index + middle + ring up, hold: Home"
        )
    }
}
