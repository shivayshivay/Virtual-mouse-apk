package com.example.virtualmouse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var pageViews: List<View>
    private lateinit var tabViews: List<TextView>
    private lateinit var hero: TextView
    private lateinit var chipStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvCamIcon: TextView
    private lateinit var tvAccIcon: TextView
    private lateinit var setupDetail: LinearLayout
    private lateinit var setupDone: TextView
    private lateinit var liveCard: LinearLayout
    private lateinit var preview: HandPreviewView
    private var lastRunning: Boolean? = null
    private var ticks = 0

    private val tick = object : Runnable {
        override fun run() {
            ticks++
            if (liveCard.visibility == View.VISIBLE) preview.invalidate()
            if (ticks % 4 == 0) refresh()
            ui.postDelayed(this, 70)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = this
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        TrackingState.smooth = prefs.getFloat("smooth", 5f)
        TrackingState.scrollInv = prefs.getBoolean("scroll_inv", false)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.CARD
        val pad = Ui.dp(c, 16)

        pageViews = listOf(buildHome(pad), buildGestures(pad), buildSettings(pad))
        val content = FrameLayout(c)
        for (p in pageViews) {
            content.addView(p, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }

        fun tab(emoji: String, label: String, i: Int): TextView {
            val t = Ui.text(c, "$emoji\n$label", 12f, Ui.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, Ui.dp(c, 10), 0, Ui.dp(c, 10))
            t.setOnClickListener { selectTab(i) }
            return t
        }
        tabViews = listOf(tab("🏠", "Home", 0), tab("✋", "Gestures", 1), tab("⚙️", "Settings", 2))
        val bar = LinearLayout(c)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Ui.CARD)
        for (t in tabViews) bar.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bar)
        setContentView(root)
        selectTab(0)

        if (!prefs.getBoolean("tutorial_done", false)) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }
    }

    // ------------------------------------------------------------------ Home

    private fun buildHome(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)

        val header = LinearLayout(c)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val icon = ImageView(c)
        icon.setImageResource(R.mipmap.ic_launcher)
        header.addView(icon, LinearLayout.LayoutParams(Ui.dp(c, 52), Ui.dp(c, 52)))
        val titles = LinearLayout(c)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(Ui.dp(c, 12), 0, 0, 0)
        titles.addView(Ui.text(c, "Virtual Mouse", 22f, Ui.TEXT, true))
        titles.addView(Ui.text(c, "Control your phone with your hand", 12f, Ui.MUTED))
        header.addView(titles)
        col.addView(header)

        // big start / stop button
        val heroCard = Ui.card(c)
        hero = TextView(c)
        hero.text = "START"
        hero.textSize = 22f
        hero.setTextColor(Color.WHITE)
        hero.setTypeface(hero.typeface, Typeface.BOLD)
        hero.gravity = Gravity.CENTER
        hero.background = Ui.gradientCircle(Ui.ACCENT, Ui.TEAL)
        hero.setOnClickListener { toggle() }
        val hlp = LinearLayout.LayoutParams(Ui.dp(c, 150), Ui.dp(c, 150))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.topMargin = Ui.dp(c, 8)
        heroCard.addView(hero, hlp)
        chipStatus = Ui.chip(c, "Not running", Ui.MUTED)
        Ui.add(heroCard, chipStatus, 16)
        tvHint = Ui.text(c, "", 12f, Ui.MUTED)
        tvHint.gravity = Gravity.CENTER
        Ui.add(heroCard, tvHint, 8)
        Ui.add(col, heroCard, 16)

        // setup (collapses to one line when everything is done)
        val setup = Ui.card(c)
        setup.addView(Ui.text(c, "Setup", 18f, Ui.TEXT, true))
        setupDone = Ui.chip(c, "✅  Setup complete", Ui.GOOD)
        Ui.add(setup, setupDone, 10)
        setupDetail = LinearLayout(c)
        setupDetail.orientation = LinearLayout.VERTICAL
        tvCamIcon = row(setupDetail, "Camera", "Needed to see your hand", "Allow") {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        tvAccIcon = row(setupDetail, "Accessibility service", "Lets the app move a cursor and tap for you", "Enable") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        Ui.add(setupDetail, Ui.button(c, "Switch greyed out? Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, 14)
        Ui.add(setup, setupDetail, 0)
        Ui.add(col, setup, 14)

        // in-app live view (shown while tracking)
        liveCard = Ui.card(c)
        liveCard.addView(Ui.text(c, "Live view", 18f, Ui.TEXT, true))
        Ui.add(liveCard, Ui.text(c, "What the camera sees. The skeleton should sit on your hand.", 12f, Ui.MUTED), 4)
        preview = HandPreviewView(c, c.resources.displayMetrics.density)
        val plp = LinearLayout.LayoutParams(Ui.dp(c, 216), Ui.dp(c, 316))
        plp.gravity = Gravity.CENTER_HORIZONTAL
        plp.topMargin = Ui.dp(c, 12)
        liveCard.addView(preview, plp)
        liveCard.visibility = View.GONE
        Ui.add(col, liveCard, 14)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    // ------------------------------------------------------------------ Gestures

    private fun buildGestures(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Gestures", 22f, Ui.TEXT, true))
        Ui.add(col, Ui.text(c, "Keep your hand about 30-50 cm from the front camera, palm facing it.", 13f, Ui.MUTED), 4)
        Ui.add(col, Ui.button(c, "Open interactive tutorial", true) {
            startActivity(Intent(c, TutorialActivity::class.java))
        }, 14)
        for ((e, title, desc) in GESTURES) {
            val card = Ui.card(c)
            val r = LinearLayout(c)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.addView(Ui.text(c, e, 30f), LinearLayout.LayoutParams(Ui.dp(c, 52), LinearLayout.LayoutParams.WRAP_CONTENT))
            val txt = LinearLayout(c)
            txt.orientation = LinearLayout.VERTICAL
            txt.addView(Ui.text(c, title, 16f, Ui.TEXT, true))
            txt.addView(Ui.text(c, desc, 13f, Ui.MUTED))
            r.addView(txt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(r)
            Ui.add(col, card, 10)
        }
        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    // ------------------------------------------------------------------ Settings

    private fun buildSettings(pad: Int): ScrollView {
        val c = this
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad * 2)
        col.addView(Ui.text(c, "Settings", 22f, Ui.TEXT, true))

        val prev = Ui.card(c)
        prev.addView(Ui.text(c, "Hand preview box", 16f, Ui.TEXT, true))
        Ui.add(
            prev,
            Ui.text(c, "Auto-hide shows it until your hand is recognised, then hides it. It comes back if your hand is lost for 2 seconds. You still feel a buzz on actions and see the cursor change colour.", 12f, Ui.MUTED),
            4
        )
        Ui.add(prev, segmented(listOf("Auto-hide", "Always on", "Hidden"), prefs.getInt("hud_mode", 1)) { m ->
            prefs.edit().putInt("hud_mode", m).apply()
            MouseAccessibilityService.instance?.setHudMode(m)
        }, 12)
        Ui.add(col, prev, 14)

        val scrollCard = Ui.card(c)
        scrollCard.addView(Ui.text(c, "Scroll direction", 16f, Ui.TEXT, true))
        Ui.add(scrollCard, Ui.text(c, "Choose how your open hand moves the page.", 12f, Ui.MUTED), 4)
        Ui.add(scrollCard, segmented(listOf("Hand up = page up", "Hand up = page down"), if (prefs.getBoolean("scroll_inv", false)) 1 else 0) { i ->
            prefs.edit().putBoolean("scroll_inv", i == 1).apply()
            TrackingState.scrollInv = (i == 1)
        }, 12)
        Ui.add(col, scrollCard, 14)

        val feel = Ui.card(c)
        feel.addView(Ui.text(c, "Feel", 16f, Ui.TEXT, true))
        val sw = Switch(c)
        sw.text = "Vibrate on tap, Back, Home, zoom"
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = prefs.getBoolean("haptics", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("haptics", on).apply()
            MouseAccessibilityService.instance?.setHapticsEnabled(on)
        }
        Ui.add(feel, sw, 12)
        val tvSmooth = Ui.text(c, "", 14f, Ui.TEXT)
        Ui.add(feel, tvSmooth, 16)
        val bar = SeekBar(c)
        bar.max = 10
        bar.progress = (TrackingState.smooth - 2f).toInt().coerceIn(0, 10)
        tvSmooth.text = "Cursor smoothness: ${bar.progress + 2}  (low = fast, high = steady)"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                TrackingState.smooth = 2f + p
                tvSmooth.text = "Cursor smoothness: ${p + 2}  (low = fast, high = steady)"
                if (fromUser) prefs.edit().putFloat("smooth", 2f + p).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        Ui.add(feel, bar, 4)
        Ui.add(col, feel, 14)

        val sec = Ui.card(c)
        sec.addView(Ui.text(c, "Privacy & security", 16f, Ui.TEXT, true))
        Ui.add(
            sec,
            Ui.text(
                c,
                "• Camera images are analysed on your phone only. They are never saved or sent anywhere.\n\n" +
                    "• The app does not request internet permission.\n\n" +
                    "• The accessibility service is only used to draw the cursor and perform taps, swipes, pinch-zoom, Back and Home. It is not given access to read your screen or key presses.\n\n" +
                    "• The camera stops automatically when the screen turns off, or after 5 minutes without a hand.\n\n" +
                    "• A notification and Android's camera indicator show whenever the camera is on.",
                13f, Ui.MUTED
            ),
            8
        )
        Ui.add(col, sec, 14)
        Ui.add(col, Ui.text(c, "Virtual Mouse 1.5", 12f, Ui.MUTED).also { it.gravity = Gravity.CENTER }, 16)

        val sv = ScrollView(c)
        sv.addView(col)
        return sv
    }

    // ------------------------------------------------------------------ logic

    private fun selectTab(i: Int) {
        for (k in pageViews.indices) pageViews[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in tabViews.indices) tabViews[k].setTextColor(if (k == i) Ui.ACCENT else Ui.MUTED)
    }

    private fun toggle() {
        if (TrackingState.running) {
            stopService(Intent(this, HandTrackingService::class.java))
            toast("Stopped")
            return
        }
        val err = startTracking(this)
        toast(err ?: "Started. Press Home and raise your hand in front of the front camera.")
    }

    private fun refresh() {
        val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val acc = MouseAccessibilityService.instance != null
        tvCamIcon.text = if (cam) "✅" else "⭕"
        tvAccIcon.text = if (acc) "✅" else "⭕"
        val allSet = cam && acc
        setupDetail.visibility = if (allSet) View.GONE else View.VISIBLE
        setupDone.visibility = if (allSet) View.VISIBLE else View.GONE

        val running = TrackingState.running
        liveCard.visibility = if (running) View.VISIBLE else View.GONE
        if (running) {
            Ui.setChip(chipStatus, "● ${TrackingState.statusLine()}  |  ${TrackingState.fps} fps" + if (TrackingState.has3d) "  |  3D" else "", TrackingState.color())
        } else {
            Ui.setChip(chipStatus, "● Not running", Ui.MUTED)
        }
        tvHint.text = when {
            !allSet -> "Finish the setup below, then press START."
            running -> "Press Home to use your phone. The preview box hides itself once your hand is recognised."
            else -> "Press START, then raise your hand in front of the front camera."
        }
        if (lastRunning != running) {
            lastRunning = running
            hero.text = if (running) "STOP" else "START"
            hero.background = if (running) Ui.gradientCircle(Ui.BAD, Ui.WARN) else Ui.gradientCircle(Ui.ACCENT, Ui.TEAL)
        }
    }

    override fun onResume() {
        super.onResume()
        TrackingState.inApp = true // this screen has its own live view, so hide the floating box
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        TrackingState.inApp = false
        MouseAccessibilityService.instance?.refreshHud()
        ui.removeCallbacks(tick)
    }

    private fun row(parent: LinearLayout, title: String, desc: String, btn: String, onClick: () -> Unit): TextView {
        val c = this
        val r = LinearLayout(c)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val icon = Ui.text(c, "⭕", 22f)
        r.addView(icon)
        val mid = LinearLayout(c)
        mid.orientation = LinearLayout.VERTICAL
        mid.setPadding(Ui.dp(c, 10), 0, Ui.dp(c, 8), 0)
        mid.addView(Ui.text(c, title, 15f, Ui.TEXT, true))
        mid.addView(Ui.text(c, desc, 12f, Ui.MUTED))
        r.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Ui.button(c, btn, false, onClick))
        Ui.add(parent, r, 14)
        return icon
    }

    private fun segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val c = this
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        val btns = ArrayList<Button>()
        fun select(k: Int) {
            for (j in btns.indices) Ui.restyle(btns[j], if (j == k) Ui.ACCENT else Ui.CARD2)
            onSelect(k)
        }
        for (i in labels.indices) {
            val b = Ui.button(c, labels[i], i == selected) { }
            b.textSize = 13f
            b.setOnClickListener { select(i) }
            btns.add(b)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = Ui.dp(c, 6)
            row.addView(b, lp)
        }
        return row
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private val GESTURES = listOf(
            Triple("☝️", "Move", "Index finger up, other fingers folded, thumb away from your index tip. The cursor follows your index knuckle."),
            Triple("🤏", "Tap", "While pointing, touch your thumb to your index fingertip."),
            Triple("✋", "Scroll", "Open hand. Hold still until the ring around the cursor fills, then move your hand up or down from the centre. The farther, the faster."),
            Triple("↔️", "Slide pages", "Open hand, hold still, then move it right for the next page or left for the previous page."),
            Triple("👌", "Zoom", "OK sign (thumb touches index, other fingers up), then move your hand toward the camera to zoom in or away to zoom out."),
            Triple("👍", "Volume", "Thumbs-up raises the volume, thumbs-down lowers it. Hold: it repeats while you hold."),
            Triple("✊", "Task done", "Make a fist when you have finished something. The app resets, buzzes and waits for your next command."),
            Triple("↩️", "Back", "Index + middle fingers up (V sign). Hold until the ring around the cursor fills."),
            Triple("🏠", "Home", "Index + middle + ring fingers up. Hold until the ring fills.")
        )
    }
}
