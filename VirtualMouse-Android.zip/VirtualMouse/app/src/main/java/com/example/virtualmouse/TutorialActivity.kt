package com.example.virtualmouse

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Step-by-step tutorial. A 3D hand performs each gesture; each step ticks green when YOU do it. */
class TutorialActivity : Activity() {

    private class Step(val title: String, val pose: String, val body: String, val tip: String?, val target: String?)

    private val steps = listOf(
        Step("Set up your phone", "OPEN",
            "Prop your phone upright so the FRONT camera sees your hand from about 30-50 cm. Put light in front of you, not behind.",
            "Tap 'Start tracking' below to practise every step live.", null),
        Step("Check your hand is captured", "OPEN",
            "The small box at the top-right shows your hand as a glowing 3D model. If it follows your hand, you are captured.",
            "Outside this tutorial the box hides itself once your hand is recognised. Cursor colours: red = no hand, orange = hand found, green = moving, blue = open hand, teal = volume, grey = done.",
            "HAND"),
        Step("Move the cursor", "MOVE",
            "Raise your index finger and fold the others. Move your hand like a mouse.",
            "Out of room? Make a fist, move your hand back, then point again. The cursor stays exactly where you left it.",
            "MOVE"),
        Step("Tap", "TAP",
            "Keep your index finger up. Flick your thumb away from your middle finger, then touch them together.",
            "Not tapping? Press 'Calibrate tap' below: it measures your own hand so the tap fits you. The grey numbers show the thumb-middle distance and READY when the next touch will tap.",
            "TAP"),
        Step("Scroll", "SCROLL",
            "Open your hand and hold still until the ring fills around the cursor. Then move your hand up or down: the farther, the faster.",
            "Aim the cursor first. Go back to the centre to stop. Wrong way round? Flip it in Settings.",
            "SCROLL"),
        Step("Slide pages", "PAGE",
            "Open your hand, hold still, then move it right for the next page or left for the previous page. Try the pages below.",
            "Return to the centre before the next slide.",
            "SWIPE"),
        Step("Volume", "VOLUME",
            "Raise only your pinky and hold still until the ring fills. Then move your hand up for louder or down for quieter.",
            "A thumbs-up or thumbs-down held for a moment also works. No reaction? Try Settings > Test volume.",
            "VOLUME"),
        Step("Task done", "DONE",
            "When you finish something, make a fist and hold it for a moment. The app resets, buzzes, and waits for your next command.",
            "Open your hand again when you are ready to start the next task.",
            "PAUSED"),
        Step("Back", "BACK",
            "Hold your index and middle fingers up (a V sign) until the ring around the cursor fills. Back is pressed.",
            "This tutorial stays open on purpose; the green tick confirms it worked.",
            "BACK"),
        Step("Home", "HOME",
            "Hold your index, middle and ring fingers up until the ring fills. Home is pressed and the app leaves the screen.",
            "Re-open GestureFlow from recent apps.",
            "HOME"),
        Step("You're ready", "OPEN",
            "You're all set. Change speed, strictness and the floating box in Settings.",
            "If gestures ever trigger by accident, set Settings > Strictness to Strict.",
            null)
    )

    private var index = 0
    private var taps = 0
    private var ticks = 0
    private val detected = BooleanArray(steps.size)
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var dots: LinearLayout
    private lateinit var tvProgress: TextView
    private lateinit var demoView: HandPreviewView
    private lateinit var tvTitle: TextView
    private lateinit var tvBody: TextView
    private lateinit var tvTip: TextView
    private lateinit var tvTrack: TextView
    private lateinit var chipCheck: TextView
    private lateinit var btnTap: Button
    private lateinit var btnCal: Button
    private lateinit var pager: HorizontalScrollView
    private lateinit var btnStart: Button
    private lateinit var btnPrev: Button
    private lateinit var btnNext: Button

    private val poll = object : Runnable {
        override fun run() {
            ticks++
            demoView.invalidate() // the demo hand keeps moving
            if (ticks % 3 == 0) refresh()
            ui.postDelayed(this, 50)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Ui.applyTheme(this)
        setTheme(Ui.themeRes())
        super.onCreate(savedInstanceState)
        val c = this
        Ui.systemBars(this)
        val pad = Ui.dp(c, 16)

        val outer = LinearLayout(c)
        outer.orientation = LinearLayout.VERTICAL
        outer.setBackgroundColor(Ui.BG)
        val content = LinearLayout(c)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(pad, pad, pad, pad)
        val sv = ScrollView(c)
        sv.addView(content)
        outer.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // progress dots
        dots = LinearLayout(c)
        dots.orientation = LinearLayout.HORIZONTAL
        dots.gravity = Gravity.CENTER
        for (i in steps.indices) {
            val lp = LinearLayout.LayoutParams(Ui.dp(c, 9), Ui.dp(c, 9))
            lp.setMargins(Ui.dp(c, 3), 0, Ui.dp(c, 3), 0)
            dots.addView(View(c), lp)
        }
        content.addView(dots)
        tvProgress = Ui.text(c, "", 12f, Ui.MUTED)
        tvProgress.gravity = Gravity.CENTER
        Ui.add(content, tvProgress, 8)

        // the animated 3D hand
        val viewport = FrameLayout(c)
        viewport.background = Ui.shape(Color.rgb(6, 10, 22), Ui.dp(c, 24)).apply {
            setStroke(Ui.dp(c, 1), Ui.tint(Ui.ACCENT, 130))
        }
        demoView = HandPreviewView(c, c.resources.displayMetrics.density)
        demoView.showStrip = false
        demoView.cornerDp = 24f
        demoView.demo = "OPEN"
        viewport.addView(demoView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val watch = Ui.chip(c, "▶  Watch how", Color.rgb(170, 185, 220))
        val wl = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        wl.setMargins(Ui.dp(c, 12), Ui.dp(c, 12), 0, 0)
        viewport.addView(watch, wl)
        val vl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 250))
        vl.topMargin = Ui.dp(c, 10)
        content.addView(viewport, vl)

        // text
        val card = Ui.card(c)
        tvTitle = Ui.text(c, "", 22f, Ui.TEXT, true)
        card.addView(tvTitle)
        tvBody = Ui.text(c, "", 16f, Ui.TEXT)
        Ui.add(card, tvBody, 8)
        tvTip = Ui.text(c, "", 13f, Ui.MUTED)
        Ui.add(card, tvTip, 10)

        btnTap = Ui.button(c, "Tap me with your hand!  (0)", true) {
            taps++
            btnTap.text = "Tap me with your hand!  ($taps)"
        }
        Ui.add(card, btnTap, 14)
        btnCal = Ui.button(c, "Calibrate tap", false) { startActivity(Intent(c, CalibrationActivity::class.java)) }
        Ui.add(card, btnCal, 10)
        val pageW = resources.displayMetrics.widthPixels - Ui.dp(c, 68)
        pager = buildPager(c, pageW)
        Ui.add(card, pager, 14)

        chipCheck = Ui.chip(c, "", Ui.MUTED)
        Ui.add(card, chipCheck, 14)
        Ui.add(content, card, 12)

        tvTrack = Ui.text(c, "", 11f, Ui.MUTED)
        tvTrack.typeface = android.graphics.Typeface.MONOSPACE
        tvTrack.gravity = Gravity.CENTER
        Ui.add(content, tvTrack, 12)
        btnStart = Ui.button(c, "Start tracking", true) {
            startTracking(this@TutorialActivity)?.let {
                Toast.makeText(this@TutorialActivity, it, Toast.LENGTH_LONG).show()
            }
        }
        Ui.add(content, btnStart, 8)

        // bottom bar
        btnPrev = Ui.button(c, "Previous", false) { if (index > 0) { index--; render() } }
        val btnSkip = Ui.button(c, "Skip", false) { finishTutorial() }
        btnNext = Ui.button(c, "Next", true) {
            if (index < steps.size - 1) { index++; render() } else finishTutorial()
        }
        val bar = LinearLayout(c)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Ui.CARD)
        bar.setPadding(pad, Ui.dp(c, 10), pad, Ui.dp(c, 14))
        val gap = Ui.dp(c, 8)
        bar.addView(btnPrev, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(btnSkip, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = gap })
        bar.addView(btnNext, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f).apply { leftMargin = gap })
        outer.addView(bar)

        setContentView(outer)
        render()
    }

    private fun buildPager(c: Context, pageW: Int): HorizontalScrollView {
        val hs = HorizontalScrollView(c)
        hs.isHorizontalScrollBarEnabled = false
        hs.overScrollMode = View.OVER_SCROLL_NEVER
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        val colors = intArrayOf(Ui.ACCENT, Ui.TEAL, Ui.WARN, Ui.BAD)
        for (i in 0 until 4) {
            val t = Ui.text(c, "Page ${i + 1}", 22f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.background = Ui.shape(colors[i], Ui.dp(c, 16))
            row.addView(t, LinearLayout.LayoutParams(pageW, Ui.dp(c, 110)))
        }
        hs.addView(row)
        hs.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                hs.postDelayed({
                    val page = ((hs.scrollX + pageW / 2) / pageW).coerceIn(0, 3)
                    hs.smoothScrollTo(page * pageW, 0)
                }, 120)
            }
            false
        }
        return hs
    }

    private fun render() {
        val s = steps[index]
        tvProgress.text = "Step ${index + 1} of ${steps.size}"
        demoView.demo = s.pose
        tvTitle.text = s.title
        tvBody.text = s.body
        tvTip.text = if (s.tip != null) "💡  ${s.tip}" else ""
        tvTip.visibility = if (s.tip != null) View.VISIBLE else View.GONE
        btnTap.visibility = if (s.target == "TAP") View.VISIBLE else View.GONE
        btnCal.visibility = if (s.target == "TAP") View.VISIBLE else View.GONE
        pager.visibility = if (s.target == "SWIPE") View.VISIBLE else View.GONE
        btnPrev.isEnabled = index > 0
        btnPrev.alpha = if (index > 0) 1f else 0.4f
        btnNext.text = if (index == steps.size - 1) "Finish" else "Next"
        refresh()
    }

    private fun refresh() {
        val live = TrackingState.running && MouseAccessibilityService.instance != null
        btnStart.visibility = if (live) View.GONE else View.VISIBLE
        tvTrack.text = if (live) {
            "Tracking ON  |  ${TrackingState.statusLine()}  |  ${TrackingState.fps} fps\n${TrackingState.debug}"
        } else {
            "Tracking is OFF. Start it to practise live, or just press Next."
        }

        val target = steps[index].target
        if (target == null) {
            chipCheck.visibility = View.GONE
        } else {
            chipCheck.visibility = View.VISIBLE
            if (!detected[index] && TrackingState.matches(target)) detected[index] = true
            if (detected[index]) {
                Ui.setChip(chipCheck, "✅  Detected! Great job.", Ui.GOOD)
            } else {
                Ui.setChip(
                    chipCheck,
                    if (live) "⏳  Waiting for your gesture..." else "Start tracking to see this tick green",
                    Ui.MUTED
                )
            }
        }
        for (i in steps.indices) {
            val col = when {
                i == index -> Ui.ACCENT
                detected[i] -> Ui.GOOD
                else -> Ui.CARD2
            }
            dots.getChildAt(i).background = Ui.dot(col)
        }
    }

    private fun finishTutorial() {
        getSharedPreferences("vm", MODE_PRIVATE).edit().putBoolean("tutorial_done", true).apply()
        finish()
    }

    override fun onResume() {
        super.onResume()
        TrackingState.forceHud = true // keep the floating preview visible while learning
        TrackingState.wantDebug = true
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(poll)
    }

    override fun onPause() {
        refresh() // catches the HOME gesture right as the app leaves the screen
        ui.removeCallbacks(poll)
        TrackingState.forceHud = false
        TrackingState.wantDebug = false
        MouseAccessibilityService.instance?.refreshHud()
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // A Back caused by the BACK gesture should not close the tutorial.
        if (TrackingState.eventRecent("BACK", 900L)) return
        super.onBackPressed()
    }
}
