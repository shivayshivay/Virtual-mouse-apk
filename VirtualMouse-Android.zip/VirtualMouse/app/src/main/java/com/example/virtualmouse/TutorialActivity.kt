package com.example.virtualmouse

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Step-by-step tutorial. Each step ticks green when the gesture is really detected. */
class TutorialActivity : Activity() {

    private class Step(val emoji: String, val title: String, val body: String, val target: String?)

    private val steps = listOf(
        Step("📱", "Set up your phone",
            "Prop the phone upright (stand or books) so the FRONT camera sees your hand from about 30-50 cm. " +
                "Put light in front of you, not behind.\n\n" +
                "Tap 'Start tracking' below to practise every step live.", null),
        Step("👀", "Check your hand is captured",
            "Look at the small dark preview box at the TOP-RIGHT of the screen.\n\n" +
                "- A blue skeleton is drawn on your hand when it is captured.\n" +
                "- '3D' next to the fps means depth tracking is active.\n" +
                "- The big dot on your index KNUCKLE is the point that moves the cursor.\n" +
                "- The line between thumb tip and index tip is white, amber when close, cyan on a tap.\n" +
                "- Outside this tutorial the box hides itself shortly after your hand is recognised.\n\n" +
                "Label colours: red = no hand, orange = hand found, green = moving, blue = open hand, " +
                "purple = zoom, teal = volume, gray = done/paused, cyan flash = an action fired.", "HAND"),
        Step("☝️", "Move the cursor",
            "Raise ONLY your index finger, fold the other three, and keep your thumb AWAY from your index fingertip. " +
                "Move your whole hand: the cursor follows the dot on your knuckle.\n\n" +
                "The label says 'Moving' and the thumb-index line stays white.", "MOVE"),
        Step("🤏", "Tap  (the difference from moving)",
            "MOVE: index up, thumb away. The line is white.\n" +
                "TAP: while pointing, bring your thumb to touch your index FINGERTIP, other fingers stay folded. " +
                "The line turns amber, then cyan, and the label flashes TAP!\n\n" +
                "Depth is measured in 3D, so the thumb has to really touch, not just pass in front. " +
                "The cursor freezes as your fingers get close. Move the cursor over the button below, then pinch.", "TAP"),
        Step("✋", "Scroll",
            "Open your whole hand and HOLD STILL. A ring fills around the cursor (about half a second). " +
                "Then a small dot appears: it shows where your hand is.\n\n" +
                "Move your hand ABOVE the centre to scroll up, BELOW to scroll down. The dot turns cyan when it scrolls, " +
                "and the farther from the centre, the faster. Go back to the centre to stop.\n\n" +
                "Aim the cursor with your index finger first. Wrong way round? Flip it in Settings.", "SCROLL"),
        Step("↔️", "Slide pages",
            "Open your hand, hold still until the ring fills, then move your hand to the RIGHT " +
                "for the next page, or to the LEFT for the previous page. Return to the centre before the next slide. " +
                "Try it on the pages below.", "SWIPE"),
        Step("👌", "Zoom in and out",
            "Make the OK sign: touch your thumb and index fingertips together and keep the other three fingers up. " +
                "Hold it for a moment until the label says 'Zoom mode'.\n\n" +
                "Then move your hand TOWARD the camera to zoom in, or AWAY from it to zoom out. " +
                "Hold the position and it repeats; go back to where you started to stop.\n\n" +
                "Aim the cursor at the middle of what you want to zoom first. Practise on the box below.", "ZOOM"),
        Step("👍", "Volume",
            "Make a thumbs-up (fist with the thumb pointing UP) and hold it: the media volume goes up, and keeps rising " +
                "every half second while you hold. Thumbs-down lowers it. Android's volume bar shows the level.", "VOLUME"),
        Step("✊", "Task done",
            "Make a fist when you have finished something. It means 'this task is complete': the app resets everything in progress, " +
                "buzzes once, and waits for your next command, so nothing carries over by accident.\n\n" +
                "Open your hand again when you are ready to start the next task.", "PAUSED"),
        Step("↩️", "Back",
            "Hold your index and middle fingers up (a V sign) with ring and pinky folded. " +
                "The ring around the cursor fills; when it is full, Back is pressed. " +
                "This tutorial stays open on purpose; the green check confirms it worked.", "BACK"),
        Step("🏠", "Home",
            "Hold index, middle and ring fingers up with the pinky folded. When the ring fills, Home is pressed " +
                "and the app leaves the screen. That is the proof it works. Re-open Virtual Mouse from recent apps.", "HOME"),
        Step("🎉", "You're ready!",
            "If the label stays red, move closer, add light in front of you, or face your palm to the camera.\n\n" +
                "You can change the preview box, scroll direction and cursor smoothness in Settings, and re-open this tutorial any time.", null)
    )

    private var index = 0
    private var taps = 0
    private val detected = BooleanArray(steps.size)
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var dots: LinearLayout
    private lateinit var tvProgress: TextView
    private lateinit var tvEmoji: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvBody: TextView
    private lateinit var tvTrack: TextView
    private lateinit var chipCheck: TextView
    private lateinit var btnTap: Button
    private lateinit var pager: HorizontalScrollView
    private lateinit var zoomView: View
    private lateinit var btnStart: Button
    private lateinit var btnPrev: Button
    private lateinit var btnNext: Button

    private val poll = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 150)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = this
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.CARD
        val pad = Ui.dp(c, 16)

        val outer = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val content = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        outer.addView(
            ScrollView(c).apply { addView(content) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        // progress dots
        dots = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for (i in steps.indices) {
            val lp = LinearLayout.LayoutParams(Ui.dp(c, 9), Ui.dp(c, 9))
            lp.setMargins(Ui.dp(c, 3), 0, Ui.dp(c, 3), 0)
            dots.addView(View(c), lp)
        }
        content.addView(dots)
        tvProgress = Ui.text(c, "", 12f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        Ui.add(content, tvProgress, 8)

        // main card
        val card = Ui.card(c)
        tvEmoji = Ui.text(c, "", 56f).apply { gravity = Gravity.CENTER }
        card.addView(tvEmoji)
        tvTitle = Ui.text(c, "", 22f, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
        Ui.add(card, tvTitle, 4)
        tvBody = Ui.text(c, "", 15f, Ui.MUTED)
        Ui.add(card, tvBody, 12)

        // practice widgets
        btnTap = Ui.button(c, "Tap me with your hand!  (0)", true) {
            taps++
            btnTap.text = "Tap me with your hand!  ($taps)"
        }
        Ui.add(card, btnTap, 14)

        val pageW = resources.displayMetrics.widthPixels - Ui.dp(c, 64)
        pager = buildPager(c, pageW)
        Ui.add(card, pager, 14)

        zoomView = ZoomPracticeView(c)
        zoomView.background = Ui.shape(Ui.CARD2, Ui.dp(c, 16))
        val zlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 170))
        zlp.topMargin = Ui.dp(c, 14)
        card.addView(zoomView, zlp)

        chipCheck = Ui.chip(c, "", Ui.MUTED)
        Ui.add(card, chipCheck, 14)
        Ui.add(content, card, 12)

        tvTrack = Ui.text(c, "", 12f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        Ui.add(content, tvTrack, 12)
        btnStart = Ui.button(c, "Start tracking", true) {
            startTracking(this@TutorialActivity)?.let {
                Toast.makeText(this@TutorialActivity, it, Toast.LENGTH_LONG).show()
            }
        }
        Ui.add(content, btnStart, 8)

        // bottom navigation bar
        btnPrev = Ui.button(c, "Previous", false) { if (index > 0) { index--; render() } }
        val btnSkip = Ui.button(c, "Skip", false) { finishTutorial() }
        btnNext = Ui.button(c, "Next", true) {
            if (index < steps.size - 1) { index++; render() } else finishTutorial()
        }
        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Ui.CARD)
            setPadding(pad, Ui.dp(c, 10), pad, Ui.dp(c, 14))
        }
        val gap = Ui.dp(c, 8)
        bar.addView(btnPrev, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(btnSkip, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = gap })
        bar.addView(btnNext, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f).apply { leftMargin = gap })
        outer.addView(bar)

        setContentView(outer)
        render()
    }

    private fun buildPager(c: Context, pageW: Int): HorizontalScrollView {
        val hs = HorizontalScrollView(c)
        hs.isHorizontalScrollBarEnabled = false
        hs.overScrollMode = View.OVER_SCROLL_NEVER
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        val colors = intArrayOf(Ui.ACCENT, Ui.TEAL, Ui.WARN, Ui.BAD)
        for (i in 0 until 4) {
            val t = Ui.text(c, "Page ${i + 1}", 22f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.background = Ui.shape(colors[i], Ui.dp(c, 16))
            row.addView(t, LinearLayout.LayoutParams(pageW, Ui.dp(c, 110)))
        }
        hs.addView(row)
        hs.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                hs.postDelayed({
                    val page = ((hs.scrollX + pageW / 2) / pageW).coerceIn(0, 3)
                    hs.smoothScrollTo(page * pageW, 0)
                }, 120)
            }
            false
        }
        return hs
    }

    private fun render() {
        val s = steps[index]
        tvProgress.text = "Step ${index + 1} of ${steps.size}"
        tvEmoji.text = s.emoji
        tvTitle.text = s.title
        tvBody.text = s.body
        btnTap.visibility = if (s.target == "TAP") View.VISIBLE else View.GONE
        pager.visibility = if (s.target == "SWIPE") View.VISIBLE else View.GONE
        zoomView.visibility = if (s.target == "ZOOM") View.VISIBLE else View.GONE
        btnPrev.isEnabled = index > 0
        btnPrev.alpha = if (index > 0) 1f else 0.4f
        btnNext.text = if (index == steps.size - 1) "Finish" else "Next"
        refresh()
    }

    private fun refresh() {
        val live = TrackingState.running && MouseAccessibilityService.instance != null
        btnStart.visibility = if (live) View.GONE else View.VISIBLE
        tvTrack.text = if (live) {
            "Tracking ON  |  ${TrackingState.statusLine()}  |  ${TrackingState.fps} fps"
        } else {
            "Tracking is OFF. Start it to practise live, or just press Next."
        }

        val target = steps[index].target
        if (target == null) {
            chipCheck.visibility = View.GONE
        } else {
            chipCheck.visibility = View.VISIBLE
            if (!detected[index] && TrackingState.matches(target)) detected[index] = true
            if (detected[index]) {
                Ui.setChip(chipCheck, "✅  Detected! Great job.", Ui.GOOD)
            } else {
                Ui.setChip(
                    chipCheck,
                    if (live) "⏳  Waiting for your gesture..." else "Start tracking to see this tick green",
                    Ui.MUTED
                )
            }
        }
        for (i in steps.indices) {
            val col = when {
                i == index -> Ui.ACCENT
                detected[i] -> Ui.GOOD
                else -> Ui.CARD2
            }
            dots.getChildAt(i).background = Ui.dot(col)
        }
    }

    private fun finishTutorial() {
        getSharedPreferences("vm", MODE_PRIVATE).edit().putBoolean("tutorial_done", true).apply()
        finish()
    }

    override fun onResume() {
        super.onResume()
        TrackingState.forceHud = true // keep the floating preview visible while learning
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(poll)
    }

    override fun onPause() {
        refresh() // catches the HOME gesture right as the app leaves the screen
        ui.removeCallbacks(poll)
        TrackingState.forceHud = false
        MouseAccessibilityService.instance?.refreshHud()
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // A Back caused by the BACK gesture should not close the tutorial.
        if (TrackingState.eventRecent("BACK", 900L)) return
        super.onBackPressed()
    }
}

/** A box that grows and shrinks with two-finger pinch, so you can see the zoom gesture work. */
private class ZoomPracticeView(c: Context) : View(c) {
    private var scale = 1f
    private val density = c.resources.displayMetrics.density
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 16f * density
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val detector = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            scale = (scale * d.scaleFactor).coerceIn(0.5f, 3f)
            invalidate()
            return true
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        detector.onTouchEvent(e)
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val w = width * 0.14f * scale
        val h = height * 0.22f * scale
        canvas.drawRoundRect(cx - w, cy - h, cx + w, cy + h, 24f, 24f, box)
        canvas.drawText("Zoom %.1fx".format(scale), cx, cy + txt.textSize / 3f, txt)
    }
}
