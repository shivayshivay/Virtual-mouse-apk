package com.example.virtualmouse

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/**
 * Step-by-step tutorial. A 3D hand performs each gesture; when YOU do it the step ticks green
 * and the tutorial moves on to the next step by itself.
 */
class TutorialActivity : Activity() {

    private class Step(val title: String, val pose: String, val body: String, val tip: String?, val target: String?)

    private val steps = listOf(
        Step("Set up your phone", "OPEN",
            "Prop your phone upright so the FRONT camera sees your hand from about 30-50 cm. Put light in front of you, not behind.",
            "Tap 'Start tracking' below to practise every step live.", null),
        Step("Check your hand is captured", "OPEN",
            "Show your open hand to the front camera. The small box at the top-right draws it as a glowing 3D model.",
            "Hold it there for a second. Outside this tutorial the box hides itself once your hand is recognised.",
            "HAND"),
        Step("Move the cursor", "MOVE",
            "Raise your index finger and fold the others. Move your hand like a mouse.",
            "Out of room? Make a fist, move your hand back, then point again. The cursor stays exactly where you left it.",
            "MOVE"),
        Step("Tap", "TAP",
            "Keep your index finger up. Flick your thumb away from your middle finger, then touch them together.",
            "Not tapping? Press 'Calibrate tap' below: it measures your own hand so the tap fits you.",
            "TAP"),
        Step("Scroll", "SCROLL",
            "Open your hand and hold still until the ring fills around the cursor. Then move your hand up or down: the farther, the faster.",
            "Aim the cursor first. Go back to the centre to stop. Wrong way round? Flip it in Settings.",
            "SCROLL"),
        Step("Slide pages", "PAGE",
            "Open your hand, hold still, then move it right for the next page or left for the previous page. Try the pages below.",
            "Return to the centre before the next slide.",
            "SWIPE"),
        Step("Volume", "VOLUME",
            "Raise only your pinky and hold still until the ring fills. Then move your hand up for louder or down for quieter.",
            "A thumbs-up or thumbs-down held for a moment also works. No reaction? Try Settings > Test volume.",
            "VOLUME"),
        Step("Task done", "DONE",
            "When you finish something, make a fist and hold it for a moment. The app resets, buzzes, and waits for your next command.",
            "Open your hand again when you are ready to start the next task.",
            "PAUSED"),
        Step("Back", "BACK",
            "Hold your index and middle fingers up (a V sign) until the ring around the cursor fills. Back is pressed.",
            "This tutorial stays open on purpose; the green tick confirms it worked.",
            "BACK"),
        Step("Home", "HOME",
            "Hold your index, middle and ring fingers up until the ring fills. Home is pressed and the app leaves the screen.",
            "Re-open GestureFlow from recent apps.",
            "HOME"),
        Step("You're ready", "OPEN",
            "You're all set. Change speed, strictness and the floating box in Settings.",
            "If gestures ever trigger by accident, set Settings > Strictness to Strict.",
            null)
    )

    private var index = 0
    private var taps = 0
    private var ticks = 0
    private var advanceScheduled = false
    private var sustainedKey = ""
    private var sustainedSince = 0L
    private val detected = BooleanArray(steps.size)
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var progFill: View
    private lateinit var progRest: View
    private lateinit var tvProgress: TextView
    private lateinit var demoView: HandPreviewView
    private lateinit var tvTitle: TextView
    private lateinit var tvBody: TextView
    private lateinit var tipBox: LinearLayout
    private lateinit var tvTip: TextView
    private lateinit var tvTrack: TextView
    private lateinit var chipCheck: TextView
    private lateinit var swAuto: Switch
    private lateinit var btnTap: Button
    private lateinit var btnCal: Button
    private lateinit var pager: HorizontalScrollView
    private lateinit var btnStart: Button
    private lateinit var btnPrev: Button
    private lateinit var btnNext: Button

    private val poll = object : Runnable {
        override fun run() {
            ticks++
            demoView.invalidate() // the demo hand keeps moving
            if (ticks % 3 == 0) refresh()
            ui.postDelayed(this, 50)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Ui.applyTheme(this)
        setTheme(Ui.themeRes())
        super.onCreate(savedInstanceState)
        val c = this
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        Ui.systemBars(this)
        val pad = Ui.dp(c, 20)

        val outer = LinearLayout(c)
        outer.orientation = LinearLayout.VERTICAL
        outer.setBackgroundColor(Ui.BG)

        // header: step counter + progress bar
        val head = LinearLayout(c)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(pad, Ui.dp(c, 16), pad, Ui.dp(c, 6))
        tvProgress = Ui.text(c, "", 13f, Ui.MUTED, true)
        head.addView(tvProgress)
        val prog = LinearLayout(c)
        prog.orientation = LinearLayout.HORIZONTAL
        progFill = View(c)
        progFill.background = Ui.shape(Ui.ACCENT, Ui.dp(c, 3))
        progRest = View(c)
        progRest.background = Ui.shape(Ui.CARD2, Ui.dp(c, 3))
        prog.addView(progFill, LinearLayout.LayoutParams(0, Ui.dp(c, 6), 1f))
        prog.addView(progRest, LinearLayout.LayoutParams(0, Ui.dp(c, 6), 10f))
        Ui.add(head, prog, 8)
        outer.addView(head)

        val content = LinearLayout(c)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(pad, Ui.dp(c, 8), pad, pad)
        val sv = ScrollView(c)
        sv.addView(content)
        outer.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // the animated 3D hand
        val viewport = FrameLayout(c)
        viewport.background = Ui.shape(Color.rgb(20, 24, 38), Ui.dp(c, 22))
        demoView = HandPreviewView(c, c.resources.displayMetrics.density)
        demoView.showStrip = false
        demoView.cornerDp = 22f
        demoView.demo = "OPEN"
        viewport.addView(demoView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        content.addView(viewport, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 230)))

        // text
        tvTitle = Ui.text(c, "", 26f, Ui.TEXT, true)
        Ui.add(content, tvTitle, 18)
        tvBody = Ui.text(c, "", 16f, Ui.TEXT)
        tvBody.setLineSpacing(0f, 1.15f)
        Ui.add(content, tvBody, 8)
        tipBox = LinearLayout(c)
        tipBox.orientation = LinearLayout.HORIZONTAL
        tipBox.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
        tipBox.background = Ui.shape(Ui.tint(Ui.ACCENT, 24), Ui.dp(c, 14))
        tvTip = Ui.text(c, "", 13f, Ui.TEXT)
        tipBox.addView(tvTip)
        Ui.add(content, tipBox, 14)

        // practice widgets
        btnTap = Ui.button(c, "Tap me with your hand!  (0)", true) {
            taps++
            btnTap.text = "Tap me with your hand!  ($taps)"
        }
        Ui.add(content, btnTap, 16)
        btnCal = Ui.button(c, "Calibrate tap", false) { startActivity(Intent(c, CalibrationActivity::class.java)) }
        Ui.add(content, btnCal, 10)
        val pageW = resources.displayMetrics.widthPixels - Ui.dp(c, 40)
        pager = buildPager(c, pageW)
        Ui.add(content, pager, 16)

        // result + auto-continue
        chipCheck = Ui.chip(c, "", Ui.MUTED)
        Ui.add(content, chipCheck, 16)
        swAuto = Switch(c)
        swAuto.text = "Go to the next step automatically"
        swAuto.setTextColor(Ui.TEXT)
        swAuto.isChecked = prefs.getBoolean("tut_auto", true)
        swAuto.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("tut_auto", on).apply() }
        Ui.add(content, swAuto, 14)

        tvTrack = Ui.text(c, "", 11f, Ui.MUTED)
        tvTrack.typeface = Typeface.MONOSPACE
        tvTrack.gravity = Gravity.CENTER
        Ui.add(content, tvTrack, 14)
        btnStart = Ui.button(c, "Start tracking", true) {
            startTracking(this@TutorialActivity)?.let {
                Toast.makeText(this@TutorialActivity, it, Toast.LENGTH_LONG).show()
            }
        }
        Ui.add(content, btnStart, 8)

        // bottom bar
        btnPrev = Ui.button(c, "Previous", false) { if (index > 0) { index--; render() } }
        val btnSkip = Ui.button(c, "Skip", false) { finishTutorial() }
        btnNext = Ui.button(c, "Next", true) {
            if (index < steps.size - 1) { index++; render() } else finishTutorial()
        }
        val bar = LinearLayout(c)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Ui.CARD)
        bar.setPadding(pad, Ui.dp(c, 10), pad, Ui.dp(c, 14))
        val gap = Ui.dp(c, 8)
        bar.addView(btnPrev, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(btnSkip, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = gap })
        bar.addView(btnNext, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f).apply { leftMargin = gap })
        outer.addView(bar)

        setContentView(outer)
        render()
    }

    private fun buildPager(c: Context, pageW: Int): HorizontalScrollView {
        val hs = HorizontalScrollView(c)
        hs.isHorizontalScrollBarEnabled = false
        hs.overScrollMode = View.OVER_SCROLL_NEVER
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        val colors = intArrayOf(Ui.ACCENT, Ui.TEAL, Ui.WARN, Ui.BAD)
        for (i in 0 until 4) {
            val t = Ui.text(c, "Page ${i + 1}", 22f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.background = Ui.shape(colors[i], Ui.dp(c, 16))
            row.addView(t, LinearLayout.LayoutParams(pageW, Ui.dp(c, 110)))
        }
        hs.addView(row)
        hs.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                hs.postDelayed({
                    val page = ((hs.scrollX + pageW / 2) / pageW).coerceIn(0, 3)
                    hs.smoothScrollTo(page * pageW, 0)
                }, 120)
            }
            false
        }
        return hs
    }

    /** True once [key] has been matched continuously for [ms] (so "move" / "hand found" are not ticked by a blink). */
    private fun sustained(key: String, ms: Long): Boolean {
        val now = SystemClock.uptimeMillis()
        if (TrackingState.matches(key)) {
            if (sustainedKey != key || sustainedSince == 0L) {
                sustainedKey = key
                sustainedSince = now
            }
            return now - sustainedSince >= ms
        }
        sustainedSince = 0L
        return false
    }

    private fun render() {
        val s = steps[index]
        advanceScheduled = false
        sustainedSince = 0L
        tvProgress.text = "Step ${index + 1} of ${steps.size}"
        val frac = (index + 1).toFloat() / steps.size
        progFill.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(this, 6), frac * 10f)
        progRest.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(this, 6), (1f - frac) * 10f + 0.001f)
        demoView.demo = s.pose
        tvTitle.text = s.title
        tvBody.text = s.body
        tvTip.text = if (s.tip != null) "Tip:  ${s.tip}" else ""
        tipBox.visibility = if (s.tip != null) View.VISIBLE else View.GONE
        btnTap.visibility = if (s.target == "TAP") View.VISIBLE else View.GONE
        btnCal.visibility = if (s.target == "TAP") View.VISIBLE else View.GONE
        pager.visibility = if (s.target == "SWIPE") View.VISIBLE else View.GONE
        swAuto.visibility = if (s.target != null) View.VISIBLE else View.GONE
        btnPrev.isEnabled = index > 0
        btnPrev.alpha = if (index > 0) 1f else 0.4f
        btnNext.text = if (index == steps.size - 1) "Finish" else "Next"
        refresh()
    }

    private fun refresh() {
        val live = TrackingState.running && MouseAccessibilityService.instance != null
        btnStart.visibility = if (live) View.GONE else View.VISIBLE
        tvTrack.text = if (live) {
            "Tracking ON  |  ${TrackingState.statusLine()}  |  ${TrackingState.fps} fps\n${TrackingState.debug}"
        } else {
            "Tracking is OFF. Start it to practise live, or just press Next."
        }

        val target = steps[index].target
        if (target == null) {
            chipCheck.visibility = View.GONE
        } else {
            chipCheck.visibility = View.VISIBLE
            if (!detected[index]) {
                val ok = when (target) {
                    "HAND" -> sustained("HAND", 1000L)
                    "MOVE" -> sustained("MOVE", 900L)
                    else -> TrackingState.matches(target)
                }
                if (ok) detected[index] = true
            }
            if (detected[index]) {
                val auto = swAuto.isChecked && index < steps.size - 1
                Ui.setChip(chipCheck, if (auto) "✅  Detected! Next step in a moment..." else "✅  Detected! Great job.", Ui.GOOD)
                if (auto && !advanceScheduled) {
                    advanceScheduled = true
                    val at = index
                    ui.postDelayed({
                        if (index == at && at < steps.size - 1) {
                            index = at + 1
                            render()
                        }
                    }, 1600L)
                }
            } else {
                Ui.setChip(
                    chipCheck,
                    if (live) "Waiting for your gesture..." else "Start tracking to see this tick green",
                    Ui.MUTED
                )
            }
        }
    }

    private fun finishTutorial() {
        prefs.edit().putBoolean("tutorial_done", true).apply()
        finish()
    }

    override fun onResume() {
        super.onResume()
        TrackingState.forceHud = true // keep the floating preview visible while learning
        TrackingState.wantDebug = prefs.getBoolean("diag", false)
        MouseAccessibilityService.instance?.refreshHud()
        ui.post(poll)
    }

    override fun onPause() {
        refresh() // catches the HOME gesture right as the app leaves the screen
        ui.removeCallbacks(poll)
        TrackingState.forceHud = false
        TrackingState.wantDebug = false
        MouseAccessibilityService.instance?.refreshHud()
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // A Back caused by the BACK gesture should not close the tutorial.
        if (TrackingState.eventRecent("BACK", 900L)) return
        super.onBackPressed()
    }
}
