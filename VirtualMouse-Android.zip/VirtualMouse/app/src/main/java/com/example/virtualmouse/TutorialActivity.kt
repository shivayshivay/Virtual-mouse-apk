package com.example.virtualmouse

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Step-by-step tutorial. Each step ticks green when the gesture is really detected. */
class TutorialActivity : Activity() {

    private class Step(val emoji: String, val title: String, val body: String, val target: String?)

    private val steps = listOf(
        Step("📱", "Set up your phone",
            "Prop the phone upright (stand or books) so the FRONT camera sees your hand from about 30-50 cm. " +
                "Light should be in front of you, not behind. Keep your hand upright with fingers pointing up.\n\n" +
                "Tip: tap 'Start tracking' below to practise every step live.", null),
        Step("👀", "Check your hand is captured",
            "Look at the small dark preview box at the TOP-RIGHT of the screen.\n\n" +
                "- A blue skeleton is drawn on your hand when it is captured.\n" +
                "- The dashed rectangle is the active area: your fingertip inside it covers the whole screen.\n" +
                "- The preview is mirrored, like a selfie.\n\n" +
                "Status colours: red = no hand, orange = hand found, green = moving, blue = scroll, " +
                "gray = paused, cyan flash = an action fired.", "HAND"),
        Step("☝️", "Move the cursor",
            "Raise ONLY your index finger and fold the others. The cursor follows your fingertip. " +
                "The big coloured dot on the preview marks exactly the point being tracked.\n\n" +
                "Move left, right, up and down.", "MOVE"),
        Step("🤏", "Tap",
            "Move the cursor over the button below, then pinch thumb + middle finger together. " +
                "The cursor freezes while you pinch so the tap lands where you aimed. " +
                "The label flashes TAP! and the counter goes up if it hit the button.", "TAP"),
        Step("✋", "Scroll",
            "Open your whole hand (all four fingers up). The label says 'Scroll mode'. " +
                "Now move your palm UP or DOWN quickly, like swiping. Scrolling happens at the cursor position, " +
                "so aim the cursor first.", "SCROLL"),
        Step("✊", "Pause",
            "Make a fist. The label turns gray 'Paused' and the cursor fades. Use this to rest your hand.", "PAUSED"),
        Step("🏠", "Home",
            "Pinch thumb + pinky together. This presses the Home button, so the app will leave the screen. " +
                "That is the proof it works. Re-open Virtual Mouse from recent apps to continue.", "HOME"),
        Step("↩️", "Back",
            "Pinch thumb + ring finger. This presses Back. This tutorial stays open on purpose; " +
                "the green check confirms the gesture was detected.", "BACK"),
        Step("🎉", "You're ready!",
            "If the label stays red, move closer, add light in front of you, or keep your hand upright.\n\n" +
                "You can hide the preview with the switch on the main screen, and re-open this tutorial any time.", null)
    )

    private var index = 0
    private var taps = 0
    private val detected = BooleanArray(steps.size)
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var tvProgress: TextView
    private lateinit var tvEmoji: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvBody: TextView
    private lateinit var tvCheck: TextView
    private lateinit var tvTrack: TextView
    private lateinit var btnPractice: Button
    private lateinit var btnStart: Button
    private lateinit var btnPrev: Button
    private lateinit var btnNext: Button

    private val poll = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 150)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(size: Float, bold: Boolean = false): TextView {
            val t = TextView(this)
            t.textSize = size
            if (bold) t.setTypeface(null, Typeface.BOLD)
            root.addView(t)
            return t
        }

        tvProgress = label(13f)
        tvEmoji = label(64f).also { it.gravity = Gravity.CENTER }
        tvTitle = label(22f, true)
        tvBody = label(16f).also { it.setPadding(0, pad / 2, 0, pad / 2) }

        btnPractice = Button(this).apply {
            text = "Tap me with your hand! (0)"
            setOnClickListener {
                taps++
                text = "Tap me with your hand! ($taps)"
            }
        }
        root.addView(btnPractice)

        tvCheck = label(17f, true)
        tvTrack = label(13f).also { it.setPadding(0, pad / 2, 0, pad / 2) }

        btnStart = Button(this).apply {
            text = "Start tracking"
            setOnClickListener {
                startTracking(this@TutorialActivity)?.let {
                    Toast.makeText(this@TutorialActivity, it, Toast.LENGTH_LONG).show()
                }
            }
        }
        root.addView(btnStart)

        btnPrev = Button(this).apply {
            text = "Previous"
            setOnClickListener { if (index > 0) { index--; render() } }
        }
        btnNext = Button(this).apply {
            setOnClickListener {
                if (index < steps.size - 1) { index++; render() } else finishTutorial()
            }
        }
        val btnSkip = Button(this).apply {
            text = "Skip"
            setOnClickListener { finishTutorial() }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (b in listOf(btnPrev, btnNext, btnSkip)) {
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)

        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun render() {
        val s = steps[index]
        tvProgress.text = "Step ${index + 1} of ${steps.size}"
        tvEmoji.text = s.emoji
        tvTitle.text = s.title
        tvBody.text = s.body
        btnPractice.visibility = if (s.target == "TAP") View.VISIBLE else View.GONE
        btnPrev.isEnabled = index > 0
        btnNext.text = if (index == steps.size - 1) "Finish" else "Next"
        refresh()
    }

    private fun refresh() {
        val live = TrackingState.running && MouseAccessibilityService.instance != null
        btnStart.visibility = if (live) View.GONE else View.VISIBLE
        tvTrack.text = if (live) "Tracking: ON | ${TrackingState.statusLine()} | ${TrackingState.fps} fps"
        else "Tracking is OFF. Tap 'Start tracking' to practise live, or just press Next."

        val target = steps[index].target
        if (target == null) {
            tvCheck.text = ""
            return
        }
        if (!detected[index] && TrackingState.matches(target)) detected[index] = true
        if (detected[index]) {
            tvCheck.text = "✅ Detected! Great job."
            tvCheck.setTextColor(Color.rgb(34, 160, 80))
        } else {
            tvCheck.text = if (live) "⏳ Waiting for your gesture..." else "Start tracking to see this tick green"
            tvCheck.setTextColor(Color.GRAY)
        }
    }

    private fun finishTutorial() {
        getSharedPreferences("vm", MODE_PRIVATE).edit().putBoolean("tutorial_done", true).apply()
        finish()
    }

    override fun onResume() {
        super.onResume()
        ui.post(poll)
    }

    override fun onPause() {
        refresh() // catches the HOME gesture right as the app leaves the screen
        ui.removeCallbacks(poll)
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // A Back caused by the BACK gesture should not close the tutorial.
        if (TrackingState.eventRecent("BACK", 900L)) return
        super.onBackPressed()
    }
}
