package com.example.virtualmouse

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Parametric 3D hand: forward kinematics for the four fingers (curl angles per joint),
 * simple two-bone aiming for the thumb. Produces the same 21 landmarks the live tracker gives,
 * so the gesture pictures are drawn by the same 3D hand renderer.
 * Units: metres, wrist at the origin, y points down, z points away from the camera.
 */
object HandPoses {
    private val D2R = (PI / 180.0).toFloat()
    private val MCP = arrayOf(
        floatArrayOf(-0.027f, -0.088f, 0f), floatArrayOf(-0.006f, -0.093f, 0f),
        floatArrayOf(0.016f, -0.088f, 0f), floatArrayOf(0.036f, -0.078f, 0.001f)
    )
    private val LEN = arrayOf(
        floatArrayOf(0.0386f, 0.0254f, 0.0206f), floatArrayOf(0.041f, 0.027f, 0.022f),
        floatArrayOf(0.038f, 0.024f, 0.020f), floatArrayOf(0.030f, 0.019f, 0.016f)
    )
    private val SPLAY = floatArrayOf(-0.10f, -0.01f, 0.05f, 0.20f)
    private val CMC = floatArrayOf(-0.022f, -0.020f, -0.004f)
    private val OPEN2 = floatArrayOf(-0.040f, -0.044f, -0.008f)
    private val OPEN3 = floatArrayOf(-0.054f, -0.066f, -0.010f)
    private val OPEN4 = floatArrayOf(-0.064f, -0.086f, -0.010f)
    private val OPENC = floatArrayOf(0f, 0f, 0f)
    private val FOLD = floatArrayOf(80f * D2R, 100f * D2R, 50f * D2R)
    private val HALF = floatArrayOf(35f * D2R, 50f * D2R, 30f * D2R)

    private fun put(p: FloatArray, i: Int, x: Float, y: Float, z: Float) {
        p[i * 3] = x
        p[i * 3 + 1] = y
        p[i * 3 + 2] = z
    }

    private fun mix(a: FloatArray, b: FloatArray, s: Float): FloatArray =
        floatArrayOf(a[0] + (b[0] - a[0]) * s, a[1] + (b[1] - a[1]) * s, a[2] + (b[2] - a[2]) * s)

    /** Finger f (0 = index .. 3 = pinky) with curl angles c (MCP, PIP, DIP) bending towards the camera. */
    private fun finger(p: FloatArray, f: Int, c: FloatArray, splayAdd: Float) {
        val base = 5 + 4 * f
        val m = MCP[f]
        put(p, base, m[0], m[1], m[2])
        val sp = SPLAY[f] + splayAdd
        val dx = sin(sp)
        val dy = -cos(sp)
        var x = m[0]
        var y = m[1]
        var z = m[2]
        var phi = 0f
        for (k in 0 until 3) {
            phi += c[k]
            val l = LEN[f][k]
            x += dx * l
            y += dy * cos(phi) * l
            z += dy * sin(phi) * l
            put(p, base + 1 + k, x, y, z)
        }
    }

    /** Thumb: open, or aimed so its tip reaches (tx, ty, tz). */
    private fun thumb(p: FloatArray, aim: Boolean, tx: Float, ty: Float, tz: Float) {
        put(p, 1, CMC[0], CMC[1], CMC[2])
        if (!aim) {
            put(p, 2, OPEN2[0], OPEN2[1], OPEN2[2])
            put(p, 3, OPEN3[0], OPEN3[1], OPEN3[2])
            put(p, 4, OPEN4[0], OPEN4[1], OPEN4[2])
            return
        }
        val m2x = OPEN2[0] + (tx - OPEN2[0]) * 0.25f
        val m2y = OPEN2[1] + (ty - OPEN2[1]) * 0.25f
        val m2z = OPEN2[2] + (tz - OPEN2[2]) * 0.25f
        put(p, 2, m2x, m2y, m2z)
        val a = 0.026f
        val b = 0.022f
        val vx = tx - m2x
        val vy = ty - m2y
        val vz = tz - m2z
        val d = max(sqrt(vx * vx + vy * vy + vz * vz), 1e-6f)
        val nx = vx / d
        val ny = vy / d
        val nz = vz / d
        if (d >= a + b) {
            put(p, 3, m2x + nx * a, m2y + ny * a, m2z + nz * a)
            put(p, 4, m2x + nx * (a + b), m2y + ny * (a + b), m2z + nz * (a + b))
        } else {
            val x = (d * d + a * a - b * b) / (2f * d)
            val h = sqrt(max(a * a - x * x, 0f))
            // bend the knuckle towards the camera, perpendicular to the thumb direction
            var qx = nx * nz
            var qy = ny * nz
            var qz = -1f + nz * nz
            val ql = sqrt(qx * qx + qy * qy + qz * qz)
            if (ql > 1e-4f) {
                qx /= ql
                qy /= ql
                qz /= ql
            } else {
                qx = 0f
                qy = -1f
                qz = 0f
            }
            put(p, 3, m2x + nx * x + qx * h, m2y + ny * x + qy * h, m2z + nz * x + qz * h)
            put(p, 4, tx, ty, tz)
        }
    }

    /**
     * 21 landmarks (x, y, z each) for a named gesture, animated by [t] seconds:
     * OPEN, MOVE, TAP, SCROLL, PAGE, VOLUME, FIST, DONE, BACK, HOME.
     */
    fun demo(name: String, t: Float): FloatArray {
        val p = FloatArray(63)
        put(p, 0, 0f, 0f, 0f)
        var cur = arrayOf(OPENC, OPENC, OPENC, OPENC)
        val spl = floatArrayOf(0f, 0f, 0f, 0f)
        var aim = false
        var tx = 0f
        var ty = 0f
        var tz = 0f
        var dx = 0f
        var dy = 0f
        val s = (sin(t * 3f) + 1f) / 2f

        when (name) {
            "MOVE" -> {
                cur = arrayOf(OPENC, FOLD, FOLD, FOLD)
                aim = true; tx = -0.012f; ty = -0.075f; tz = -0.048f
                dx = 0.03f * sin(t * 1.6f)
                dy = 0.02f * sin(t * 1.1f)
            }
            "TAP" -> cur = arrayOf(OPENC, HALF, FOLD, FOLD)
            "SCROLL" -> dy = 0.04f * sin(t * 1.8f)
            "PAGE" -> dx = 0.05f * sin(t * 1.8f)
            "VOLUME" -> {
                cur = arrayOf(FOLD, FOLD, FOLD, OPENC)
                dy = 0.04f * sin(t * 1.8f)
            }
            "FIST" -> {
                cur = arrayOf(FOLD, FOLD, FOLD, FOLD)
                aim = true; tx = 0f; ty = -0.070f; tz = -0.050f
            }
            "DONE" -> {
                val k = (sin(t * 1.5f) + 1f) / 2f
                val c = FloatArray(3) { OPENC[it] + (FOLD[it] - OPENC[it]) * k }
                cur = arrayOf(c, c, c, c)
                if (k > 0.35f) {
                    aim = true
                    val m = mix(floatArrayOf(-0.075f, -0.060f, -0.030f), floatArrayOf(0f, -0.070f, -0.050f), k)
                    tx = m[0]; ty = m[1]; tz = m[2]
                }
            }
            "BACK" -> {
                cur = arrayOf(OPENC, OPENC, FOLD, FOLD)
                spl[0] = -0.12f; spl[1] = 0.08f
                aim = true; tx = 0.012f; ty = -0.078f; tz = -0.048f
            }
            "HOME" -> {
                cur = arrayOf(OPENC, OPENC, OPENC, FOLD)
                spl[0] = -0.10f; spl[2] = 0.06f
                aim = true; tx = 0.030f; ty = -0.070f; tz = -0.040f
            }
        }
        for (f in 0 until 4) finger(p, f, cur[f], spl[f])
        if (name == "TAP") {
            // the thumb swings from open to touching the middle fingertip, and back
            val far = floatArrayOf(-0.085f, -0.060f, -0.030f)
            val touch = floatArrayOf(p[36], p[37], p[38])
            val m = mix(far, touch, s.pow(0.8f))
            thumb(p, true, m[0], m[1], m[2])
        } else {
            thumb(p, aim, tx, ty, tz)
        }
        for (i in 0 until 21) {
            p[i * 3] += dx
            p[i * 3 + 1] += dy
        }
        return p
    }
}
