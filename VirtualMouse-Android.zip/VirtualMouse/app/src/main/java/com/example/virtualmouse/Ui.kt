package com.example.virtualmouse

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** GestureFlow design system with a runtime dark / light theme. */
object Ui {
    var isDark = true
    var BG = Color.rgb(7, 11, 22)
    var CARD = Color.rgb(13, 19, 36)
    var CARD2 = Color.rgb(22, 31, 58)
    var STROKE = Color.argb(46, 40, 215, 255)
    var ACCENT = Color.rgb(40, 215, 255)   // neon cyan
    var BLUE = Color.rgb(47, 128, 255)
    var VIOLET = Color.rgb(107, 76, 255)
    var TEAL = Color.rgb(45, 212, 170)
    var TEXT = Color.rgb(232, 238, 255)
    var MUTED = Color.rgb(140, 152, 186)
    var GOOD = Color.rgb(74, 222, 128)
    var WARN = Color.rgb(251, 191, 36)
    var BAD = Color.rgb(248, 113, 113)

    /** theme pref: 0 = follow the system, 1 = light, 2 = dark. Call before building any view. */
    fun applyTheme(c: Context) {
        val mode = c.getSharedPreferences("vm", Context.MODE_PRIVATE).getInt("theme", 0)
        val sysDark = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        isDark = when (mode) {
            1 -> false
            2 -> true
            else -> sysDark
        }
        if (isDark) {
            BG = Color.rgb(7, 11, 22); CARD = Color.rgb(13, 19, 36); CARD2 = Color.rgb(22, 31, 58)
            STROKE = Color.argb(46, 40, 215, 255)
            ACCENT = Color.rgb(40, 215, 255); BLUE = Color.rgb(47, 128, 255); VIOLET = Color.rgb(107, 76, 255)
            TEAL = Color.rgb(45, 212, 170); TEXT = Color.rgb(232, 238, 255); MUTED = Color.rgb(140, 152, 186)
            GOOD = Color.rgb(74, 222, 128); WARN = Color.rgb(251, 191, 36); BAD = Color.rgb(248, 113, 113)
        } else {
            BG = Color.rgb(242, 245, 252); CARD = Color.rgb(255, 255, 255); CARD2 = Color.rgb(230, 236, 249)
            STROKE = Color.argb(40, 15, 23, 42)
            ACCENT = Color.rgb(0, 146, 204); BLUE = Color.rgb(37, 99, 235); VIOLET = Color.rgb(109, 40, 217)
            TEAL = Color.rgb(13, 148, 136); TEXT = Color.rgb(15, 23, 42); MUTED = Color.rgb(98, 110, 140)
            GOOD = Color.rgb(22, 163, 74); WARN = Color.rgb(217, 119, 6); BAD = Color.rgb(220, 38, 38)
        }
    }

    fun themeRes(): Int =
        if (isDark) android.R.style.Theme_DeviceDefault_NoActionBar else android.R.style.Theme_DeviceDefault_Light_NoActionBar

    /** Status / navigation bar colours and icon tint for the current theme. */
    @Suppress("DEPRECATION")
    fun systemBars(a: Activity) {
        a.window.statusBarColor = BG
        a.window.navigationBarColor = BG
        var f = a.window.decorView.systemUiVisibility
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        f = if (isDark) f and light.inv() else f or light
        a.window.decorView.systemUiVisibility = f
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun tint(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    fun shape(color: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    fun gradient(
        c1: Int, c2: Int, radiusPx: Int,
        o: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
    ): GradientDrawable = GradientDrawable(o, intArrayOf(c1, c2)).apply {
        cornerRadius = radiusPx.toFloat()
    }

    fun dot(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    /** Circle with a neon outline. */
    fun ring(c: Context, strokeDp: Int, color: Int, fill: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            setStroke(dp(c, strokeDp), color)
        }

    private fun ripple(bg: Drawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), bg, null)

    fun text(c: Context, s: String, size: Float, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    /** Rounded surface with a thin outline (and a soft shadow in light mode). */
    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 18)
        setPadding(p, p, p, p)
        background = shape(CARD, dp(c, 22)).apply { setStroke(dp(c, 1), STROKE) }
        if (!isDark) elevation = dp(c, 2).toFloat()
    }

    /** Round badge with an emoji inside, tinted with [color]. */
    fun badge(c: Context, emoji: String, color: Int, sizeDp: Int): TextView = TextView(c).apply {
        text = emoji
        textSize = sizeDp * 0.45f
        gravity = Gravity.CENTER
        background = dot(tint(color, 40)).apply { setStroke(dp(c, 1), tint(color, 120)) }
    }

    fun button(c: Context, label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            stateListAnimator = null
            minHeight = dp(c, 50)
            minimumHeight = dp(c, 50)
            styleButton(this, primary)
            setOnClickListener { onClick() }
        }

    fun styleButton(b: Button, primary: Boolean) {
        val c = b.context
        b.setTextColor(if (primary) Color.WHITE else TEXT)
        b.background = if (primary) {
            ripple(gradient(BLUE, VIOLET, dp(c, 16)))
        } else {
            ripple(shape(CARD2, dp(c, 16)).apply { setStroke(dp(c, 1), STROKE) })
        }
    }

    fun restyle(b: Button, color: Int) {
        b.setTextColor(Color.WHITE)
        b.background = ripple(shape(color, dp(b.context, 16)))
    }

    fun chip(c: Context, s: String, color: Int): TextView = text(c, s, 13f, color, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        background = shape(tint(color, 34), dp(c, 20)).apply { setStroke(dp(c, 1), tint(color, 110)) }
    }

    fun setChip(t: TextView, s: String, color: Int) {
        t.text = s
        t.setTextColor(color)
        t.background = shape(tint(color, 34), dp(t.context, 20)).apply { setStroke(dp(t.context, 1), tint(color, 110)) }
    }

    fun add(parent: LinearLayout, v: View, topDp: Int = 0) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(parent.context, topDp)
        parent.addView(v, lp)
    }
}
