package com.example.virtualmouse

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Tiny design system so every screen looks the same. */
object Ui {
    val BG = Color.rgb(14, 17, 32)
    val CARD = Color.rgb(24, 29, 51)
    val CARD2 = Color.rgb(37, 44, 74)
    val ACCENT = Color.rgb(108, 99, 255)
    val TEAL = Color.rgb(25, 211, 176)
    val TEXT = Color.rgb(241, 243, 255)
    val MUTED = Color.rgb(154, 163, 199)
    val GOOD = Color.rgb(46, 213, 115)
    val WARN = Color.rgb(255, 176, 32)
    val BAD = Color.rgb(255, 77, 109)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun tint(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    fun shape(color: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    fun dot(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    fun gradientCircle(c1: Int, c2: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
            shape = GradientDrawable.OVAL
        }

    private fun ripple(bg: GradientDrawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(60, 255, 255, 255)), bg, null)

    fun text(c: Context, s: String, size: Float, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 16)
        setPadding(p, p, p, p)
        background = shape(CARD, dp(c, 20))
    }

    fun button(c: Context, label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(if (primary) Color.WHITE else TEXT)
            stateListAnimator = null
            minHeight = dp(c, 48)
            minimumHeight = dp(c, 48)
            background = ripple(shape(if (primary) ACCENT else CARD2, dp(c, 14)))
            setOnClickListener { onClick() }
        }

    fun restyle(b: Button, color: Int) {
        b.background = ripple(shape(color, dp(b.context, 14)))
    }

    fun chip(c: Context, s: String, color: Int): TextView = text(c, s, 13f, color, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8))
        background = shape(tint(color, 45), dp(c, 20))
    }

    fun setChip(t: TextView, s: String, color: Int) {
        t.text = s
        t.setTextColor(color)
        t.background = shape(tint(color, 45), dp(t.context, 20))
    }

    fun add(parent: LinearLayout, v: View, topDp: Int = 0) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(parent.context, topDp)
        parent.addView(v, lp)
    }
}
