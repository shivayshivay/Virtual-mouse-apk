package com.example.virtualmouse

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** GestureFlow design system: clean surfaces, one indigo accent, light and dark themes. */
object Ui {
    var isDark = false
    var BG = Color.rgb(247, 248, 252)
    var CARD = Color.WHITE
    var CARD2 = Color.rgb(236, 238, 247)
    var STROKE = Color.argb(30, 15, 23, 42)
    var ACCENT = Color.rgb(79, 70, 229)
    var ON_ACCENT = Color.WHITE
    var BLUE = Color.rgb(37, 99, 235)
    var VIOLET = Color.rgb(124, 58, 237)
    var TEAL = Color.rgb(13, 148, 136)
    var TEXT = Color.rgb(17, 24, 39)
    var MUTED = Color.rgb(107, 114, 128)
    var GOOD = Color.rgb(22, 163, 74)
    var WARN = Color.rgb(217, 119, 6)
    var BAD = Color.rgb(220, 38, 38)

    /** theme pref: 0 = follow the system, 1 = light, 2 = dark. Call before building any view. */
    fun applyTheme(c: Context) {
        val mode = c.getSharedPreferences("vm", Context.MODE_PRIVATE).getInt("theme", 0)
        val sysDark = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        isDark = when (mode) {
            1 -> false
            2 -> true
            else -> sysDark
        }
        if (isDark) {
            BG = Color.rgb(15, 17, 21); CARD = Color.rgb(26, 29, 36); CARD2 = Color.rgb(40, 44, 54)
            STROKE = Color.argb(34, 255, 255, 255)
            ACCENT = Color.rgb(129, 140, 248); ON_ACCENT = Color.rgb(15, 17, 21)
            BLUE = Color.rgb(96, 165, 250); VIOLET = Color.rgb(167, 139, 250); TEAL = Color.rgb(45, 212, 191)
            TEXT = Color.rgb(236, 239, 244); MUTED = Color.rgb(148, 155, 170)
            GOOD = Color.rgb(74, 222, 128); WARN = Color.rgb(251, 191, 36); BAD = Color.rgb(248, 113, 113)
        } else {
            BG = Color.rgb(247, 248, 252); CARD = Color.WHITE; CARD2 = Color.rgb(236, 238, 247)
            STROKE = Color.argb(30, 15, 23, 42)
            ACCENT = Color.rgb(79, 70, 229); ON_ACCENT = Color.WHITE
            BLUE = Color.rgb(37, 99, 235); VIOLET = Color.rgb(124, 58, 237); TEAL = Color.rgb(13, 148, 136)
            TEXT = Color.rgb(17, 24, 39); MUTED = Color.rgb(107, 114, 128)
            GOOD = Color.rgb(22, 163, 74); WARN = Color.rgb(217, 119, 6); BAD = Color.rgb(220, 38, 38)
        }
    }

    fun themeRes(): Int =
        if (isDark) android.R.style.Theme_DeviceDefault_NoActionBar else android.R.style.Theme_DeviceDefault_Light_NoActionBar

    /** Status / navigation bar colours and icon tint for the current theme. */
    @Suppress("DEPRECATION")
    fun systemBars(a: Activity) {
        a.window.statusBarColor = BG
        a.window.navigationBarColor = CARD
        var f = a.window.decorView.systemUiVisibility
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        f = if (isDark) f and light.inv() else f or light
        a.window.decorView.systemUiVisibility = f
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun tint(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    fun shape(color: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    fun gradient(
        c1: Int, c2: Int, radiusPx: Int,
        o: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
    ): GradientDrawable = GradientDrawable(o, intArrayOf(c1, c2)).apply {
        cornerRadius = radiusPx.toFloat()
    }

    fun dot(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    /** Circle outline. */
    fun ring(c: Context, strokeDp: Int, color: Int, fill: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            setStroke(dp(c, strokeDp), color)
        }

    private fun ripple(bg: Drawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(60, 128, 128, 128)), bg, null)

    fun text(c: Context, s: String, size: Float, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    /** White (or dark grey) rounded surface with a hairline outline. */
    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 18)
        setPadding(p, p, p, p)
        background = shape(CARD, dp(c, 20)).apply { setStroke(dp(c, 1), STROKE) }
        elevation = dp(c, if (isDark) 0 else 1).toFloat()
    }

    /** Round badge with an emoji inside, softly tinted with [color]. */
    fun badge(c: Context, emoji: String, color: Int, sizeDp: Int): TextView = TextView(c).apply {
        text = emoji
        textSize = sizeDp * 0.45f
        gravity = Gravity.CENTER
        background = dot(tint(color, 34))
    }

    fun button(c: Context, label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            stateListAnimator = null
            minHeight = dp(c, 50)
            minimumHeight = dp(c, 50)
            styleButton(this, primary)
            setOnClickListener { onClick() }
        }

    /** primary = solid accent; otherwise a quiet tonal button. */
    fun styleButton(b: Button, primary: Boolean) {
        val c = b.context
        b.setTextColor(if (primary) ON_ACCENT else TEXT)
        b.background = ripple(shape(if (primary) ACCENT else CARD2, dp(c, 14)))
    }

    fun restyle(b: Button, color: Int) {
        b.setTextColor(Color.WHITE)
        b.background = ripple(shape(color, dp(b.context, 14)))
    }

    fun chip(c: Context, s: String, color: Int): TextView = text(c, s, 13f, color, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(c, 14), dp(c, 7), dp(c, 14), dp(c, 7))
        background = shape(tint(color, 30), dp(c, 20))
    }

    fun setChip(t: TextView, s: String, color: Int) {
        t.text = s
        t.setTextColor(color)
        t.background = shape(tint(color, 30), dp(t.context, 20))
    }

    fun add(parent: LinearLayout, v: View, topDp: Int = 0) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(parent.context, topDp)
        parent.addView(v, lp)
    }
}
