package com.example.virtualmouse

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Small design system: violet -> pink gradient on a deep midnight background. */
object Ui {
    val BG = Color.rgb(11, 10, 31)
    val CARD = Color.rgb(24, 22, 52)
    val CARD2 = Color.rgb(42, 38, 84)
    val ACCENT = Color.rgb(139, 92, 246)
    val PINK = Color.rgb(236, 72, 153)
    val TEAL = Color.rgb(34, 211, 238)
    val TEXT = Color.rgb(245, 243, 255)
    val MUTED = Color.rgb(166, 160, 205)
    val GOOD = Color.rgb(74, 222, 128)
    val WARN = Color.rgb(251, 191, 36)
    val BAD = Color.rgb(248, 113, 113)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun tint(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    fun shape(color: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    fun gradient(
        c1: Int, c2: Int, radiusPx: Int,
        o: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
    ): GradientDrawable = GradientDrawable(o, intArrayOf(c1, c2)).apply {
        cornerRadius = radiusPx.toFloat()
    }

    fun dot(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    fun gradientCircle(c1: Int, c2: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
            shape = GradientDrawable.OVAL
        }

    private fun ripple(bg: Drawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), bg, null)

    fun text(c: Context, s: String, size: Float, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 18)
        setPadding(p, p, p, p)
        background = shape(CARD, dp(c, 24)).apply { setStroke(dp(c, 1), tint(Color.WHITE, 30)) }
    }

    /** Round badge with an emoji inside, tinted with [color]. */
    fun badge(c: Context, emoji: String, color: Int, sizeDp: Int): TextView = TextView(c).apply {
        text = emoji
        textSize = sizeDp * 0.45f
        gravity = Gravity.CENTER
        background = dot(tint(color, 60))
    }

    fun button(c: Context, label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            stateListAnimator = null
            minHeight = dp(c, 50)
            minimumHeight = dp(c, 50)
            styleButton(this, primary)
            setOnClickListener { onClick() }
        }

    fun styleButton(b: Button, primary: Boolean) {
        val c = b.context
        b.setTextColor(if (primary) Color.WHITE else TEXT)
        b.background = if (primary) {
            ripple(gradient(ACCENT, PINK, dp(c, 16)))
        } else {
            ripple(shape(CARD2, dp(c, 16)).apply { setStroke(dp(c, 1), tint(Color.WHITE, 30)) })
        }
    }

    fun restyle(b: Button, color: Int) {
        b.background = ripple(shape(color, dp(b.context, 16)))
    }

    fun chip(c: Context, s: String, color: Int): TextView = text(c, s, 13f, color, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        background = shape(tint(color, 45), dp(c, 20))
    }

    fun setChip(t: TextView, s: String, color: Int) {
        t.text = s
        t.setTextColor(color)
        t.background = shape(tint(color, 45), dp(t.context, 20))
    }

    fun add(parent: LinearLayout, v: View, topDp: Int = 0) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(parent.context, topDp)
        parent.addView(v, lp)
    }
}
