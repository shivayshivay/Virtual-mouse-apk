#!/usr/bin/env bash
set -e
mkdir -p app/src/main/assets
curl -L --fail -o app/src/main/assets/hand_landmarker.task \
  https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
echo "Model downloaded."
