# GestureFlow - notices

GestureFlow (c) 2026 shivayshivay. All rights reserved.
(Change the name in `app/src/main/res/values/about.xml`; the About screen reads it from there.)

## Third-party software
- MediaPipe Tasks and the hand landmark model - Google - Apache License 2.0
- AndroidX CameraX, Lifecycle, Core - Google - Apache License 2.0
- Kotlin Standard Library - JetBrains - Apache License 2.0

Apache License 2.0: https://www.apache.org/licenses/LICENSE-2.0

GestureFlow is not affiliated with or endorsed by Google. Other trademarks belong to their owners.

## Artwork
The app icon (`app/src/main/res/mipmap-*/ic_launcher_foreground.png`, `drawable-nodpi/gf_logo.png`) was supplied by the developer.
Only publish the app if you hold the rights to this artwork.
