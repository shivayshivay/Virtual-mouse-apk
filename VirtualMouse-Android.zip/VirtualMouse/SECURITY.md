# GestureFlow - security notes

## What the app can do
- Uses the FRONT camera, only while tracking is running (a notification and Android's camera indicator are shown).
- Changes the MEDIA volume (thumbs-up / thumbs-down) through Android's AudioManager; this needs no extra permission.
- Draws a cursor overlay and performs taps, swipes, pinch-zoom, Back and Home through an Accessibility Service.

## What it cannot do (by design)
- No INTERNET permission: it cannot send data off the phone. (Checked on every cloud build.)
- The accessibility service does not request `canRetrieveWindowContent` or key-event filtering, so it is not given access to screen contents or typed text.
- Camera frames are processed in memory and never written to storage.
- Backups are disabled (`allowBackup=false`); the only stored data is a few small preferences (smoothness, preview mode, haptics, tutorial flag).

## Safety behaviours
- Camera stops when the screen turns off, and after 5 minutes without a hand.
- Only the system can bind the accessibility service (`BIND_ACCESSIBILITY_SERVICE`). Only the launcher activity is exported.

## Known limits / to do before wider distribution
- `debug.keystore` is committed with the default password. Anyone holding it can sign an APK that Android accepts as an update to this app. Keep the repository PRIVATE, or replace it with your own secret key.
- Builds are debug builds (debuggable). Use a signed release build for anything beyond personal use.
- The hand model is downloaded at build time from storage.googleapis.com without a checksum.
